--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_cron; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION pg_cron; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_cron IS 'Job scheduler for PostgreSQL';


--
-- Name: dba; Type: SCHEMA; Schema: -; Owner: dba_user
--

CREATE SCHEMA dba;


ALTER SCHEMA dba OWNER TO dba_user;

--
-- Name: dblink; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;


--
-- Name: EXTENSION dblink; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';


--
-- Name: remote_truncate_and_vacuum(); Type: FUNCTION; Schema: cron; Owner: dba_user
--

CREATE FUNCTION cron.remote_truncate_and_vacuum() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- TRUNCATE can run inside a transaction
  PERFORM dblink_exec(
    'dbname=dba_user user=postgres password=Password09',
    'TRUNCATE TABLE public.activity_log;'
  );

  -- VACUUM must run outside a transaction block
  PERFORM dblink_exec(
    'dbname=dba_user user=postgres password=Password09',
    'VACUUM public.activity_log;'
  );
END;
$$;


ALTER FUNCTION cron.remote_truncate_and_vacuum() OWNER TO dba_user;

--
-- Name: remote_vacuum(); Type: FUNCTION; Schema: cron; Owner: dba_user
--

CREATE FUNCTION cron.remote_vacuum() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- VACUUM FULL must run outside a transaction block
  PERFORM dblink_exec(
    'dbname=dba_user user=postgres password=Password09',
    'VACUUM FULL ANALYZE;'
  );
END;
$$;


ALTER FUNCTION cron.remote_vacuum() OWNER TO dba_user;

--
-- Name: truncate_and_vacuum(); Type: FUNCTION; Schema: public; Owner: dba_user
--

CREATE FUNCTION public.truncate_and_vacuum() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  TRUNCATE TABLE public.activity_log;
  VACUUM public.activity_log;
END;
$$;


ALTER FUNCTION public.truncate_and_vacuum() OWNER TO dba_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hardware_2; Type: TABLE; Schema: dba; Owner: mis_user
--

CREATE TABLE dba.hardware_2 (
    id integer,
    make character varying(255),
    model character varying(255),
    serial character varying(255),
    os_name character varying(255),
    os_version character varying(255),
    type character varying(255),
    ram character varying(255),
    cpu integer,
    status integer,
    current boolean,
    company_id integer,
    user_id integer,
    provaider_id integer,
    purchased_at character varying(255),
    created_at character varying(255),
    updated_at character varying(255),
    deleted_at character varying(255),
    note character varying(255),
    max_con integer
);


ALTER TABLE dba.hardware_2 OWNER TO mis_user;

--
-- Name: activity_log; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.activity_log (
    id bigint NOT NULL,
    log_name character varying(255),
    description text NOT NULL,
    subject_type character varying(255),
    subject_id bigint,
    causer_type character varying(255),
    causer_id bigint,
    properties json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    event character varying(255),
    batch_uuid uuid
);


ALTER TABLE public.activity_log OWNER TO dba_user;

--
-- Name: activity_log_id_seq; Type: SEQUENCE; Schema: public; Owner: dba_user
--

CREATE SEQUENCE public.activity_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_log_id_seq OWNER TO dba_user;

--
-- Name: activity_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dba_user
--

ALTER SEQUENCE public.activity_log_id_seq OWNED BY public.activity_log.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.companies (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    personal_company boolean NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.companies OWNER TO dba_user;

--
-- Name: TABLE companies; Type: COMMENT; Schema: public; Owner: dba_user
--

COMMENT ON TABLE public.companies IS 'default id ';


--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: dba_user
--

CREATE SEQUENCE public.companies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.companies_id_seq OWNER TO dba_user;

--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dba_user
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: company_invitations; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.company_invitations (
    id bigint NOT NULL,
    company_id bigint NOT NULL,
    email character varying(255) NOT NULL,
    role character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.company_invitations OWNER TO dba_user;

--
-- Name: company_invitations_id_seq; Type: SEQUENCE; Schema: public; Owner: dba_user
--

CREATE SEQUENCE public.company_invitations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.company_invitations_id_seq OWNER TO dba_user;

--
-- Name: company_invitations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dba_user
--

ALTER SEQUENCE public.company_invitations_id_seq OWNED BY public.company_invitations.id;


--
-- Name: company_user; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.company_user (
    id bigint NOT NULL,
    company_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.company_user OWNER TO dba_user;

--
-- Name: company_user_id_seq; Type: SEQUENCE; Schema: public; Owner: dba_user
--

CREATE SEQUENCE public.company_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.company_user_id_seq OWNER TO dba_user;

--
-- Name: company_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dba_user
--

ALTER SEQUENCE public.company_user_id_seq OWNED BY public.company_user.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO dba_user;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: dba_user
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.failed_jobs_id_seq OWNER TO dba_user;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dba_user
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: hardware; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.hardware (
    id bigint NOT NULL,
    make character varying(150),
    model character varying(150),
    serial character varying(150),
    os_name character varying(150),
    os_version character varying(150),
    type character varying(150),
    ram character varying(150),
    cpu character varying(150),
    status character varying(150),
    current boolean DEFAULT true,
    company_id bigint,
    user_id bigint,
    provaider_id bigint,
    purchased_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    note character varying(250),
    max_con bigint
)
WITH (autovacuum_enabled='true', autovacuum_analyze_scale_factor='0.05', autovacuum_vacuum_scale_factor='0.02', toast.autovacuum_enabled='true', toast.autovacuum_vacuum_cost_delay='20', toast.autovacuum_vacuum_scale_factor='0.02', toast.autovacuum_vacuum_threshold='50');


ALTER TABLE public.hardware OWNER TO dba_user;

--
-- Name: TABLE hardware; Type: COMMENT; Schema: public; Owner: dba_user
--

COMMENT ON TABLE public.hardware IS 'default id for hardware';


--
-- Name: COLUMN hardware.id; Type: COMMENT; Schema: public; Owner: dba_user
--

COMMENT ON COLUMN public.hardware.id IS 'default id for hardware';


--
-- Name: hardware270225; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.hardware270225 (
    id bigint,
    make character varying(150),
    model character varying(150),
    serial character varying(150),
    os_name character varying(150),
    os_version character varying(150),
    type character varying(150),
    ram character varying(150),
    cpu character varying(150),
    status character varying(150),
    current boolean,
    company_id bigint,
    user_id bigint,
    provaider_id bigint,
    purchased_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    note character varying(250)
);


ALTER TABLE public.hardware270225 OWNER TO dba_user;

--
-- Name: hardware_id_seq; Type: SEQUENCE; Schema: public; Owner: dba_user
--

CREATE SEQUENCE public.hardware_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hardware_id_seq OWNER TO dba_user;

--
-- Name: hardware_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dba_user
--

ALTER SEQUENCE public.hardware_id_seq OWNED BY public.hardware.id;


--
-- Name: hardware_050425; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.hardware_050425 (
    id bigint DEFAULT nextval('public.hardware_id_seq'::regclass) NOT NULL,
    make character varying(150) NOT NULL,
    model character varying(150) NOT NULL,
    serial character varying(150) NOT NULL,
    os_name character varying(150),
    os_version character varying(150),
    type character varying(150) NOT NULL,
    ram character varying(150),
    cpu character varying(150),
    status character varying(150) NOT NULL,
    current boolean DEFAULT true NOT NULL,
    company_id bigint NOT NULL,
    user_id bigint,
    provaider_id bigint NOT NULL,
    purchased_at timestamp(0) without time zone NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    note character varying(250)
);


ALTER TABLE public.hardware_050425 OWNER TO dba_user;

--
-- Name: hardware_050825; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.hardware_050825 (
    id bigint DEFAULT nextval('public.hardware_id_seq'::regclass) NOT NULL,
    make character varying(150) NOT NULL,
    model character varying(150) NOT NULL,
    serial character varying(150) NOT NULL,
    os_name character varying(150),
    os_version character varying(150),
    type character varying(150) NOT NULL,
    ram character varying(150),
    cpu character varying(150),
    status character varying(150) NOT NULL,
    current boolean DEFAULT true NOT NULL,
    company_id bigint NOT NULL,
    user_id bigint,
    provaider_id bigint NOT NULL,
    purchased_at timestamp(0) without time zone NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    note character varying(250),
    max_con bigint
);


ALTER TABLE public.hardware_050825 OWNER TO dba_user;

--
-- Name: TABLE hardware_050825; Type: COMMENT; Schema: public; Owner: dba_user
--

COMMENT ON TABLE public.hardware_050825 IS 'default id for hardware';


--
-- Name: COLUMN hardware_050825.id; Type: COMMENT; Schema: public; Owner: dba_user
--

COMMENT ON COLUMN public.hardware_050825.id IS 'default id for hardware';


--
-- Name: hardware_131024; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.hardware_131024 (
    id bigint,
    make character varying(150),
    model character varying(150),
    serial character varying(150),
    os_name character varying(150),
    os_version character varying(150),
    type character varying(150),
    ram character varying(150),
    cpu character varying(150),
    status character varying(150),
    current boolean,
    company_id bigint,
    user_id bigint,
    provaider_id bigint,
    purchased_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    note character varying(240)
);


ALTER TABLE public.hardware_131024 OWNER TO dba_user;

--
-- Name: hardware_140525; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.hardware_140525 (
    id bigint DEFAULT nextval('public.hardware_id_seq'::regclass) NOT NULL,
    make character varying(150) NOT NULL,
    model character varying(150) NOT NULL,
    serial character varying(150) NOT NULL,
    os_name character varying(150),
    os_version character varying(150),
    type character varying(150) NOT NULL,
    ram character varying(150),
    cpu character varying(150),
    status character varying(150) NOT NULL,
    current boolean DEFAULT true NOT NULL,
    company_id bigint NOT NULL,
    user_id bigint,
    provaider_id bigint NOT NULL,
    purchased_at timestamp(0) without time zone NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    note character varying(250),
    max_con bigint
);


ALTER TABLE public.hardware_140525 OWNER TO dba_user;

--
-- Name: hardware_2; Type: TABLE; Schema: public; Owner: mis_user
--

CREATE TABLE public.hardware_2 (
    id bigint,
    make character varying(150),
    model character varying(150),
    serial character varying(150),
    os_name character varying(150),
    os_version character varying(150),
    type character varying(150),
    ram character varying(150),
    cpu character varying(150),
    status character varying(150) NOT NULL,
    current boolean NOT NULL,
    company_id bigint NOT NULL,
    user_id bigint,
    provaider_id bigint NOT NULL,
    purchased_at timestamp(0) without time zone NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    note character varying(250),
    max_con bigint
);


ALTER TABLE public.hardware_2 OWNER TO mis_user;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO dba_user;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: dba_user
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO dba_user;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dba_user
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: model_has_permissions; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.model_has_permissions (
    permission_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.model_has_permissions OWNER TO dba_user;

--
-- Name: model_has_roles; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.model_has_roles (
    role_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.model_has_roles OWNER TO dba_user;

--
-- Name: mv_active_hardware_summary; Type: MATERIALIZED VIEW; Schema: public; Owner: dba_user
--

CREATE MATERIALIZED VIEW public.mv_active_hardware_summary AS
 SELECT id,
    make,
    model,
    serial,
    os_name,
    os_version,
    type,
    ram,
    cpu,
    status,
    company_id,
    user_id,
    provaider_id,
    purchased_at,
    note
   FROM public.hardware
  WHERE ((current = true) AND (deleted_at IS NULL))
  ORDER BY id
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.mv_active_hardware_summary OWNER TO dba_user;

--
-- Name: mv_activity_log_summary; Type: MATERIALIZED VIEW; Schema: public; Owner: dba_user
--

CREATE MATERIALIZED VIEW public.mv_activity_log_summary AS
 SELECT log_name,
    count(*) AS log_count,
    max(created_at) AS last_logged_at
   FROM public.activity_log
  GROUP BY log_name
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.mv_activity_log_summary OWNER TO dba_user;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    type character varying(255) NOT NULL,
    notifiable_type character varying(255) NOT NULL,
    notifiable_id bigint NOT NULL,
    data jsonb NOT NULL,
    read_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.notifications OWNER TO dba_user;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO dba_user;

--
-- Name: periphels; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.periphels (
    id bigint NOT NULL,
    make character varying(255) NOT NULL,
    model character varying(255) NOT NULL,
    serial character varying(255),
    type character varying(255) NOT NULL,
    company_id bigint NOT NULL,
    user_id bigint,
    provaider_id bigint NOT NULL,
    current boolean DEFAULT true NOT NULL,
    purchased_at timestamp(0) without time zone NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.periphels OWNER TO dba_user;

--
-- Name: TABLE periphels; Type: COMMENT; Schema: public; Owner: dba_user
--

COMMENT ON TABLE public.periphels IS 'default id ';


--
-- Name: periphels_id_seq; Type: SEQUENCE; Schema: public; Owner: dba_user
--

CREATE SEQUENCE public.periphels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.periphels_id_seq OWNER TO dba_user;

--
-- Name: periphels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dba_user
--

ALTER SEQUENCE public.periphels_id_seq OWNED BY public.periphels.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.permissions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.permissions OWNER TO dba_user;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: dba_user
--

CREATE SEQUENCE public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.permissions_id_seq OWNER TO dba_user;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dba_user
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO dba_user;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: dba_user
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.personal_access_tokens_id_seq OWNER TO dba_user;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dba_user
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: provaiders; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.provaiders (
    id bigint NOT NULL,
    company_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.provaiders OWNER TO dba_user;

--
-- Name: provaiders_id_seq; Type: SEQUENCE; Schema: public; Owner: dba_user
--

CREATE SEQUENCE public.provaiders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.provaiders_id_seq OWNER TO dba_user;

--
-- Name: provaiders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dba_user
--

ALTER SEQUENCE public.provaiders_id_seq OWNED BY public.provaiders.id;


--
-- Name: role_has_permissions; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.role_has_permissions (
    permission_id bigint NOT NULL,
    role_id bigint NOT NULL
);


ALTER TABLE public.role_has_permissions OWNER TO dba_user;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.roles OWNER TO dba_user;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: dba_user
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO dba_user;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dba_user
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: schedule_histories; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.schedule_histories (
    id bigint NOT NULL,
    schedule_id bigint NOT NULL,
    command character varying(255) NOT NULL,
    params text,
    output text NOT NULL,
    options text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.schedule_histories OWNER TO dba_user;

--
-- Name: schedule_histories_id_seq; Type: SEQUENCE; Schema: public; Owner: dba_user
--

CREATE SEQUENCE public.schedule_histories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.schedule_histories_id_seq OWNER TO dba_user;

--
-- Name: schedule_histories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dba_user
--

ALTER SEQUENCE public.schedule_histories_id_seq OWNED BY public.schedule_histories.id;


--
-- Name: schedules; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.schedules (
    id bigint NOT NULL,
    command character varying(255) NOT NULL,
    command_custom character varying(255),
    params text,
    expression character varying(255) NOT NULL,
    environments character varying(255),
    options text,
    options_with_value text,
    log_filename character varying(255),
    even_in_maintenance_mode boolean DEFAULT false NOT NULL,
    without_overlapping boolean DEFAULT false NOT NULL,
    on_one_server boolean DEFAULT false NOT NULL,
    webhook_before character varying(255),
    webhook_after character varying(255),
    email_output character varying(255),
    sendmail_error boolean DEFAULT false NOT NULL,
    log_success boolean DEFAULT true NOT NULL,
    log_error boolean DEFAULT true NOT NULL,
    status boolean DEFAULT true NOT NULL,
    run_in_background boolean DEFAULT false NOT NULL,
    sendmail_success boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.schedules OWNER TO dba_user;

--
-- Name: schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: dba_user
--

CREATE SEQUENCE public.schedules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.schedules_id_seq OWNER TO dba_user;

--
-- Name: schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dba_user
--

ALTER SEQUENCE public.schedules_id_seq OWNED BY public.schedules.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO dba_user;

--
-- Name: software; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.software (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    current boolean DEFAULT true NOT NULL,
    licenses character varying(255),
    license_period character varying(255),
    company_id bigint NOT NULL,
    provaider_id bigint NOT NULL,
    purchased_at timestamp(0) without time zone NOT NULL,
    expired_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.software OWNER TO dba_user;

--
-- Name: TABLE software; Type: COMMENT; Schema: public; Owner: dba_user
--

COMMENT ON TABLE public.software IS 'default id ';


--
-- Name: software_id_seq; Type: SEQUENCE; Schema: public; Owner: dba_user
--

CREATE SEQUENCE public.software_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.software_id_seq OWNER TO dba_user;

--
-- Name: software_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dba_user
--

ALTER SEQUENCE public.software_id_seq OWNED BY public.software.id;


--
-- Name: system_metrics; Type: TABLE; Schema: public; Owner: mis_user
--

CREATE TABLE public.system_metrics (
    id bigint NOT NULL,
    "timestamp" timestamp(0) without time zone NOT NULL,
    hostname character varying(255) NOT NULL,
    environment character varying(255) NOT NULL,
    cpu_usage character varying(255) NOT NULL,
    memory_usage character varying(255) NOT NULL,
    disk_usage character varying(255) NOT NULL,
    network_usage character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    extra1 character varying(255),
    extra2 character varying(255),
    file_name character varying(255) NOT NULL,
    load_status character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.system_metrics OWNER TO mis_user;

--
-- Name: system_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: mis_user
--

CREATE SEQUENCE public.system_metrics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_metrics_id_seq OWNER TO mis_user;

--
-- Name: system_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mis_user
--

ALTER SEQUENCE public.system_metrics_id_seq OWNED BY public.system_metrics.id;


--
-- Name: test; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.test (
    id bigint DEFAULT nextval('public.hardware_id_seq'::regclass),
    make character varying(255),
    model character varying(255),
    serial character varying(255),
    os_name character varying(255),
    os_version character varying(255),
    type character varying(255),
    ram character varying(255),
    cpu character varying(255),
    status character varying(255),
    current boolean,
    company_id bigint,
    user_id bigint,
    provaider_id bigint,
    purchased_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    note character varying(240)
);


ALTER TABLE public.test OWNER TO dba_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: dba_user
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    current_company_id bigint,
    current_connected_account_id bigint,
    profile_photo_path character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    two_factor_secret text,
    two_factor_recovery_codes text,
    two_factor_confirmed_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO dba_user;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: dba_user
--

COMMENT ON TABLE public.users IS 'default id ';


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: dba_user
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO dba_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dba_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: activity_log id; Type: DEFAULT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.activity_log ALTER COLUMN id SET DEFAULT nextval('public.activity_log_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: company_invitations id; Type: DEFAULT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.company_invitations ALTER COLUMN id SET DEFAULT nextval('public.company_invitations_id_seq'::regclass);


--
-- Name: company_user id; Type: DEFAULT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.company_user ALTER COLUMN id SET DEFAULT nextval('public.company_user_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: hardware id; Type: DEFAULT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.hardware ALTER COLUMN id SET DEFAULT nextval('public.hardware_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: periphels id; Type: DEFAULT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.periphels ALTER COLUMN id SET DEFAULT nextval('public.periphels_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: provaiders id; Type: DEFAULT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.provaiders ALTER COLUMN id SET DEFAULT nextval('public.provaiders_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: schedule_histories id; Type: DEFAULT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.schedule_histories ALTER COLUMN id SET DEFAULT nextval('public.schedule_histories_id_seq'::regclass);


--
-- Name: schedules id; Type: DEFAULT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.schedules ALTER COLUMN id SET DEFAULT nextval('public.schedules_id_seq'::regclass);


--
-- Name: software id; Type: DEFAULT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.software ALTER COLUMN id SET DEFAULT nextval('public.software_id_seq'::regclass);


--
-- Name: system_metrics id; Type: DEFAULT; Schema: public; Owner: mis_user
--

ALTER TABLE ONLY public.system_metrics ALTER COLUMN id SET DEFAULT nextval('public.system_metrics_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: job; Type: TABLE DATA; Schema: cron; Owner: dba_user
--

COPY cron.job (jobid, schedule, command, nodename, nodeport, database, username, active, jobname) FROM stdin;
1	0 3 3 * *	SELECT remote_truncate_and_vacuum();	localhost	5432	dba_user	dba_user	t	remote truncate and vacuum
6	0 23 * * *	SELECT cron.remote_vacuum();	localhost	5432	dba_user	dba_user	t	test_job_every_5_minutes
5	0 23 * * *	SELECT cron.remote_vacuum();	localhost	5432	dba_user	dba_user	t	daily_remote_vacuum
7	* * * * *	REFRESH MATERIALIZED VIEW public.activity_log_summary;	localhost	5432	dba_user	dba_user	f	refresh_mv_activity_log_summary
11	0 22 * * *	REFRESH MATERIALIZED VIEW public.activity_log_summary;	localhost	5432	dba_user	dba_user	t	refresh_mv_activity_log_summary2
13	0 1 * * *	DELETE FROM "cron"."job_run_details" WHERE "end_time" < NOW() - INTERVAL '3 days'	localhost	5432	dba_user	dba_user	t	delete_old_job_run_details
12	0 21 * * *	REFRESH MATERIALIZED VIEW CONCURRENTLY public.MV_active_hardware_summary	localhost	5432	dba_user	dba_user	t	refresh_mv_active_hardware_summary
\.


--
-- Data for Name: job_run_details; Type: TABLE DATA; Schema: cron; Owner: dba_user
--

COPY cron.job_run_details (jobid, runid, job_pid, database, username, command, status, return_message, start_time, end_time) FROM stdin;
13	484	3191369	dba_user	dba_user	DELETE FROM "cron"."job_run_details" WHERE "end_time" < NOW() - INTERVAL '3 days'	succeeded	DELETE 5	2025-08-04 08:00:00.01492+07	2025-08-04 08:00:00.020318+07
12	485	3532278	dba_user	dba_user	REFRESH MATERIALIZED VIEW CONCURRENTLY public.MV_active_hardware_summary	succeeded	REFRESH MATERIALIZED VIEW	2025-08-05 04:00:00.024764+07	2025-08-05 04:00:00.117655+07
11	486	3545824	dba_user	dba_user	REFRESH MATERIALIZED VIEW public.activity_log_summary;	failed	ERROR:  relation "public.activity_log_summary" does not exist\n	2025-08-05 05:00:00.013643+07	2025-08-05 05:00:00.014312+07
6	487	3559525	dba_user	dba_user	SELECT cron.remote_vacuum();	succeeded	1 row	2025-08-05 06:00:00.017661+07	2025-08-05 06:00:07.5557+07
5	488	3559526	dba_user	dba_user	SELECT cron.remote_vacuum();	succeeded	1 row	2025-08-05 06:00:00.01679+07	2025-08-05 06:00:07.560148+07
13	489	3586622	dba_user	dba_user	DELETE FROM "cron"."job_run_details" WHERE "end_time" < NOW() - INTERVAL '3 days'	succeeded	DELETE 5	2025-08-05 08:00:00.019204+07	2025-08-05 08:00:00.024954+07
12	490	3962177	dba_user	dba_user	REFRESH MATERIALIZED VIEW CONCURRENTLY public.MV_active_hardware_summary	succeeded	REFRESH MATERIALIZED VIEW	2025-08-06 04:00:00.041479+07	2025-08-06 04:00:00.142003+07
11	491	3975699	dba_user	dba_user	REFRESH MATERIALIZED VIEW public.activity_log_summary;	failed	ERROR:  relation "public.activity_log_summary" does not exist\n	2025-08-06 05:00:00.016365+07	2025-08-06 05:00:00.017391+07
6	492	3989402	dba_user	dba_user	SELECT cron.remote_vacuum();	succeeded	1 row	2025-08-06 06:00:00.022699+07	2025-08-06 06:00:08.737715+07
5	493	3989403	dba_user	dba_user	SELECT cron.remote_vacuum();	succeeded	1 row	2025-08-06 06:00:00.025512+07	2025-08-06 06:00:08.741027+07
13	494	4016561	dba_user	dba_user	DELETE FROM "cron"."job_run_details" WHERE "end_time" < NOW() - INTERVAL '3 days'	succeeded	DELETE 6	2025-08-06 08:00:00.035011+07	2025-08-06 08:00:00.040196+07
12	495	96474	dba_user	dba_user	REFRESH MATERIALIZED VIEW CONCURRENTLY public.MV_active_hardware_summary	succeeded	REFRESH MATERIALIZED VIEW	2025-08-07 04:00:00.040957+07	2025-08-07 04:00:00.138469+07
11	496	110077	dba_user	dba_user	REFRESH MATERIALIZED VIEW public.activity_log_summary;	failed	ERROR:  relation "public.activity_log_summary" does not exist\n	2025-08-07 05:00:00.015569+07	2025-08-07 05:00:00.016983+07
6	497	123730	dba_user	dba_user	SELECT cron.remote_vacuum();	succeeded	1 row	2025-08-07 06:00:00.017409+07	2025-08-07 06:00:07.651859+07
5	498	123731	dba_user	dba_user	SELECT cron.remote_vacuum();	succeeded	1 row	2025-08-07 06:00:00.020115+07	2025-08-07 06:00:07.656091+07
13	499	150862	dba_user	dba_user	DELETE FROM "cron"."job_run_details" WHERE "end_time" < NOW() - INTERVAL '3 days'	succeeded	DELETE 5	2025-08-07 08:00:00.017207+07	2025-08-07 08:00:00.024641+07
\.


--
-- Data for Name: hardware_2; Type: TABLE DATA; Schema: dba; Owner: mis_user
--

COPY dba.hardware_2 (id, make, model, serial, os_name, os_version, type, ram, cpu, status, current, company_id, user_id, provaider_id, purchased_at, created_at, updated_at, deleted_at, note, max_con) FROM stdin;
3	10.170.53.29	BPM DB PRD	VIDHOPLINBPMDB1	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	64	4	0	t	1	1	1	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	148 GB	400
4	10.171.140.16	Payment Database PRD	VIDDCLXPNPHDB01-New	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	32	4	0	t	1	1	1	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	688 GB	400
5	10.170.53.56	Database Leads PRD	VIDDCLXPAOBDB05	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	31	36	0	t	1	1	4	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-11-28 10:44:23.000	\N	109 GB	400
6	10.170.53.57	Training PRD	VIDDCLXPAOBDB06	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	32	10	0	t	1	1	4	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-10-20 04:04:31.000	\N	109 GB	400
7	10.170.53.131	New ODS - PROD	VIDHOLXPODSDB01	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	160	16	0	t	1	1	1	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	997 GB	400
8	10.170.53.23	PRUForce DB PRD	VIDHOPLINAOBDB1	Red Hat 6.10 (RHEL)	(EnterpriseDB Advanced Server 14.13.1)	0	171	20	0	t	1	1	1	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-01-06 11:44:20.000	\N	1400 GB	400
9	10.171.84.55	SME omni PRD	VIDDCLXPSMEDB01	Red Hat 6.10 (RHEL)	PostgreSQL 14.13	0	31	24	0	t	1	1	4	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-03-20 11:29:37.000	\N	79 GB	400
10	10.171.84.56	SME Pruworks PRD	VIDDCLXPSMEDB02	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	23G	20	0	t	1	1	4	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-10-19 20:05:17.000	\N	217 GB	400
11	10.171.84.68	SME DB PRD	VIDDCLXPSMEDB04-new	Red Hat 6.10 (RHEL)	PostgreSQL 10.7 	0	19	6	0	t	1	1	4	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	 GB	400
12	10.170.53.101	nbwf,  DB Workflow PRD	VIDDCLXPAOBDB02	Red Hat  7.9  (RHEL)	(EnterpriseDB Advanced Server 14.13.1)	0	50	28	0	t	1	1	1	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-11-28 10:24:26.000	\N	892 GB	400
13	10.171.84.117	Magnum Pure PRD	VIDDCLXPMGPDB01	Red Hat  7.9  (RHEL)	(EnterpriseDB Advanced Server 9.6.2.7) 	0	16	16	0	t	1	1	1	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	571 GB	400
14	10.170.53.200	Corespondence DB PRD	VIDDCLXPCDSDB01	Red Hat (RHEL) 7.9	PostgreSQL 14.12	0	31	4	0	t	1	1	4	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-04-15 10:30:32.000	\N	443 GB	400
15	10.171.84.92	Postgre Enablement Tribe COMPLIANCE PRD	VIDDCLXPENTDB01	Red Hat 8.10 (RHEL)	PostgreSQL 14.12	0	15	4	0	t	1	1	4	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-05-05 08:38:54.000	\N	10 GB	400
16	10.170.53.108	Base DB PRD	VIDDCLXPBSEDB06	Red Hat 8.10 (RHEL)	PostgreSQL 14.12	0	62	8	0	t	1	1	4	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-04-14 14:10:21.000	\N	59 GB	400
17	10.171.84.100	AI DB PRD	VIDDCLXPAICDB01	Red Hat 6.10 (RHEL)	PostgreSQL 10.4	0	32	4	0	t	1	1	4	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	197 GB	400
18	10.170.53.147	Consolidate Database Server(XML) PRD	VIDHOWNPINTDB01	Windows Server 2016	SQL Server 2016	0	44	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-04-30 16:40:07.000	\N	Afdoli Fahmi \nowner Nanda widy	400
19	10.170.53.106	ODS PRD IDNPLAODSDB	VIDHOWNPODSDB01	Windows Server 2016	SQL Server 2016	0	64	4	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-07-17 16:57:15.000	\N	Afdoli Fahmi  IDNPLAODSDB	400
20	10.170.53.36	Internal DB (Moveit) PRD	VIDHOWNPINTDB02	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-02-14 10:30:13.000	\N	Afdoli Fahmi -- > moveitdmz Password09	400
21	10.170.48.98	Reporting DB SRSS PRD	VIDHOWNPREPDB01	Windows Server 2016	SQL Server 2016	0	32	4	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Afdoli Fahmi 	400
22	10.170.48.177	Database Solarwind, scom, SCCM PRD	SIDHOPWINIFRDB1	Windows Server 2016	SQL Server 2016	0	16	3	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-03-27 11:54:30.000	\N	Afdoli Fahmi , mis_user\nSQLAGTSVCPROD Password09	400
23	10.170.48.58	Internal DB - 03 PRD	VIDHOWNPINTDB03	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Afdoli Fahmi 	400
24	10.170.48.211	NICE DB PRD	VIDHOWNPNDSDB01	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Ridwan Royani	400
25	10.170.48.44	NICE DB PRD	VIDHOWNPNDSDB02	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Ridwan Royani	400
26	10.170.48.186	Ops Dashboard DB PRD	VIDHOWNPOPSDB01	Windows Server 2016	SQL Server 2016	0	8	2	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Afdoli Fahmi 	400
27	10.170.48.85	GPP Report PRD	SIDHOPWINMDB01	Windows Server 2016	SQL Server 2016	0	16	8	8	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-07-02 10:08:54.000	\N	Afdoli Fahmi GPP	400
28	10.170.48.112	Customer Analytic PRD	SIDHOPWINDALDB1	Windows Server 2016	SQL Server 2019	0	48	3	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-11-28 10:03:49.000	\N	Afdoli Fahmi \nHani Asri Guardiani	400
29	10.170.53.46	CRM Archive PRD	VIDHOWNPCRMDB03	Windows Server 2016	SQL Server 2016	0	24	4	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Victor Liliwidjaja	400
30	10.170.48.84	Reinsurance DB PRD	VIDHOWNPREIDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Fikrilsyah Algoumar	400
31	10.170.48.77	E-Submission NB PRD	VIDHOWNPXARDB01	Windows Server 2016	SQL Server 2016	0	8	2	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-02-10 11:13:44.000	\N	Nanda Widy	400
32	10.170.48.122	Sharepoint DB PRD	SIDHOPWINSHPDB1	Windows Server 2016	SQL Server 2016	0	16	8	8	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-02-27 11:54:03.000	\N	Syofianer Fitra	400
34	10.170.53.91	SUN GL PRD	SIDHOPWINSUNDB1	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Syofianer Fitra	400
35	10.170.53.187	New Actuary DB PRD	VIDHOWNPPRPDB01	Windows Server 2016	SQL Server 2016	0	64	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-03-27 08:19:59.000	\N	Salman Farizi \n260325->addcpu 2	400
36	10.170.53.68	CRM PRD	VIDHOWNPCRMDB02	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Victor Liliwidjaja	400
37	10.170.53.44	CRM PRD	VIDHOWNPCRMDB01	Windows Server 2016	SQL Server 2016	0	39	12	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Victor Liliwidjaja	400
38	10.170.53.105	DataMart PRD	VIDHOWNPDTMDB01	Windows Server 2019	SQL Server 2016	0	32	4	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-05-28 16:46:00.000	\N	Fikrilsyah Algoumar	400
39	 10.170.53.49	PG BCA PRD	VIDHOWNPH2BDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Bhimo Bhaskoro	400
40	10.170.53.153	OCR DB PRD	VIDDCWNPOCRDB01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Juliana	400
41	10.170.53.5	EPOS DB PRD	VIDHOPWINPOSDB1	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Afdoli Fahmi 	400
42	10.171.84.205	New IFRS  PRD	VIDDRWNPIFRDB01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Mimi Winata	400
43	10.171.84.215	Power BI PRD	VIDDCWNPPBIAP01	Windows Server 2016	SQL Server 2016	0	96	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Rizky Karunia	400
44	10.171.84.70	GreenPlum Master PRD	SIDDRLXPGPMAP01 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00.000	2024-07-01 08:00:00.000	2025-08-05 13:58:34.000	\N	Afdoli Fahmi , MIS\n/GPDB_DATA/master/gpseg-1/	400
45	10.171.84.71 	GreenPlum Second Master PRD	SIDDRLXPGPSAP01	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00.000	2024-07-01 08:00:00.000	2024-07-01 08:00:00.000	\N	Afdoli Fahmi , MIS	400
46	10.171.84.123	GreenPlum Node 1 PRD	SIDDRLXPGPNAP01	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00.000	2024-07-01 08:00:00.000	2024-07-01 08:00:00.000	\N	Afdoli Fahmi , MIS	400
47	10.171.84.124	GreenPlum Node 2 PRD	SIDDRLXPGPNAP02	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00.000	2024-07-01 08:00:00.000	2024-07-01 08:00:00.000	\N	Afdoli Fahmi , MIS	400
48	10.171.84.125	GreenPlum Node 3 PRD	SIDDRLXPGPNAP03 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00.000	2024-07-01 08:00:00.000	2024-07-01 08:00:00.000	\N	Afdoli Fahmi , MIS	400
49	10.171.84.126	GreenPlum Node 4 PRD	SIDDRLXPGPNAP04 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00.000	2024-07-01 08:00:00.000	2024-07-01 08:00:00.000	\N	Afdoli Fahmi , MIS	400
50	10.171.84.128 	GreenPlum Node 5 PRD	SIDDRLXPGPNAP05	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00.000	2024-07-01 08:00:00.000	2024-07-01 08:00:00.000	\N	Afdoli Fahmi , MIS	400
51	10.171.84.129	GreenPlum Node 6 PRD	SIDDRLXPGPNAP06	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00.000	2024-07-01 08:00:00.000	2024-07-01 08:00:00.000	\N	Afdoli Fahmi , MIS	400
52	10.171.84.104	BPM DB2 PRD	VIDDCLXPBPMDB01	Red Hat 6.10 (RHEL)	DB2 v10.5.0.3	0	58	8	0	t	1	1	1	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Afdoli Fahmi , MIS\nkill locking db2  	400
53	10.170.53.150	HPX DB2  PRD	VIDHOLXPHPEDB01	Red Hat  8.10  (RHEL)	DB2 v10.5.0.3	0	15	4	0	t	1	1	1	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-04-29 14:30:39.000	\N	Afdoli Fahmi , MIS, HPXDE	400
54	10.170.53.99	CM DB2 PRD	PRUIDWFCM02	AIX 7	DB2 v10.5.0.8	0	42	3	0	t	1	1	1	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Afdoli Fahmi , MIS \nkill locking db2  	400
56	10.170.53.14	MFPDATA DB2 PRD	VIDHOPLINIMFDB1	Red Hat (RHEL) 8.10	DB2 v11.5.8.0	0	62	8	0	t	1	1	1	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-11-05 10:52:32.000	\N	Afdoli Fahmi , MIS	400
57	10.171.82.73	UAT	sidhopwinvnxap1	Red Hat 6.10 (RHEL)	MySQL Database Server	0	31	8	0	t	1	1	1	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Afdoli Fahmi , MIS	400
58	10.170.49.144	UAT	vidhownuinsdb01	Windows Server 2012 R2	Oracle Database 11g Enterprise Edition	0	31	8	0	t	1	1	3	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-11-18 18:00:58.000	\N	Afdoli Fahmi , MIS\n.\\sqlagtsvcdev\nPassword09	400
59	10.170.49.107	UAT	viddrlxdatsap01	Red Hat 6.10 (RHEL)	Oracle Database 11g Enterprise Edition	0	31	8	0	t	1	1	1	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Afdoli Fahmi , MIS	400
60	10.171.83.52	DB Server SCCM Server PRD	viddcwnpscmap02	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Abdul Qahar	400
61	10.170.53.198	DB Server iCare & IVRDB PRD	vidhowpivrdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	unknow	400
62	10.170.48.37	DB Nice Server Playback Portal PRD	vidhownpnpsdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-12-02 15:35:03.000	\N	Ridwan Royani	400
63	10.170.48.101	DB Server New AWMS Server (Tower) PRD	viddcwnpawmap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-07-30 12:03:48.000	\N	Abdul Qahar MSSQL$FXAW mis_user	400
65	10.170.109.19	DB Server Q-Matic PRD	vidptwnpqmtap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Ridwan Royani	400
66	10.170.53.199	DB Server iCare & IVRDB PRD	viddrwpivrdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-06-19 14:56:10.000	\N	mis_user Password09	400
67	10.170.53.186	Is not DB Server PRD	vidhownpprpap02	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	unknow	400
68	10.170.48.63	Is not DB Server PRD	sidhopwinscmap1	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Taufik Ridwan	400
69	10.170.216.196	DB Server WINPAKPRO PRD	sidpcwnpacdap01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-07-16 17:51:06.000	\N	Fingerprint Tower	400
70	10.171.210.50	NICE Engage Unified PRD	siddrwnpneuap01	Windows Server 2016	no db	0	16	8	8	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-12-02 15:33:59.000	\N	Ridwan Royani	400
71	10.170.48.235	DB Server(NewSolarWins DB) PRD	vidhopwinifrdb1	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	unknow	400
72	10.170.216.69	DB Server FXAW PRD	vidpcwnpawmap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	unknow	400
73	10.170.53.185	Is not DB Server New Actuary Apps PRD	vidhownpprpap01	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Daniel Agustinus Rahardjo / Salman Farizi 	400
74	10.170.48.102	Decommissioning PRD	vidhownpintdb07	Windows Server 2016	SQL Server 2012	0	16	8	8	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	unknow	400
75	10.170.48.33	Decommissioning NICE  PRD	vidhownpndsdb03	Windows Server 2016	SQL Server 2012	0	16	8	8	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Ridwan Royani	400
76	10.170.48.128	DB Server SOLARWIN_ORION PRD	vidhopwinswdap1	Windows Server 2016	SQL EXPRESS 2017	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-07-22 14:12:49.000	\N	unknow	400
77	10.171.140.90	Is not DB Server ( No DB Service) PRD	viddcwnppbhap01	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Arif Hidayat Husni	400
82	10.143.17.6	smartclaim smartclaim PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00.000	2024-05-01 08:00:00.000	2024-05-01 08:00:00.000	\N	\N	400
96	10.143.34.5 	DB SCRM PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2022	0	16	8	0	t	1	1	2	2024-05-01 08:00:00.000	2024-05-01 08:00:00.000	2025-04-25 15:31:30.000	\N	1433  sqlserver/ua}T&-9[  simplecrm	400
97	10.141.48.131	STAGGING REMOTE SQL NRPD	service db cloud	Windows Server 2016 GCP	Client Cloud Remote Server	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	\N	400
101	10.170.52.70	PRD	VIDHOWNPSFSAP04	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00.000	2024-04-01 08:00:00.000	2024-09-01 08:00:00.000	\N	Upgrade Postgres v.8.3 to 14.3	400
102	10.170.52.28	NPRD	WINTEL	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00.000	2024-04-01 08:00:00.000	2024-09-01 08:00:00.000	\N	Upgrade Postgres v.8.3 to 14.3	400
104	10.170.48.110	NPRD	VIDHOLXPBAKAP01	Red Hat  8.10  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00.000	2024-04-01 08:00:00.000	2024-09-01 08:00:00.000	\N	Upgrade Postgres v.8.3 to 14.3	400
105	10.170.48.109	PRD	VIDHOLXPBAKAP02	Red Hat  7.9  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00.000	2024-04-01 08:00:00.000	2024-09-01 08:00:00.000	\N	Upgrade Postgres v.8.3 to 14.3	400
106	10.171.84.78	NPRD	VIDHOLXGBQMAP01	Red Hat  7.9  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00.000	2024-04-01 08:00:00.000	2025-03-20 08:53:44.000	\N	Upgrade Postgres v.8.3 to 14.3	400
107	10.171.213.79	NPRD	VIDDRLXUSMEAP04	Red Hat  8.1 (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00.000	2024-04-01 08:00:00.000	2024-09-01 08:00:00.000	\N	Upgrade Postgres v.10 to 14.3	400
108	10.170.49.150	NPRD	SIDHODLINFUSDB1	Red Hat  8.1  (RHEL)	PostgreSQL 15.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00.000	2024-04-01 08:00:00.000	2025-08-03 10:13:45.000	\N	Postgres v.10 to 14.3 | fuse DB  pruasia\\sqlagtsvcdev\nPassword09	400
109	10.170.49.191	NPRD	vidholdodsdb1	Red Hat  7.9  (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00.000	2024-04-01 08:00:00.000	2024-12-13 09:41:05.000	\N	Upgrade Postgres v.10 to 14.3 pruasia\\sqlagtsvcdev\nPassword09	400
110	10.171.212.215	PRD	VIDDRWNDNRSDB01	Windows Server 2016	SQL Server 2016 express SP3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	\N	Uninstal SQLEXPRESS	400
111	10.171.210.25	NPRD	VIDDRWNPCCVAP01	Windows Server 2016	SQL Server 2016 express SP3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	\N	Uninstal SQLEXPRESS	400
112	10.171.212.142	NPRD	viddcwndhpxap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	\N	\N	400
113	10.170.49.11	NPRD	VIDHOWNUPDCAP01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	2025-06-11 13:53:48.000	\N	SQLAGTSVCDEV  Password09	400
114	10.170.49.123	NPRD	SIDHOUWINSAPDB2	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	2024-11-11 13:43:00.000	\N	PRUASIA\\sqlagtsvcdev\nPassword09	400
115	10.170.49.188	NPRD	vidhodwinintdb1	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	\N	\N	400
117	10.170.49.196	NPRD	vidhownupacdb01	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	\N	Finger Print	400
118	10.170.49.197	NPRD	vidhowndeprap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	2025-03-25 17:39:18.000	\N	11	400
119	10.170.49.210	NPRD	vidhodwinintdb7	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	\N	Dev Moveit	400
120	10.170.49.216	NPRD	sidhouwinepvap1	Windows Server 2016	SQL Server 2016 SP 3	0	16,200	8	0	t	1	1	5	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	2025-05-04 16:18:45.000	\N	123	400
121	10.170.49.217	NPRD	vidhownuefmap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	2025-04-22 16:24:12.000	\N	AJI  E-FORM-APPS\n.\\sqlagtsvcdev  -> Password09	400
122	10.170.49.78	NPRD	sidhouwinepvdb1	Windows Server 2016	SQL Server 2016 SP 3	1	16	8	0	t	1	1	5	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	2025-03-25 17:39:00.000	\N	111	400
123	10.170.49.80	UAT	SIDHOUWINSFTP01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	2025-01-28 10:02:30.000	\N	Hanan	400
124	10.170.49.81 	NPRD	sidhodwinepvdb1	Windows Server 2012 R2 	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	\N	e-Payment Voucher	400
125	10.170.49.88 	NPRD	VIDHOWNUINTDB01	Windows Server 2019	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	\N	\N	400
126	10.170.216.100	PRD	SIDHOWNPCCVAP01	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	\N	Upgrade to 2016 SP 3	400
127	10.170.53.61	PRD	vidhownpcrmap03	Windows Server 2019 STD	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	\N	Microsoft SQL Server 2008 R2 	400
128	10.170.49.136	DBA_USER DEV	VIDDRLXUGBQDB01	Red Hat  8.10  (RHEL)	Postgres 16.0	0	125GB	32	0	t	1	1	4	2024-10-10	2024-10-10 21:31:41.000	2024-10-10 21:31:41.000	\N	DEV NEW Postgres 16 | dba_user dba_user | 5432 | owner | Radit	400
129	10.171.86.72	NBWF UAT	VIDDRLXUMSCDB01	Red Hat  7.9  (RHEL)	(EnterpriseDB Advanced Server 14.13.1)	0	15	8	0	t	1	1	4	2024-10-12	2024-10-12 16:31:46.000	2025-08-05 13:53:56.000	\N	SR02701142	400
130	10.171.211.50	DR GP	SIDDCLXPGPMAP01	Red Hat 6.10 (RHEL)	Greenplum Node Master	0	252	8	0	t	1	1	2	2024-02-01 08:00:00.000	2024-02-01 08:00:00.000	2024-02-01 08:00:00.000	\N	Afdoli Fahmi	400
131	10.171.211.51	DR GP	SIDDCLXPGPSAP01	Red Hat 6.10 (RHEL)	Greenplum Node Standby	0	252	8	0	t	1	1	2	2024-02-01 08:00:00.000	2024-02-01 08:00:00.000	2024-02-01 08:00:00.000	\N	Afdoli Fahmi	400
132	10.171.211.123	DR GP	SIDDCLXPGPNAP01	Red Hat 6.10 (RHEL)	Greenplum Node 1	0	252	8	0	t	1	1	2	2024-02-01 08:00:00.000	2024-02-01 08:00:00.000	2024-02-01 08:00:00.000	\N	Afdoli Fahmi	400
133	10.171.211.124	DR GP	SIDDCLXPGPNAP02	Red Hat 6.10 (RHEL)	Greenplum Node 2	0	252	8	0	t	1	1	2	2024-02-01 08:00:00.000	2024-02-01 08:00:00.000	2024-02-01 08:00:00.000	\N	Afdoli Fahmi	400
134	10.171.211.125	DR GP	SIDDCLXPGPNAP03	Red Hat 6.10 (RHEL)	Greenplum Node 3	0	252	8	0	t	1	1	2	2024-02-01 08:00:00.000	2024-02-01 08:00:00.000	2024-02-01 08:00:00.000	\N	Afdoli Fahmi	400
135	10.171.211.126	DR GP	SIDDCLXPGPNAP04	Red Hat 6.10 (RHEL)	Greenplum Node 4	0	252	8	0	t	1	1	2	2024-02-01 08:00:00.000	2024-02-01 08:00:00.000	2024-02-01 08:00:00.000	\N	Afdoli Fahmi	400
136	10.171.211.127	DR GP	SIDDCLXPGPNAP05	Red Hat 6.10 (RHEL)	Greenplum Node 5	0	252	8	0	t	1	1	2	2024-02-01 08:00:00.000	2024-02-01 08:00:00.000	2024-02-01 08:00:00.000	\N	Afdoli Fahmi	400
137	10.171.211.128	DR GP	SIDDCLXPGPNAP06	Red Hat 6.10 (RHEL)	Greenplum Node 6	0	252	8	0	t	1	1	2	2024-02-01 08:00:00.000	2024-02-01 08:00:00.000	2024-02-01 08:00:00.000	\N	Afdoli Fahmi	400
138	10.170.49.179	DR GP	VIDHOLXDGPMAP02 	Red Hat 8.10 (RHEL)	Postgres 16.0	0	62	24	0	t	1	1	2	2024-02-01 08:00:00.000	2024-02-01 08:00:00.000	2025-07-02 14:21:44.000	\N	Arif Rahman  - Postgres + mis_user padmin password_09 root today123	400
139	10.170.49.180	GP DEV	VIDHOLXDGPNAP03	Red Hat Enterprise Linux 	Greenplum Node 4.3.33	0	62G	24	0	t	1	1	4	2024-10-22	2024-10-22 18:35:26.000	2024-10-22 20:21:47.000	\N	VIDHOLXDGPNAP03	400
140	10.170.49.181	GP DEV	VIDHOLXDGPNAP04	Red Hat Enterprise Linux 	Greenplum Node 4.3.33	0	62G	24	0	t	1	1	4	2024-10-22	2024-10-22 20:11:06.000	2024-10-22 20:22:04.000	\N	VIDHOLXDGPNAP04	400
141	10.170.49. 	DBA_USER DEV	VID	Red Hat Enterprise Linux 	(EnterpriseDB Advanced Server 14.13.1)	0	62G	24	0	t	1	1	4	2024-10-22	2024-10-22 20:18:04.000	2024-10-23 07:15:51.000	\N	10.170.49.180	400
142	10.170.49.168	ON PREM ESUB NEWODS AOB UAT	VIDHOLXUINTDB02	Red Hat  8.1  (RHEL)	PostgreSQL 15.13	0	15	8	0	t	1	1	4	2024-10-23	2024-10-23 10:43:56.000	2025-08-03 10:13:15.000	\N	 	400
143	10.171.84.154	ICN DB2 PRD	VIDDCLXPICNDB01	Red Hat (RHEL) 8.10	DB2 v11.5.8.0	0	7.5 GB	2	0	t	1	1	1	2024-11-05 10:00:00.000	2024-11-05 10:58:11.000	2024-11-05 10:58:11.000	\N	Afdoli Fahmi , MIS	400
145	10.170.53.202	TRIAL DB SQL SERVER	TRIAL	WINDOWS 2012 R2	SQL Server 2022	0	16	8	9	t	1	1	5	2024-11-13	2024-11-13 07:52:19.000	2024-11-13 07:52:27.000	\N	10.170.53.202\n.\\admintemp\nPassword09	400
148	10.143.27.236	Cloud INTUATDB PRD	IDLIFED4VZP1CVI	Ubuntu 20	SQL Server 2019	0	6	2	0	t	1	10	1	2024-12-17 10:00:00.000	2024-12-17 16:00:37.000	2025-02-06 09:45:15.000	\N	    "private_address": "10.143.27.236",\n    "root_password": "+}CGp[@-"\n}\nuser sqlserver	400
149	10.170.109.42	Server Recording ACRA  PRD	VIDPTWNPACRAP01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	1	2025-01-14	2025-01-14 09:07:24.000	2025-01-14 09:07:37.000	\N	Login : VIDPTWNPACRAP01\\pruadmin\nPassword : P@ssw0rd\nVIDPTWNPACRAP01	400
151	10.171.84.73	VIDDCLXPGA PRD	VIDDCLXPGA	Red Hat Enterprise Linux 	Postgres 14.0	0	8	2	0	t	1	1	2	2025-02-06	2025-02-06 14:44:55.000	2025-02-06 14:44:55.000	\N	VIDDCLXPGA	400
152	10.170.53.78	ORACLE PRD	VIDHOWNPINSDB01	WINDOWS 2012 R2	Oracle 11g Windows	0	32	8	0	t	1	1	3	2025-02-21	2025-02-21 15:02:20.000	2025-02-21 15:02:20.000	\N	CREATE USER mis_user IDENTIFIED BY Password09;	400
153	10.170.48.190	DCI CFS PRD	VIDHOWPCFSAP1	WINDOWS 2012 R2	Microsoft SQL Server 2012	0	8	4	0	t	1	1	1	2025-02-26	2025-02-26 15:31:15.000	2025-02-26 15:31:15.000	\N	Henry Lois Sumendap	400
156	10.171.211.16	DB2 - DEV	PRUIDWFCM02	AIX 2	DB2 AIX	0	8	8	0	t	1	1	2	2025-04-25	2025-04-25 11:18:31.000	2025-04-25 14:22:08.000	\N	   test	400
158	10.170.53.132	PROD	vidholxpodsdb02	Red Hat 8.10 (RHEL)	EDB 14.12	0	168	26	0	t	1	1	1	2025-04-30	2025-04-30 14:56:44.000	2025-05-06 13:29:11.000	\N	padmin	400
161	10.143.17.22	DEV DBA_USERx	10.143.17.22	CLOUD SQL	Postgres 9.0	0	16	8	0	t	1	1	2	2025-05-21	2025-05-21 14:02:27.000	2025-05-21 14:02:27.000	\N	pw: lAb43za16dHCMWbTpOFqV3tNJXi449rL\nu: postgres	400
164	10.170.52.68	SHARE PROD	10.170.52.68	WINDOWS 2016	Postgres 8.3	0	24	8	0	t	1	1	1	2025-05-27	2025-05-27 14:35:12.000	2025-05-27 14:38:46.000	\N	IPS_Prundetial	400
165	10.170.52.70	SHARE PROD	10.170.52.70	WINDOWS 2012	Postgres 15.13	0	8	8	0	t	1	1	1	2025-05-27	2025-05-27 14:37:44.000	2025-05-28 16:48:19.000	\N	88	400
166	10.143.17.10	REDSOFT	INVESTMEN	CLOUD SQL	Microsoft SQL Server 2019	0	16	8	0	t	1	1	1	2025-06-03	2025-06-03 15:19:47.000	2025-06-03 15:19:47.000	\N	IP : 10.143.17.10\nUsername : sqlserver\nPassword : ceJym<Le	400
167	10.170.49.251	NRPD	VIDHOLXUINTDB01	Red Hat 7 (Rhell)	PostgreSQL 14.12	0	15	8	0	t	1	1	2	2025-06-17	2025-06-17 11:37:25.000	2025-06-17 11:37:25.000	\N	10.170.49.251	400
168	10.170.49.211	DEV NRPOD	VIDHOWNUSFSAP02	Windows Server 2016	PostgreSQL 16.9	0	16	4	0	t	1	1	1	2025-06-23	2025-06-23 15:39:00.000	2025-07-03 09:25:06.000	\N	PostgreSQL 16.9\nPRUASIA\\SQLAGTSVCDEV  \nJ4k@rta21	400
169	10.143.17.96	pruhub3-a2202659	c5fzh0	asia-southeast2	POSTGRES_9_6	0	38	1	0	t	1	1	4	2025-07-02	2025-07-02 13:28:37.000	2025-07-02 14:38:47.000	\N	    "default_password": "UQTjnEpIOucHfEKaHHA8fDE2578DiXCu",\n    "default_username": "postgres",	400
170	10.171.84.145	clone 92	VIDDCLXPENTDB01T	Red Hat 8.10 (RHEL)	Postgres 15.0	0	19	4	0	t	1	1	1	2025-07-16	2025-07-16 16:51:47.000	2025-07-16 16:51:47.000	\N	padmin/Password09 root/today123	400
171	10.143.34.54	PROD fhsl34 pmnwf-new2-6a194f8d	nbwf	CLOUD	PostgreSQL 9.6.24 	PMN DB	12	24	0	t	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Nanda Widi {"password":"4AOT1weD-2-uEotf","username":"nbwf-svc"} 	400
172	10.143.34.5	PROD pxz32v crm-prod-4d1f4c46	CRM	CLOUD ubuntu linux 20.04 LTS	SQLSERVER 2022 STD	SCRM	32	32	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Salman Farizi user/pas : sqlserver/ua}T&-9[ 	400
173	10.143.27.253	UAT w89lzu jatisdev-c9a15088	jatisSMS (Cloud Instance)	CLOUD (Cloud Instance)	SQLSERVER 2019 ENTERPRISE	jatisSMS (Cloud Instance)	4	16	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Aji user/pass: sqlserver/Svu72BhZ 	400
174	10.143.34.237	PROD s16gul pruhub3-168cfd2c	pruhub	CLOUD	PostgreSQL 9.6.24	pruhub	4	8	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	 password:"v1CtdwHkyX@7RYi8","username":"dba_user" / default_username":"PostgreSQL " "default_password":"BfvuoYlNmX0XRDY4hPHyCh2bTzE244Do" 	400
175	10.143.17.91	UAT ss5reu pmnwf-new-1b3665f1	pmnwf	CLOUD	PostgreSQL 9.6.24	PMN DB	1	4	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Fajar Tri nbwf-svc/Yosm@fY$EcZeF6WE 	400
176	10.143.17.92	UAT lo943j viddrlxddgpap01db-new-d5f22d10	\N	Red Hat Enterprise Linux 	PostgreSQL 16.9 	\N	4	4	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	viddrlxddgpap01db-new-d5f22d10 "default_password": "15d78c3d849493ee",\n "default_username": "digitalpg",	400
177	10.143.17.17	DEV tylzpr mis-api-bc543eee	mis-api	CLOUD	PostgreSQL 16.8 	mis-api	4	8	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	 PostgreSQL /mKvfzOHMGKiZ6uvH7g5qd8EP3Nyrtwfb 	400
178	10.143.17.16	DEV tylzpr mis-newods-37aa20f8	mis-newods	CLOUD	PostgreSQL 16.8 	mis-newods	4	6	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	 PostgreSQL /9QLP2ubRW6FENboO0H7arWr5vq91GJ1S 	400
179	10.143.34.234	PROD q6ec67 magnumpuredb-08fea2c0	magnumpure	CLOUD	PostgreSQL 15.10 	MagnumPure	16	16	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Odianto user/pas : PostgreSQL /ikGIgklikmFjNxWf0hVq4oNVZNXlWlVB 	400
180	10.143.17.126	UAT wyaxkx magnumpuredb-f1c22de1	magnumpure	CLOUD	PostgreSQL 15.10 	MagnumPure	1	4	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Odianto PostgreSQL /baf78c6b70be36ee  ALTER USER prumagnumpure WITH PASSWORD 'cNA4-K/C2VZ3Wh!!';\n5432	400
181	10.143.34.101	PROD m6amcz pap-f0099a49	PAP	CLOUD	PostgreSQL 14.12 	PAP	4	6	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Marantika user/pas : postgres/xIqL6MHtPJWYA1OjaPaW4n9UM844LYdF	400
182	10.143.34.70 	PROD m6amcz psa-25bc426c	PSA	CLOUD	PostgreSQL 14.12 	PSA	4	6	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Dede P user/pas : PostgreSQL /bFAyEyz383ITMZ8MHImEfAnDzKZSTO74 	400
183	10.143.17.29	UAT wsjs97 edocpg-0db5bf0e	edoc	UBUNTU 10,22 GCP	PostgreSQL 13.21 	edoc (cloud_Instance)	2	5	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Benny Setiawan user/pass: "PostgreSQL "/"o1Gy1WbqQ3DZcTt4hyVGzkCzEHnFEKxb" user/pass:"edocplai"/"U0Y42h8mngzu-D8@"	400
184	10.143.34.199	PROD s3rcg0 apidb-e2626704	apidb	CLOUD	PostgreSQL 13.20 	apidb	8	16	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Syatria Babullah PostgreSQL /BCddZ3lIoxsgMqEd7Un2gB1JcMT7SFsx 	400
185	10.143.17.197	UAT pdf47h apidb-f000bac2	apidb	CLOUD	PostgreSQL 13.20 	apidb	4	8	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	password":"JqoNbmc/hgQud4wP",\n"username":"dev-svc" postgres/Ku6u6mpGsBplAeyeiiG28P8J3gDUk63o	400
186	10.143.34.226	PROD s3rcg0 oltp-5b56f831	oltp	CLOUD	PostgreSQL 13.13	oltp	8	16	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Syatria Babullah "oltp-svc"/"KT3meM@r-BdEBF1p" 	400
187	10.143.17.6	PROD pw0vxt smartclaimpg-new-121e1fea	smartclaim	CLOUD	PostgreSQL 12.16	smartclaim	1	4	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	  	400
189	10.143.17.96	DEV c5fzh0 pruhub3-a2202659	\N	CLOUD	PostgreSQL  9 6	\N	1	4	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	 PostgreSQL /UQTjnEpIOucHfEKaHHA8fDE2578DiXCu  dba_user/91s7tmqQzPt$@65-  pruhub_user/j-UESCT26jXXAR-! 	400
190	10.143.34.58	PROD fhsl34 pmnwf-new2-6a194f8d-replica001	PMN DB Replica	CLOUD	PostgreSQL  9 6	PMN DB Replica	12	24	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Fajar Tri  	400
191	10.141.23.11	UAT c5wvjk idlifec5wvjknuf	Renova_Individual	CLOUD	SQLSERVER  2017 STD	Renova (Cloud VM)	8	64	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Kris Ginting user/pass: renovaid/Password12 sa/Password09	400
192	10.143.17.32	DEV lgtk7w pruforce-5c930018	Pruforce Dev	CLOUD	PostgreSQL  16	Pruforce Dev	1	4	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	  	400
193	10.143.27.7	DEV w89lzu mitracomdev-3dbd2351	Mitracom	CLOUD	SQLSERVER 2019 ENTERPRISE	Mitracom	4	16	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	  	400
194	10.143.34.112	PROD cq4b9l consolidate-db	Consolidate DB	CLOUD	SQLSERVER 2019 ENTERPRISE	Consolidate DB	8	45	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	  	400
195	10.143.34.111	PROD cq4b9l internal-db	Internal DB (HR)	CLOUD	SQLSERVER 2019 ENTERPRISE	Internal DB (HR)	4	20	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	  	400
196	10.143.34.200	PROD i7e7oy newpruworks	Pruworks	CLOUD	SQLSERVER 2019 ENTERPRISE	Pruworks	8	49	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	  	400
197	10.143.17.8	DEV xdh57h radsoftdb	Radsoft dev	CLOUD	SQLSERVER 2019 ENTERPRISE	Radsoft dev	4	16	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	  	400
198	10.143.27.236	UAT h7xg8d pruworks-nprd-1bf475b2	Pruworks UAT	CLOUD	SQLSERVER 2019 ENTERPRISE	Pruworks UAT	4	24	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	  	400
199	10.143.27.57	UAT r9vnma crm-nprd-1ccd6221	CRM	CLOUD ubuntu linux 20.04 LTS	SQLSERVER 2022 STD	SCRM	2	9	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Salman Farizi user/pas : sqlserver/vA:sX3d@ 	400
201	10.143.34.206	PROD o35gws smartclaimpg-b9476f39-replica001	smartclaim	CLOUD	PostgreSQL 12.16	smartclaim (replica)	4	16	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	  	400
202	10.143.34.202	PROD o35gws smartclaimpg-b9476f39	smartclaim	CLOUD	PostgreSQL 12.16	smartclaim (master)	4	15	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	"password": "nl!rWHX@vSojmUbn",\n"username": "op-svc"\n\n"password": "rh1mTEj!U23pd6$5",\n  "username": "dba-user"\n\n"password": "rp@o73p6-knfv$lC",\n "username": "release-user"	400
203	10.143.34.42	PROD cmb6ze onepulsepg-60317328	onepulse	CLOUD	PostgreSQL 12.16	One Pulse Platform	2	7	0	t	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Benny Setiawan  	400
204	10.143.17.10	UAT p82cwr radsoftdbuat	Prudential	CLOUD	SQLSERVER 2019 ENTERPRISE	radsoft	4	16	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Kris Ginting sqlserver/ceJym<Le 	400
205	10.143.27.238	DEV r9vnma crm-reporting-nprd-5ca264f8	CRM Reporting UAT	Ubuntu 20.04	SQL Server 2022 ENTERPRISE	CRM Reporting UAT	1	4	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	sqlserver\n\n@78$hZ!L	400
206	10.143.34.109	PROD pxz32v crm-reporting-prod-4b5c8140	CRM Reporting	CLOUD	SQLSERVER 2019 ENTERPRISE	CRM Reporting	8	16	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	  	400
207	10.143.17.69	UAT qdunle psa-a83c68ff	PSA	UBUNTU 10,22 GCP	PostgreSQL 14.12 	PSA	1	3	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Dede P user/pas : PostgreSQL /AmZsWOWWl949v3lAtKMJeT9AVAqlBbHu 	400
208	10.143.34.223	DEV jjnvha edocpg-c18592f8	edoc	CLOUD	PostgreSQL 12.16	edoc (cloud_Instance)	2	4	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Benny Setiawan user/pass: "PostgreSQL "/"agG0nkLGOCphBdCwsUD5Cd1B8W0TmADT" user/pass: "edocplai"/"IOSBQgiK6hOiEvu-"	400
209	10.143.17.121	UAT eawwbd onepulseplatpg-1a3b455f	\N	CLOUD	PostgreSQL  16	\N	1	4	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	 PostgreSQL /b9b4cf99149f76d2 	400
210	10.143.17.88	DEV m9wvmh onepulseplatform-8ec602c4	\N	asia-southeast2	PostgreSQL  12	\N	1	4	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	 PostgreSQL /e4f88211cf99b3e7 	400
211	10.143.34.26	PROD babq79 digitalpartner-new-6d79c8d4	Digital Partner	CLOUD	PostgreSQL  12	Digital Partner	4	8	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Herdianto  	400
212	10.143.21.8	UAT gyy08m dbedoc-node-0	edoc	UBUNTU 10,22 GCP	PostgreSQL 12.16	edoc (cloud_VM)	1	1	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Benny Setiawan user/pass: edocplai/edoc2022 	400
213	10.143.36.140	DEV pfpbtb edoc (cloud_VM) edoc PRD	edoc	CLOUD	PostgreSQL 12.16	edoc (cloud_VM)	1	1	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Benny Setiawan user/pass: edocplai/edoc2022 	400
214	10.143.17.202	UAT fynu69 phsdb-f2775ab1	PHS	CLOUD	PostgreSQL  14	PHS	1	4	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	  	400
215	10.143.34.60	PROD krenc4 dqs-0d921dad	DQS	CLOUD	PostgreSQL  14	DQS	2	6	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	 	400
216	10.143.17.86	DEV yw4ncv dqs-21dddb1e	DQS Dev	CLOUD	PostgreSQL  14	DQS Dev	1	4	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	  	400
217	10.143.34.106	PROD asne4l pruforce-3f630c90	Pruforce	CLOUD	PostgreSQL  16	Pruforce	2	8	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	  	400
218	10.141.12.7	PROD DigiService DigiService	DigiService	CLOUD	PostgreSQL 10.6	\N	2	4	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	 PostgreSQL /Password09 	400
219	10.143.17.193	UAT pdf47h misdb-252a6e7d	mis-db uat	CLOUD Red Hat Enterprise Linux 	PostgreSQL  13	mis-db uat	2	6	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	  "username":"dev-svc"\n"password":"n@WXnqZHwNZg7/td"\n"username":"dev-user"\n"password":"/vSwLnEYYDul8P!G"\n"password":"nog1-ePSZ/vgrL7-","username":"dev-ro"	400
220	10.143.34.230	PROD s3rcg0 oltp-5b56f831-replica001	OLTP Prod	CLOUD	PostgreSQL  13	OLTP Prod	8	16	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	  	400
221	10.143.34.23	PROD o7pm17 datalake01-8b1c79f9	Datalake	CLOUD	PostgreSQL  13	Datalake	8	32	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	  	400
222	10.143.17.95	DEV c5wvjk datalake-new-5d7890fa	Datalake Dev	CLOUD	PostgreSQL  13	Datalake Dev	2	8	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	  	400
1	10.170.53.102	AOB DB ESUB PRD	VIDDCLXPAOBDB03	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.2.7	0	32	4	0	t	1	1	1	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	814 GB	400
2	10.170.53.103	AOB EPOLICY DB (WAB,Fuse)  PRD	VIDDCLXPAOBDB04	Red Hat  7.9  (RHEL)	EnterpriseDB 14.13	0	46	20	0	t	1	1	1	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-05-28 15:06:28.000	\N	200 GB DISK --- NIDLIFEAPPSUP ada versi 14 UP	400
33	10.170.48.215	K2 DB server PRD	VIDHOWNPKTWDB01	Windows Server 2016	SQL Server 2016	0	20	2	8	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2025-02-27 11:53:25.000	\N	Syofianer Fitra	400
55	10.171.84.43	RESDB DB2 PRD	VIDDCLXPODMDB01	Red Hat  7.9  (RHEL)	DB2 v10.5.0.3	0	31	4	0	t	1	1	1	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	\N	Afdoli Fahmi , MIS  \n user SPLAIODM pass: Password09 di ip\n10.171.84.43 (BRMS)	400
64	10.170.48.35	DB Server Sentinel  PRD	vidhownpnmsap02	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00.000	2024-08-01 08:00:00.000	2024-12-02 15:35:36.000	\N	Ridwan Royani, Manage by Nice Vendor	400
103	10.170.53.114	NPRD	vidhownp2faap01 	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00.000	2024-04-01 08:00:00.000	2024-09-01 08:00:00.000	\N	Upgrade Postgres v.8.3 to 14.3	400
116	10.170.49.195	NPRD	vidhowndefmdb01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	2024-06-01 08:00:00.000	\N	\N	400
146	10.143.34.85	newpruworks PRD	pruidlife-prod	CLOUD SQL  SVR	PostgreSQL 15.8	0	16	8	0	t	1	1	5	2024-11-19	2024-11-19 13:53:08.000	2024-11-19 14:30:32.000	\N	 "default_password": "\\u003cM?WuPtb",\n  "default_username": "pruuser", "root_password": "K2b\\u003ej1ly"	400
150	10.170.49.73	UAT 	VIDDCLXDGAIAPP01	Red Hat Enterprise Linux 	Postgres 14.0	0	16	23	0	t	1	1	4	2025-02-06	2025-02-06 14:38:58.000	2025-02-06 14:38:58.000	\N	VIDDCLXDGAIAPP01	400
160	10.143.34.237	pruhub3-168cfd2c	s16gul	CLOUD SQL	PostgreSQL 9	0	16	8	0	t	1	1	1	2025-05-14	2025-05-14 09:13:32.000	2025-07-21 11:26:51.000	\N	[{"password":"v1CtdwHkyX@7RYi8","username":"dba_user"},\n{"password":"9TKYrP$8kU15Ny-O","username":"pruhub_user"},\n{"password":"N/TdoFP@ey0nwRWP","username":"service_user"}]	400
188	10.141.19.86	UAT el8fvd PostgreSQL -digiservice (gke)	PostgreSQL 	CLOUD	PostgreSQL 10.6 	\N	1	2	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Fajar Tri PostgreSQL /P@ssw0rd 	400
200	10.143.34.79	PROD syxuqi renovadb2-aaf0f976  (Cloud Instance) Renova_Individual PRD	Renova_Individual	CLOUD	SQLSERVER 2019 STD	Renova (Cloud Instance)	4	16	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Kris Ginting user/pass: renovadb/5J+a]OlQ user/pass: "sqlserver"/"XpIeX_N&"	400
223	10.141.15.39	PROD wwe3r3 idlifewwe3r3jbi	SUN	CLOUD	SQLSERVER  2016 STD	SUN Payment	8	32	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Salman Farizi sun.dbadmin  Password09	400
224	10.141.15.36	PROD wwe3r3 idlifewwe3r3bcp	TLM	CLOUD	SQLSERVER  2016 STD	TLM Payment	8	32	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Salman Farizi user : SRVPLAIPRTLMSMARTS01 Password : Q42PDxA(	400
225	10.143.34.36	STAGGING j5toic mitracommprd-1a1636b9	smsgw_prod	CLOUD SQL UBUNTU 20	SQLSERVER 2019 STD	mitracom	4	16	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Aji  "default_password":"D<1n=j}K",\n "default_username":"mitracommadm",\n "root" d6fs4NeX" 	400
226	10.141.23.9	DEV c5wvjk win1-c5wvjk-001	ifrs17	CLOUD	SQLSERVER 2019 STD	Ifrs17 (cloud_VM)	10	32	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Agam Adhinegara user/pass: sa/Password09 user/pass : PRUASIA\\407409\tWindows_autentication (superuser)	400
227	10.143.34.120	PROD babq79 pruservices-b6414432	Pruservices	CLOUD	PostgreSQL  16	Pruservices	4	8	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	  username: operation_user_prd | password: p+FNaj+34-49{H1J{>9!\n    "password": "ylsaTGbqz!ZcV8@H",\n    "username": "operation_user_prd"	400
228	10.143.17.59	DEV pdf47h keycloackdb-0ad4bfd6	keycloack	UBUNTU 10,22 GCP	PostgreSQL 13.15	keycloack	4	8	0	f	1	1	1	2025-08-05	2025-08-05	2025-08-05	\N	Syatria Babullah user/pas: "PostgreSQL "/d5iv2cp2t2LmRfIXECtypk1JBh71r7bl	400
\.


--
-- Data for Name: activity_log; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.activity_log (id, log_name, description, subject_type, subject_id, causer_type, causer_id, properties, created_at, updated_at, event, batch_uuid) FROM stdin;
867	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.192","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-16 07:24:58	2025-06-16 07:24:58	Login	\N
868	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.171.225.220","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-16 13:48:57	2025-06-16 13:48:57	Login	\N
869	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.98.231","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-17 07:42:24	2025-06-17 07:42:24	Login	\N
870	Resource	Hardware Created by Harys 	App\\Models\\Hardware	180	App\\Models\\User	3	{"make":"10.170.49.251","model":"NRPD","serial":"VIDHOLXUINTDB01","status":"0","os_name":"Red Hat 7 (Rhell)","os_version":"PostgreSQL 14.12","ram":"15","cpu":"8","type":"0","user_id":3,"provaider_id":"2","purchased_at":"2025-06-17 00:00:00","note":"10.170.49.251","company_id":1,"updated_at":"2025-06-17 11:37:25","created_at":"2025-06-17 11:37:25","id":180}	2025-06-17 11:37:25	2025-06-17 11:37:25	Created	\N
871	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	180	App\\Models\\User	3	{"user_id":"1"}	2025-06-17 11:37:25	2025-06-17 11:37:25	Updated	\N
872	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.17","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-18 09:12:34	2025-06-18 09:12:34	Login	\N
873	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.41","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-19 09:31:10	2025-06-19 09:31:10	Login	\N
874	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	67	App\\Models\\User	3	{"updated_at":"2025-06-19 14:56:10","note":"mis_user Password09"}	2025-06-19 14:56:10	2025-06-19 14:56:10	Updated	\N
875	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.96.24","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-20 07:53:25	2025-06-20 07:53:25	Login	\N
876	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.97.74","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-20 15:16:12	2025-06-20 15:16:12	Login	\N
877	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.98.129","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-21 17:34:50	2025-06-21 17:34:50	Login	\N
878	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.96.111","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-22 05:58:57	2025-06-22 05:58:57	Login	\N
879	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.191","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-22 15:26:13	2025-06-22 15:26:13	Login	\N
880	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.17","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-23 07:33:22	2025-06-23 07:33:22	Login	\N
881	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.17","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-23 15:37:08	2025-06-23 15:37:08	Login	\N
882	Resource	Hardware Created by Harys 	App\\Models\\Hardware	181	App\\Models\\User	3	{"make":"10.170.49.211","model":"DEV NRPOD","serial":"VIDHOWNUSFSAP02","status":"0","os_name":"Windows Server 2016","os_version":"PostgreSQL 14.12","ram":"16","cpu":"4","type":"0","user_id":3,"provaider_id":"1","purchased_at":"2025-06-23 00:00:00","note":"POSTGRES 14","company_id":1,"updated_at":"2025-06-23 15:39:00","created_at":"2025-06-23 15:39:00","id":181}	2025-06-23 15:39:00	2025-06-23 15:39:00	Created	\N
883	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	181	App\\Models\\User	3	{"user_id":"1"}	2025-06-23 15:39:00	2025-06-23 15:39:00	Updated	\N
884	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.96.19","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-23 23:03:10	2025-06-23 23:03:10	Login	\N
885	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.98.194","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-24 08:16:32	2025-06-24 08:16:32	Login	\N
886	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.98.51","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-25 06:28:58	2025-06-25 06:28:58	Login	\N
887	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.98.51","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-25 14:57:28	2025-06-25 14:57:28	Login	\N
888	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.98.56","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-26 08:24:29	2025-06-26 08:24:29	Login	\N
889	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.244","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-27 06:31:28	2025-06-27 06:31:28	Login	\N
890	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.96.160","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-27 20:53:04	2025-06-27 20:53:04	Login	\N
891	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.97.184","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-29 06:29:37	2025-06-29 06:29:37	Login	\N
892	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.97.184","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/137.0.0.0 Safari\\/537.36 Edg\\/137.0.0.0"}	2025-06-29 10:58:26	2025-06-29 10:58:26	Login	\N
893	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.202","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-06-29 23:39:46	2025-06-29 23:39:46	Login	\N
894	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.170.92.66","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-06-30 08:13:34	2025-06-30 08:13:34	Login	\N
895	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.98.172","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-01 07:43:40	2025-07-01 07:43:40	Login	\N
896	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.98.172","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-01 14:50:58	2025-07-01 14:50:58	Login	\N
897	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.98.172","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-01 18:02:22	2025-07-01 18:02:22	Login	\N
898	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.170.93.109","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-02 10:00:39	2025-07-02 10:00:39	Login	\N
899	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	27	App\\Models\\User	3	{"status":"8","updated_at":"2025-07-02 10:08:54","note":"Afdoli Fahmi GPP"}	2025-07-02 10:08:54	2025-07-02 10:08:54	Updated	\N
900	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.170.92.240","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-02 10:09:26	2025-07-02 10:09:26	Login	\N
901	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.170.92.240","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-02 13:24:23	2025-07-02 13:24:23	Login	\N
902	Resource	Hardware Created by Harys 	App\\Models\\Hardware	182	App\\Models\\User	3	{"make":"10.143.17.96","model":"POSTGRES_9_6","serial":"c5fzh0","status":"0","os_name":"pruhub3-a2202659","os_version":null,"ram":"16","cpu":"8","type":"0","user_id":3,"provaider_id":"4","purchased_at":"2025-07-02 00:00:00","note":"asia-southeast2","company_id":1,"updated_at":"2025-07-02 13:28:37","created_at":"2025-07-02 13:28:37","id":182}	2025-07-02 13:28:37	2025-07-02 13:28:37	Created	\N
903	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	182	App\\Models\\User	3	{"user_id":"1"}	2025-07-02 13:28:37	2025-07-02 13:28:37	Updated	\N
904	Resource	Hardware Created by Harys 	App\\Models\\Hardware	183	App\\Models\\User	3	{"make":"10.143.17.121","model":"POSTGRES_12","serial":"eawwbd","status":"0","os_name":"POSTGRES_12","os_version":"POSTGRES_12","ram":"16","cpu":"8","type":"0","user_id":3,"provaider_id":"4","purchased_at":"2025-07-02 00:00:00","note":"onepulseplatpg-1a3b455f","company_id":1,"updated_at":"2025-07-02 13:29:56","created_at":"2025-07-02 13:29:56","id":183}	2025-07-02 13:29:56	2025-07-02 13:29:56	Created	\N
905	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	183	App\\Models\\User	3	{"user_id":"1"}	2025-07-02 13:29:56	2025-07-02 13:29:56	Updated	\N
906	Resource	Hardware Created by Harys 	App\\Models\\Hardware	184	App\\Models\\User	3	{"make":"10.143.17.88","model":"POSTGRES_12","serial":"m9wvmh","status":"0","os_name":"POSTGRES_12","os_version":"POSTGRES_12","ram":"16","cpu":"8","type":"0","user_id":3,"provaider_id":"4","purchased_at":"2025-07-02 00:00:00","note":"onepulseplatform-8ec602c4","company_id":1,"updated_at":"2025-07-02 13:30:55","created_at":"2025-07-02 13:30:55","id":184}	2025-07-02 13:30:55	2025-07-02 13:30:55	Created	\N
907	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	184	App\\Models\\User	3	{"user_id":"1"}	2025-07-02 13:30:55	2025-07-02 13:30:55	Updated	\N
908	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	182	App\\Models\\User	3	{"os_version":"POSTGRES_9_6","updated_at":"2025-07-02 13:31:19"}	2025-07-02 13:31:19	2025-07-02 13:31:19	Updated	\N
909	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	183	App\\Models\\User	3	{"os_name":"asia-southeast2","updated_at":"2025-07-02 13:31:49"}	2025-07-02 13:31:49	2025-07-02 13:31:49	Updated	\N
910	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	182	App\\Models\\User	3	{"os_name":"asia-southeast2","updated_at":"2025-07-02 13:32:10","note":"pruhub3-a2202659"}	2025-07-02 13:32:11	2025-07-02 13:32:11	Updated	\N
911	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	184	App\\Models\\User	3	{"os_name":"asia-southeast2","updated_at":"2025-07-02 13:32:37"}	2025-07-02 13:32:37	2025-07-02 13:32:37	Updated	\N
912	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	141	App\\Models\\User	3	{"os_name":"Red Hat 8.10 (RHEL)","os_version":"Postgres 16.0","updated_at":"2025-07-02 14:21:44","note":"Arif Rahman  - Postgres + mis_user padmin password_09 root today123"}	2025-07-02 14:21:44	2025-07-02 14:21:44	Updated	\N
913	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	182	App\\Models\\User	3	{"model":"pruhub3-a2202659","updated_at":"2025-07-02 14:28:51","note":"    \\"default_password\\": \\"UQTjnEpIOucHfEKaHHA8fDE2578DiXCu\\",\\n    \\"default_username\\": \\"postgres\\","}	2025-07-02 14:28:51	2025-07-02 14:28:51	Updated	\N
914	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	184	App\\Models\\User	3	{"model":"onepulseplatform-8ec602c4","updated_at":"2025-07-02 14:29:17","note":"\\"default_password\\": \\"e4f88211cf99b3e7\\",\\n  \\"default_username\\": \\"postgres\\","}	2025-07-02 14:29:17	2025-07-02 14:29:17	Updated	\N
915	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	183	App\\Models\\User	3	{"model":"onepulseplatpg-1a3b455f ","updated_at":"2025-07-02 14:29:46","note":"  \\"default_password\\": \\"b9b4cf99149f76d2\\",\\n  \\"default_username\\": \\"postgres\\","}	2025-07-02 14:29:46	2025-07-02 14:29:46	Updated	\N
916	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.170.93.109","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-02 14:37:08	2025-07-02 14:37:08	Login	\N
917	Resource	Hardware Updated by Haris Rifai	App\\Models\\Hardware	182	App\\Models\\User	5	{"ram":"38","cpu":"1","updated_at":"2025-07-02 14:38:47"}	2025-07-02 14:38:47	2025-07-02 14:38:47	Updated	\N
918	Resource	Hardware Updated by Haris Rifai	App\\Models\\Hardware	183	App\\Models\\User	5	{"ram":"38","cpu":"1","updated_at":"2025-07-02 14:39:18"}	2025-07-02 14:39:18	2025-07-02 14:39:18	Updated	\N
919	Resource	Hardware Updated by Haris Rifai	App\\Models\\Hardware	184	App\\Models\\User	5	{"ram":"38","cpu":"1","updated_at":"2025-07-02 14:39:34"}	2025-07-02 14:39:34	2025-07-02 14:39:34	Updated	\N
920	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.171.96.226","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-03 09:11:19	2025-07-03 09:11:19	Login	\N
921	Resource	Hardware Updated by Haris Rifai	App\\Models\\Hardware	181	App\\Models\\User	5	{"os_version":"PostgreSQL 16.9","updated_at":"2025-07-03 09:13:06","note":"PostgreSQL 16.9"}	2025-07-03 09:13:06	2025-07-03 09:13:06	Updated	\N
922	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.170.92.240","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-03 09:16:34	2025-07-03 09:16:34	Login	\N
923	Resource	Hardware Updated by Arif Rahman	App\\Models\\Hardware	181	App\\Models\\User	6	{"updated_at":"2025-07-03 09:18:50","note":"PostgreSQL 16.9\\npruasia\\\\sqlagtsvcdev \\nJ4k@rta21"}	2025-07-03 09:18:50	2025-07-03 09:18:50	Updated	\N
924	Resource	Hardware Updated by Haris Rifai	App\\Models\\Hardware	181	App\\Models\\User	5	{"updated_at":"2025-07-03 09:21:00","note":"PostgreSQL 16.9\\nPRUASIA\\\\SQLAGTSVCDEV  J4k@rta21"}	2025-07-03 09:21:00	2025-07-03 09:21:00	Updated	\N
925	Resource	Hardware Updated by Arif Rahman	App\\Models\\Hardware	181	App\\Models\\User	6	{"updated_at":"2025-07-03 09:25:06","note":"PostgreSQL 16.9\\nPRUASIA\\\\SQLAGTSVCDEV  \\nJ4k@rta21 \\n"}	2025-07-03 09:25:06	2025-07-03 09:25:06	Updated	\N
926	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.171.98.228","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-04 07:30:07	2025-07-04 07:30:07	Login	\N
927	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.171.97.192","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-04 09:06:32	2025-07-04 09:06:32	Login	\N
928	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.170.92.72","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-04 14:04:50	2025-07-04 14:04:50	Login	\N
929	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.171.97.4","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-04 21:17:46	2025-07-04 21:17:46	Login	\N
930	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.171.96.201","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-05 09:55:59	2025-07-05 09:55:59	Login	\N
931	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.171.99.36","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-06 00:42:07	2025-07-06 00:42:07	Login	\N
932	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.171.97.154","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-06 08:56:37	2025-07-06 08:56:37	Login	\N
933	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.171.97.154","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-06 12:19:26	2025-07-06 12:19:26	Login	\N
934	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.171.98.59","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-07 07:57:33	2025-07-07 07:57:33	Login	\N
935	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.171.98.88","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-07 10:23:20	2025-07-07 10:23:20	Login	\N
936	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.170.92.108","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-08 08:34:14	2025-07-08 08:34:14	Login	\N
937	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.170.92.108","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-08 16:37:26	2025-07-08 16:37:26	Login	\N
938	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.171.97.109","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-08 20:11:18	2025-07-08 20:11:18	Login	\N
939	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.170.92.93","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-09 08:49:27	2025-07-09 08:49:27	Login	\N
940	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.170.92.174","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-09 13:38:10	2025-07-09 13:38:10	Login	\N
941	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.170.92.93","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-09 14:11:21	2025-07-09 14:11:21	Login	\N
942	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.171.98.30","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-09 18:35:44	2025-07-09 18:35:44	Login	\N
943	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.171.98.139","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-10 08:47:59	2025-07-10 08:47:59	Login	\N
944	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.170.92.247","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-10 09:28:11	2025-07-10 09:28:11	Login	\N
945	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.170.92.247","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-10 13:42:44	2025-07-10 13:42:44	Login	\N
946	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.171.98.139","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-10 16:38:15	2025-07-10 16:38:15	Login	\N
947	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.170.92.247","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-10 16:46:50	2025-07-10 16:46:50	Login	\N
948	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.171.99.141","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-11 06:11:09	2025-07-11 06:11:09	Login	\N
949	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.141","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-11 07:01:23	2025-07-11 07:01:23	Login	\N
950	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.141","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-11 07:02:40	2025-07-11 07:02:40	Login	\N
951	Resource	User Updated by Harys 	App\\Models\\User	3	App\\Models\\User	3	{"profile_photo_path":"profile-photos\\/pVpVe66ve64fFKJ0idajdDuefBlcFym7qvpp3KAU.png","updated_at":"2025-07-11 07:03:16"}	2025-07-11 07:03:16	2025-07-11 07:03:16	Updated	\N
952	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.170.92.247","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-11 09:55:25	2025-07-11 09:55:25	Login	\N
953	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.170.92.47","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-11 14:54:46	2025-07-11 14:54:46	Login	\N
954	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.171.96.247","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-11 18:38:13	2025-07-11 18:38:13	Login	\N
955	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.98.108","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-14 07:11:56	2025-07-14 07:11:56	Login	\N
956	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.171.97.102","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-14 08:12:17	2025-07-14 08:12:17	Login	\N
957	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.96.159","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-15 07:41:49	2025-07-15 07:41:49	Login	\N
958	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.96.159","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-15 12:50:38	2025-07-15 12:50:38	Login	\N
959	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.170.92.48","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-16 08:21:34	2025-07-16 08:21:34	Login	\N
960	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.171.96.222","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-16 09:51:47	2025-07-16 09:51:47	Login	\N
961	Resource	Hardware Created by Harys 	App\\Models\\Hardware	185	App\\Models\\User	3	{"make":"10.171.84.145","model":"clone 92","serial":"VIDDCLXPENTDB01T","status":"0","os_name":"Red Hat 8.10 (RHEL)","os_version":"Postgres 15.0","ram":"19","cpu":"4","type":"0","user_id":3,"provaider_id":"1","purchased_at":"2025-07-16 00:00:00","note":"padmin\\/Password09 root\\/today123","company_id":1,"updated_at":"2025-07-16 16:51:47","created_at":"2025-07-16 16:51:47","id":185}	2025-07-16 16:51:47	2025-07-16 16:51:47	Created	\N
962	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	185	App\\Models\\User	3	{"user_id":"1"}	2025-07-16 16:51:48	2025-07-16 16:51:48	Updated	\N
963	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	70	App\\Models\\User	3	{"os_version":"SQL Server 2016","updated_at":"2025-07-16 17:51:06","note":"Fingerprint Tower"}	2025-07-16 17:51:06	2025-07-16 17:51:06	Updated	\N
964	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.170.92.94","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-17 08:46:36	2025-07-17 08:46:36	Login	\N
965	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.170.93.70","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-17 10:17:01	2025-07-17 10:17:01	Login	\N
966	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.170.92.94","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-17 16:17:24	2025-07-17 16:17:24	Login	\N
967	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	19	App\\Models\\User	3	{"updated_at":"2025-07-17 16:17:55","note":"Afdoli Fahmi  IDNPLAODSDB"}	2025-07-17 16:17:55	2025-07-17 16:17:55	Updated	\N
968	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	19	App\\Models\\User	3	{"os_name":"Windows Server 2016 R2","updated_at":"2025-07-17 16:49:59"}	2025-07-17 16:49:59	2025-07-17 16:49:59	Updated	\N
969	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	19	App\\Models\\User	3	{"model":"ODS PRD IDNPLAODSDB","os_name":"Windows Server 2016","updated_at":"2025-07-17 16:57:15"}	2025-07-17 16:57:15	2025-07-17 16:57:15	Updated	\N
970	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.170.60.34","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-17 18:05:16	2025-07-17 18:05:16	Login	\N
971	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.96.254","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-18 07:02:57	2025-07-18 07:02:57	Login	\N
972	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.170.92.109","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-18 09:21:33	2025-07-18 09:21:33	Login	\N
973	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.170.92.95","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-18 14:22:12	2025-07-18 14:22:12	Login	\N
974	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.205","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-19 10:48:05	2025-07-19 10:48:05	Login	\N
975	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.97.184","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-20 21:45:08	2025-07-20 21:45:08	Login	\N
976	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.2","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-21 06:37:24	2025-07-21 06:37:24	Login	\N
977	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.171.99.128","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-21 09:53:37	2025-07-21 09:53:37	Login	\N
978	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	85	App\\Models\\User	3	{"serial":"o35gws","updated_at":"2025-07-21 11:22:35"}	2025-07-21 11:22:35	2025-07-21 11:22:35	Updated	\N
979	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	82	App\\Models\\User	3	{"serial":"cmb6ze","updated_at":"2025-07-21 11:23:52","note":"cmb6ze"}	2025-07-21 11:23:52	2025-07-21 11:23:52	Updated	\N
980	Resource	Hardware Created by Harys 	App\\Models\\Hardware	186	App\\Models\\User	3	{"make":"10.143.34.26","model":"digitalpartner-new-6d79c8d4","serial":"babq79","status":"0","os_name":"Red Hat Enterprise Linux ","os_version":"Postgres 12","ram":"16","cpu":"8","type":"0","user_id":3,"provaider_id":"2","purchased_at":"2025-07-21 00:00:00","note":"digitalpartner-new-6d79c8d4","company_id":1,"updated_at":"2025-07-21 11:25:14","created_at":"2025-07-21 11:25:14","id":186}	2025-07-21 11:25:15	2025-07-21 11:25:15	Created	\N
981	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	186	App\\Models\\User	3	{"user_id":"1","updated_at":"2025-07-21 11:25:15"}	2025-07-21 11:25:15	2025-07-21 11:25:15	Updated	\N
982	Resource	Hardware Created by Harys 	App\\Models\\Hardware	187	App\\Models\\User	3	{"make":"10.143.17.92","model":"viddrlxddgpap01db-new-d5f22d10","serial":"lo943j","status":"0","os_name":"Red Hat Enterprise Linux ","os_version":"Postgres 12","ram":"16","cpu":"8","type":"0","user_id":3,"provaider_id":"1","purchased_at":"2025-07-21 00:00:00","note":"viddrlxddgpap01db-new-d5f22d10","company_id":1,"updated_at":"2025-07-21 11:26:05","created_at":"2025-07-21 11:26:05","id":187}	2025-07-21 11:26:05	2025-07-21 11:26:05	Created	\N
983	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	187	App\\Models\\User	3	{"user_id":"1"}	2025-07-21 11:26:05	2025-07-21 11:26:05	Updated	\N
984	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	170	App\\Models\\User	3	{"model":"pruhub3-168cfd2c","serial":"s16gul","updated_at":"2025-07-21 11:26:51"}	2025-07-21 11:26:51	2025-07-21 11:26:51	Updated	\N
985	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	79	App\\Models\\User	3	{"serial":"fhsl34","updated_at":"2025-07-21 11:27:30","note":"10.143.34.54 \\nPMN DB pmnwf-new2-6a194f8d"}	2025-07-21 11:27:30	2025-07-21 11:27:30	Updated	\N
986	Resource	Hardware Created by Harys 	App\\Models\\Hardware	188	App\\Models\\User	3	{"make":"10.143.34.58","model":"pmnwf-new2-6a194f8d-replica001","serial":"fhsl34a","status":"0","os_name":"Red Hat Enterprise Linux ","os_version":"POSTGRES_9_6","ram":"16","cpu":"8","type":"0","user_id":3,"provaider_id":"1","purchased_at":"2025-07-21 00:00:00","note":"POSTGRES_9_6","company_id":1,"updated_at":"2025-07-21 11:38:52","created_at":"2025-07-21 11:38:52","id":188}	2025-07-21 11:38:52	2025-07-21 11:38:52	Created	\N
987	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	188	App\\Models\\User	3	{"user_id":"1"}	2025-07-21 11:38:52	2025-07-21 11:38:52	Updated	\N
988	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	187	App\\Models\\User	3	{"updated_at":"2025-07-21 11:39:28","note":"viddrlxddgpap01db-new-d5f22d10 \\"default_password\\": \\"15d78c3d849493ee\\",\\n \\"default_username\\": \\"digitalpg\\","}	2025-07-21 11:39:28	2025-07-21 11:39:28	Updated	\N
989	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.171.99.128","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-21 16:54:36	2025-07-21 16:54:36	Login	\N
990	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.97.101","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-22 10:29:51	2025-07-22 10:29:51	Login	\N
991	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.97.45","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-22 14:12:00	2025-07-22 14:12:00	Login	\N
992	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	77	App\\Models\\User	3	{"os_version":"SQL EXPRESS 2017","updated_at":"2025-07-22 14:12:49"}	2025-07-22 14:12:49	2025-07-22 14:12:49	Updated	\N
993	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.171.98.222","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-22 22:39:10	2025-07-22 22:39:10	Login	\N
994	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.171.98.188","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-23 09:50:44	2025-07-23 09:50:44	Login	\N
995	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.98.56","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-23 17:00:03	2025-07-23 17:00:03	Login	\N
996	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.222","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-24 09:56:23	2025-07-24 09:56:23	Login	\N
997	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.222","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-24 17:49:38	2025-07-24 17:49:38	Login	\N
998	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.221","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-25 07:14:30	2025-07-25 07:14:30	Login	\N
999	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.170.92.98","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-25 17:33:57	2025-07-25 17:33:57	Login	\N
1000	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.97.79","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-25 23:07:14	2025-07-25 23:07:14	Login	\N
1001	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.96.64","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-26 12:40:56	2025-07-26 12:40:56	Login	\N
1002	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.98.44","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-27 13:15:47	2025-07-27 13:15:47	Login	\N
1003	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.2","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-28 08:32:27	2025-07-28 08:32:27	Login	\N
1004	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.2","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-28 16:21:13	2025-07-28 16:21:13	Login	\N
1005	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.96.33","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-29 06:22:15	2025-07-29 06:22:15	Login	\N
1006	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.171.99.94","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-29 08:22:43	2025-07-29 08:22:43	Login	\N
1007	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.248","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-29 21:58:00	2025-07-29 21:58:00	Login	\N
1008	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.98.185","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-30 08:52:14	2025-07-30 08:52:14	Login	\N
1009	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	64	App\\Models\\User	3	{"updated_at":"2025-07-30 09:01:04","note":"Abdul Qahar MSSQL$FXAW"}	2025-07-30 09:01:04	2025-07-30 09:01:04	Updated	\N
1010	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.170.93.1","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-30 09:48:23	2025-07-30 09:48:23	Login	\N
1011	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	64	App\\Models\\User	3	{"updated_at":"2025-07-30 12:03:48","note":"Abdul Qahar MSSQL$FXAW mis_user"}	2025-07-30 12:03:48	2025-07-30 12:03:48	Updated	\N
1012	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.225.249","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-30 18:40:43	2025-07-30 18:40:43	Login	\N
1013	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.170.92.147","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-31 09:06:20	2025-07-31 09:06:20	Login	\N
1014	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.170.92.147","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-31 13:42:56	2025-07-31 13:42:56	Login	\N
1015	Access	Arif Rahman logged in	\N	\N	App\\Models\\User	6	{"ip":"10.171.96.232","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-07-31 20:42:21	2025-07-31 20:42:21	Login	\N
1016	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.170.92.136","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-08-01 10:02:12	2025-08-01 10:02:12	Login	\N
1017	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.170.92.136","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-08-01 15:39:03	2025-08-01 15:39:03	Login	\N
1018	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.98.249","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-08-02 13:08:01	2025-08-02 13:08:01	Login	\N
1019	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.99.201","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-08-03 10:10:17	2025-08-03 10:10:17	Login	\N
1020	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	145	App\\Models\\User	3	{"os_name":"Red Hat  8.1  (RHEL)","os_version":"PostgreSQL 15.13","updated_at":"2025-08-03 10:13:15"}	2025-08-03 10:13:15	2025-08-03 10:13:15	Updated	\N
1021	Resource	Hardware Updated by Harys 	App\\Models\\Hardware	110	App\\Models\\User	3	{"serial":"SIDHODLINFUSDB1","os_name":"Red Hat  8.1  (RHEL)","os_version":"PostgreSQL 15.13","updated_at":"2025-08-03 10:13:45"}	2025-08-03 10:13:45	2025-08-03 10:13:45	Updated	\N
1022	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.170.92.154","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-08-04 09:30:47	2025-08-04 09:30:47	Login	\N
1023	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.170.92.154","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-08-04 13:38:23	2025-08-04 13:38:23	Login	\N
1024	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.170.92.154","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-08-04 17:07:07	2025-08-04 17:07:07	Login	\N
1025	Access	Harys  logged in	\N	\N	App\\Models\\User	3	{"ip":"10.171.96.140","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-08-04 19:13:21	2025-08-04 19:13:21	Login	\N
1026	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.170.92.167","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-08-05 08:47:55	2025-08-05 08:47:55	Login	\N
1027	Resource	Hardware Updated by Haris Rifai	App\\Models\\Hardware	132	App\\Models\\User	5	{"serial":"VIDDRLXUMSCDB01","ram":"15","updated_at":"2025-08-05 13:53:56"}	2025-08-05 13:53:56	2025-08-05 13:53:56	Updated	\N
1028	Resource	Hardware Updated by Haris Rifai	App\\Models\\Hardware	45	App\\Models\\User	5	{"status":"8","updated_at":"2025-08-05 13:58:34"}	2025-08-05 13:58:34	2025-08-05 13:58:34	Updated	\N
1029	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.171.98.56","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-08-06 07:46:21	2025-08-06 07:46:21	Login	\N
1030	Access	Haris Rifai logged in	\N	\N	App\\Models\\User	5	{"ip":"10.171.99.174","user_agent":"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/138.0.0.0 Safari\\/537.36 Edg\\/138.0.0.0"}	2025-08-06 20:22:14	2025-08-06 20:22:14	Login	\N
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.companies (id, user_id, name, personal_company, created_at, updated_at) FROM stdin;
2	3	Haris Rifai's Company	t	2024-10-05 11:36:22	2024-10-05 11:36:22
3	6	401405's Company	t	2024-10-05 11:36:22	2024-10-05 11:36:22
4	10	Afdoli Fahmi's Company	t	2024-10-05 11:36:22	2024-10-05 11:36:22
1	1	PRU CENTER	t	2024-10-05 11:36:22	2024-10-05 11:41:50
5	1	PRU	t	2024-10-05 12:57:19	2024-10-08 13:51:26
\.


--
-- Data for Name: company_invitations; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.company_invitations (id, company_id, email, role, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: company_user; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.company_user (id, company_id, user_id, role, created_at, updated_at) FROM stdin;
1	1	2	admin	2024-10-05 11:36:22	2024-10-05 11:36:22
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: hardware; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.hardware (id, make, model, serial, os_name, os_version, type, ram, cpu, status, current, company_id, user_id, provaider_id, purchased_at, created_at, updated_at, deleted_at, note, max_con) FROM stdin;
92	10.171.212.142	NPRD	viddcwndhpxap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N	400
132	10.171.211.16	DB2 - DEV	PRUIDWFCM02	AIX 2	DB2 AIX	0	8	8	0	t	1	1	2	2025-04-25 00:00:00	2025-04-25 11:18:31	2025-04-25 14:22:08	\N	   test	400
1	10.170.53.102	AOB DB ESUB PRD	VIDDCLXPAOBDB03	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.2.7	0	32	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	814 GB	400
2	10.170.53.103	AOB EPOLICY DB (WAB,Fuse)  PRD	VIDDCLXPAOBDB04	Red Hat  7.9  (RHEL)	EnterpriseDB 14.13	0	46	20	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-05-28 15:06:28	\N	200 GB DISK --- NIDLIFEAPPSUP ada versi 14 UP	400
3	10.170.53.29	BPM DB PRD	VIDHOPLINBPMDB1	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	64	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	148 GB	400
4	10.171.140.16	Payment Database PRD	VIDDCLXPNPHDB01-New	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	32	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	688 GB	400
5	10.170.53.56	Database Leads PRD	VIDDCLXPAOBDB05	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	31	36	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-28 10:44:23	\N	109 GB	400
6	10.170.53.57	Training PRD	VIDDCLXPAOBDB06	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	32	10	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-10-20 04:04:31	\N	109 GB	400
7	10.170.53.131	New ODS - PROD	VIDHOLXPODSDB01	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	160	16	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	997 GB	400
8	10.170.53.23	PRUForce DB PRD	VIDHOPLINAOBDB1	Red Hat 6.10 (RHEL)	(EnterpriseDB Advanced Server 14.13.1)	0	171	20	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-01-06 11:44:20	\N	1400 GB	400
9	10.171.84.55	SME omni PRD	VIDDCLXPSMEDB01	Red Hat 6.10 (RHEL)	PostgreSQL 14.13	0	31	24	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-03-20 11:29:37	\N	79 GB	400
10	10.171.84.56	SME Pruworks PRD	VIDDCLXPSMEDB02	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	23G	20	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-10-19 20:05:17	\N	217 GB	400
11	10.171.84.68	SME DB PRD	VIDDCLXPSMEDB04-new	Red Hat 6.10 (RHEL)	PostgreSQL 10.7 	0	19	6	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	 GB	400
12	10.170.53.101	nbwf,  DB Workflow PRD	VIDDCLXPAOBDB02	Red Hat  7.9  (RHEL)	(EnterpriseDB Advanced Server 14.13.1)	0	50	28	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-28 10:24:26	\N	892 GB	400
13	10.171.84.117	Magnum Pure PRD	VIDDCLXPMGPDB01	Red Hat  7.9  (RHEL)	(EnterpriseDB Advanced Server 9.6.2.7) 	0	16	16	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	571 GB	400
14	10.170.53.200	Corespondence DB PRD	VIDDCLXPCDSDB01	Red Hat (RHEL) 7.9	PostgreSQL 14.12	0	31	4	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-15 10:30:32	\N	443 GB	400
15	10.171.84.92	Postgre Enablement Tribe COMPLIANCE PRD	VIDDCLXPENTDB01	Red Hat 8.10 (RHEL)	PostgreSQL 14.12	0	15	4	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-05-05 08:38:54	\N	10 GB	400
16	10.170.53.108	Base DB PRD	VIDDCLXPBSEDB06	Red Hat 8.10 (RHEL)	PostgreSQL 14.12	0	62	8	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-14 14:10:21	\N	59 GB	400
17	10.171.84.100	AI DB PRD	VIDDCLXPAICDB01	Red Hat 6.10 (RHEL)	PostgreSQL 10.4	0	32	4	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	197 GB	400
18	10.170.53.147	Consolidate Database Server(XML) PRD	VIDHOWNPINTDB01	Windows Server 2016	SQL Server 2016	0	44	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-30 16:40:07	\N	Afdoli Fahmi \nowner Nanda widy	400
19	10.170.53.106	ODS PRD IDNPLAODSDB	VIDHOWNPODSDB01	Windows Server 2016	SQL Server 2016	0	64	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-07-17 16:57:15	\N	Afdoli Fahmi  IDNPLAODSDB	400
20	10.170.53.36	Internal DB (Moveit) PRD	VIDHOWNPINTDB02	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-14 10:30:13	\N	Afdoli Fahmi -- > moveitdmz Password09	400
21	10.170.48.98	Reporting DB SRSS PRD	VIDHOWNPREPDB01	Windows Server 2016	SQL Server 2016	0	32	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 	400
22	10.170.48.177	Database Solarwind, scom, SCCM PRD	SIDHOPWINIFRDB1	Windows Server 2016	SQL Server 2016	0	16	3	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-03-27 11:54:30	\N	Afdoli Fahmi , mis_user\nSQLAGTSVCPROD Password09	400
23	10.170.48.58	Internal DB - 03 PRD	VIDHOWNPINTDB03	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 	400
24	10.170.48.211	NICE DB PRD	VIDHOWNPNDSDB01	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani	400
25	10.170.48.44	NICE DB PRD	VIDHOWNPNDSDB02	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani	400
26	10.170.48.186	Ops Dashboard DB PRD	VIDHOWNPOPSDB01	Windows Server 2016	SQL Server 2016	0	8	2	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 	400
27	10.170.48.85	GPP Report PRD	SIDHOPWINMDB01	Windows Server 2016	SQL Server 2016	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-07-02 10:08:54	\N	Afdoli Fahmi GPP	400
28	10.170.48.112	Customer Analytic PRD	SIDHOPWINDALDB1	Windows Server 2016	SQL Server 2019	0	48	3	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-28 10:03:49	\N	Afdoli Fahmi \nHani Asri Guardiani	400
29	10.170.53.46	CRM Archive PRD	VIDHOWNPCRMDB03	Windows Server 2016	SQL Server 2016	0	24	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Victor Liliwidjaja	400
30	10.170.48.84	Reinsurance DB PRD	VIDHOWNPREIDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Fikrilsyah Algoumar	400
31	10.170.48.77	E-Submission NB PRD	VIDHOWNPXARDB01	Windows Server 2016	SQL Server 2016	0	8	2	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-10 11:13:44	\N	Nanda Widy	400
32	10.170.48.122	Sharepoint DB PRD	SIDHOPWINSHPDB1	Windows Server 2016	SQL Server 2016	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-27 11:54:03	\N	Syofianer Fitra	400
33	10.170.48.215	K2 DB server PRD	VIDHOWNPKTWDB01	Windows Server 2016	SQL Server 2016	0	20	2	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-27 11:53:25	\N	Syofianer Fitra	400
34	10.170.53.91	SUN GL PRD	SIDHOPWINSUNDB1	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Syofianer Fitra	400
35	10.170.53.187	New Actuary DB PRD	VIDHOWNPPRPDB01	Windows Server 2016	SQL Server 2016	0	64	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-03-27 08:19:59	\N	Salman Farizi \n260325->addcpu 2	400
36	10.170.53.68	CRM PRD	VIDHOWNPCRMDB02	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Victor Liliwidjaja	400
37	10.170.53.44	CRM PRD	VIDHOWNPCRMDB01	Windows Server 2016	SQL Server 2016	0	39	12	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Victor Liliwidjaja	400
38	10.170.53.105	DataMart PRD	VIDHOWNPDTMDB01	Windows Server 2019	SQL Server 2016	0	32	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-05-28 16:46:00	\N	Fikrilsyah Algoumar	400
39	 10.170.53.49	PG BCA PRD	VIDHOWNPH2BDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Bhimo Bhaskoro	400
40	10.170.53.153	OCR DB PRD	VIDDCWNPOCRDB01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Juliana	400
41	10.170.53.5	EPOS DB PRD	VIDHOPWINPOSDB1	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 	400
42	10.171.84.205	New IFRS  PRD	VIDDRWNPIFRDB01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Mimi Winata	400
43	10.171.84.215	Power BI PRD	VIDDCWNPPBIAP01	Windows Server 2016	SQL Server 2016	0	96	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Rizky Karunia	400
44	10.171.84.70	GreenPlum Master PRD	SIDDRLXPGPMAP01 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2025-08-05 13:58:34	\N	Afdoli Fahmi , MIS\n/GPDB_DATA/master/gpseg-1/	400
45	10.171.84.71 	GreenPlum Second Master PRD	SIDDRLXPGPSAP01	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
46	10.171.84.123	GreenPlum Node 1 PRD	SIDDRLXPGPNAP01	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
47	10.171.84.124	GreenPlum Node 2 PRD	SIDDRLXPGPNAP02	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
48	10.171.84.125	GreenPlum Node 3 PRD	SIDDRLXPGPNAP03 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
49	10.171.84.126	GreenPlum Node 4 PRD	SIDDRLXPGPNAP04 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
50	10.171.84.128 	GreenPlum Node 5 PRD	SIDDRLXPGPNAP05	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
51	10.171.84.129	GreenPlum Node 6 PRD	SIDDRLXPGPNAP06	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
52	10.171.84.104	BPM DB2 PRD	VIDDCLXPBPMDB01	Red Hat 6.10 (RHEL)	DB2 v10.5.0.3	0	58	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS\nkill locking db2  	400
53	10.170.53.150	HPX DB2  PRD	VIDHOLXPHPEDB01	Red Hat  8.10  (RHEL)	DB2 v10.5.0.3	0	15	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-29 14:30:39	\N	Afdoli Fahmi , MIS, HPXDE	400
54	10.170.53.99	CM DB2 PRD	PRUIDWFCM02	AIX 7	DB2 v10.5.0.8	0	42	3	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS \nkill locking db2  	400
55	10.171.84.43	RESDB DB2 PRD	VIDDCLXPODMDB01	Red Hat  7.9  (RHEL)	DB2 v10.5.0.3	0	31	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS  \n user SPLAIODM pass: Password09 di ip\n10.171.84.43 (BRMS)	400
56	10.170.53.14	MFPDATA DB2 PRD	VIDHOPLINIMFDB1	Red Hat (RHEL) 8.10	DB2 v11.5.8.0	0	62	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-05 10:52:32	\N	Afdoli Fahmi , MIS	400
57	10.171.82.73	UAT	sidhopwinvnxap1	Red Hat 6.10 (RHEL)	MySQL Database Server	0	31	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS	400
58	10.170.49.144	UAT	vidhownuinsdb01	Windows Server 2012 R2	Oracle Database 11g Enterprise Edition	0	31	8	0	t	1	1	3	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-18 18:00:58	\N	Afdoli Fahmi , MIS\n.\\sqlagtsvcdev\nPassword09	400
59	10.170.49.107	UAT	viddrlxdatsap01	Red Hat 6.10 (RHEL)	Oracle Database 11g Enterprise Edition	0	31	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS	400
60	10.171.83.52	DB Server SCCM Server PRD	viddcwnpscmap02	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Abdul Qahar	400
61	10.170.53.198	DB Server iCare & IVRDB PRD	vidhowpivrdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
62	10.170.48.37	DB Nice Server Playback Portal PRD	vidhownpnpsdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-02 15:35:03	\N	Ridwan Royani	400
63	10.170.48.101	DB Server New AWMS Server (Tower) PRD	viddcwnpawmap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-07-30 12:03:48	\N	Abdul Qahar MSSQL$FXAW mis_user	400
64	10.170.48.35	DB Server Sentinel  PRD	vidhownpnmsap02	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-02 15:35:36	\N	Ridwan Royani, Manage by Nice Vendor	400
65	10.170.109.19	DB Server Q-Matic PRD	vidptwnpqmtap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani	400
66	10.170.53.199	DB Server iCare & IVRDB PRD	viddrwpivrdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-06-19 14:56:10	\N	mis_user Password09	400
67	10.170.53.186	Is not DB Server PRD	vidhownpprpap02	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
68	10.170.48.63	Is not DB Server PRD	sidhopwinscmap1	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Taufik Ridwan	400
69	10.170.216.196	DB Server WINPAKPRO PRD	sidpcwnpacdap01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-07-16 17:51:06	\N	Fingerprint Tower	400
70	10.171.210.50	NICE Engage Unified PRD	siddrwnpneuap01	Windows Server 2016	no db	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-02 15:33:59	\N	Ridwan Royani	400
71	10.170.48.235	DB Server(NewSolarWins DB) PRD	vidhopwinifrdb1	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
72	10.170.216.69	DB Server FXAW PRD	vidpcwnpawmap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
73	10.170.53.185	Is not DB Server New Actuary Apps PRD	vidhownpprpap01	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Daniel Agustinus Rahardjo / Salman Farizi 	400
74	10.170.48.102	Decommissioning PRD	vidhownpintdb07	Windows Server 2016	SQL Server 2012	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
75	10.170.48.33	Decommissioning NICE  PRD	vidhownpndsdb03	Windows Server 2016	SQL Server 2012	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani	400
76	10.170.48.128	DB Server SOLARWIN_ORION PRD	vidhopwinswdap1	Windows Server 2016	SQL EXPRESS 2017	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-07-22 14:12:49	\N	unknow	400
77	10.171.140.90	Is not DB Server ( No DB Service) PRD	viddcwnppbhap01	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Arif Hidayat Husni	400
78	10.143.17.6	smartclaim smartclaim PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	\N	400
79	10.143.34.5 	DB SCRM PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2022	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-04-25 15:31:30	\N	1433  sqlserver/ua}T&-9[  simplecrm	400
80	10.141.48.131	STAGGING REMOTE SQL NRPD	service db cloud	Windows Server 2016 GCP	Client Cloud Remote Server	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	\N	400
81	10.170.52.70	PRD	VIDHOWNPSFSAP04	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
82	10.170.52.28	NPRD	WINTEL	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
83	10.170.53.114	NPRD	vidhownp2faap01 	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
84	10.170.48.110	NPRD	VIDHOLXPBAKAP01	Red Hat  8.10  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
85	10.170.48.109	PRD	VIDHOLXPBAKAP02	Red Hat  7.9  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
86	10.171.84.78	NPRD	VIDHOLXGBQMAP01	Red Hat  7.9  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2025-03-20 08:53:44	\N	Upgrade Postgres v.8.3 to 14.3	400
87	10.171.213.79	NPRD	VIDDRLXUSMEAP04	Red Hat  8.1 (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.10 to 14.3	400
88	10.170.49.150	NPRD	SIDHODLINFUSDB1	Red Hat  8.1  (RHEL)	PostgreSQL 15.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2025-08-03 10:13:45	\N	Postgres v.10 to 14.3 | fuse DB  pruasia\\sqlagtsvcdev\nPassword09	400
89	10.170.49.191	NPRD	vidholdodsdb1	Red Hat  7.9  (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-12-13 09:41:05	\N	Upgrade Postgres v.10 to 14.3 pruasia\\sqlagtsvcdev\nPassword09	400
90	10.171.212.215	PRD	VIDDRWNDNRSDB01	Windows Server 2016	SQL Server 2016 express SP3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Uninstal SQLEXPRESS	400
91	10.171.210.25	NPRD	VIDDRWNPCCVAP01	Windows Server 2016	SQL Server 2016 express SP3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Uninstal SQLEXPRESS	400
93	10.170.49.11	NPRD	VIDHOWNUPDCAP01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-06-11 13:53:48	\N	SQLAGTSVCDEV  Password09	400
94	10.170.49.123	NPRD	SIDHOUWINSAPDB2	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-11-11 13:43:00	\N	PRUASIA\\sqlagtsvcdev\nPassword09	400
95	10.170.49.188	NPRD	vidhodwinintdb1	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N	400
96	10.170.49.195	NPRD	vidhowndefmdb01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N	400
97	10.170.49.196	NPRD	vidhownupacdb01	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Finger Print	400
98	10.170.49.197	NPRD	vidhowndeprap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-03-25 17:39:18	\N	11	400
99	10.170.49.210	NPRD	vidhodwinintdb7	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Dev Moveit	400
100	10.170.49.216	NPRD	sidhouwinepvap1	Windows Server 2016	SQL Server 2016 SP 3	0	16,200	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-05-04 16:18:45	\N	123	400
101	10.170.49.217	NPRD	vidhownuefmap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-04-22 16:24:12	\N	AJI  E-FORM-APPS\n.\\sqlagtsvcdev  -> Password09	400
102	10.170.49.78	NPRD	sidhouwinepvdb1	Windows Server 2016	SQL Server 2016 SP 3	1	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-03-25 17:39:00	\N	111	400
103	10.170.49.80	UAT	SIDHOUWINSFTP01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-01-28 10:02:30	\N	Hanan	400
104	10.170.49.81 	NPRD	sidhodwinepvdb1	Windows Server 2012 R2 	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	e-Payment Voucher	400
105	10.170.49.88 	NPRD	VIDHOWNUINTDB01	Windows Server 2019	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N	400
106	10.170.216.100	PRD	SIDHOWNPCCVAP01	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Upgrade to 2016 SP 3	400
107	10.170.53.61	PRD	vidhownpcrmap03	Windows Server 2019 STD	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Microsoft SQL Server 2008 R2 	400
108	10.170.49.136	DBA_USER DEV	VIDDRLXUGBQDB01	Red Hat  8.10  (RHEL)	Postgres 16.0	0	125GB	32	0	t	1	1	4	2024-10-10 00:00:00	2024-10-10 21:31:41	2024-10-10 21:31:41	\N	DEV NEW Postgres 16 | dba_user dba_user | 5432 | owner | Radit	400
109	10.171.86.72	NBWF UAT	VIDDRLXUMSCDB01	Red Hat  7.9  (RHEL)	(EnterpriseDB Advanced Server 14.13.1)	0	15	8	0	t	1	1	4	2024-10-12 00:00:00	2024-10-12 16:31:46	2025-08-05 13:53:56	\N	SR02701142	400
110	10.171.211.50	DR GP	SIDDCLXPGPMAP01	Red Hat 6.10 (RHEL)	Greenplum Node Master	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
111	10.171.211.51	DR GP	SIDDCLXPGPSAP01	Red Hat 6.10 (RHEL)	Greenplum Node Standby	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
112	10.171.211.123	DR GP	SIDDCLXPGPNAP01	Red Hat 6.10 (RHEL)	Greenplum Node 1	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
113	10.171.211.124	DR GP	SIDDCLXPGPNAP02	Red Hat 6.10 (RHEL)	Greenplum Node 2	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
114	10.171.211.125	DR GP	SIDDCLXPGPNAP03	Red Hat 6.10 (RHEL)	Greenplum Node 3	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
115	10.171.211.126	DR GP	SIDDCLXPGPNAP04	Red Hat 6.10 (RHEL)	Greenplum Node 4	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
116	10.171.211.127	DR GP	SIDDCLXPGPNAP05	Red Hat 6.10 (RHEL)	Greenplum Node 5	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
117	10.171.211.128	DR GP	SIDDCLXPGPNAP06	Red Hat 6.10 (RHEL)	Greenplum Node 6	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
118	10.170.49.179	DR GP	VIDHOLXDGPMAP02 	Red Hat 8.10 (RHEL)	Postgres 16.0	0	62	24	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2025-07-02 14:21:44	\N	Arif Rahman  - Postgres + mis_user padmin password_09 root today123	400
119	10.170.49.180	GP DEV	VIDHOLXDGPNAP03	Red Hat Enterprise Linux 	Greenplum Node 4.3.33	0	62G	24	0	t	1	1	4	2024-10-22 00:00:00	2024-10-22 18:35:26	2024-10-22 20:21:47	\N	VIDHOLXDGPNAP03	400
120	10.170.49.181	GP DEV	VIDHOLXDGPNAP04	Red Hat Enterprise Linux 	Greenplum Node 4.3.33	0	62G	24	0	t	1	1	4	2024-10-22 00:00:00	2024-10-22 20:11:06	2024-10-22 20:22:04	\N	VIDHOLXDGPNAP04	400
121	10.170.49. 	DBA_USER DEV	VID	Red Hat Enterprise Linux 	(EnterpriseDB Advanced Server 14.13.1)	0	62G	24	0	t	1	1	4	2024-10-22 00:00:00	2024-10-22 20:18:04	2024-10-23 07:15:51	\N	10.170.49.180	400
122	10.170.49.168	ON PREM ESUB NEWODS AOB UAT	VIDHOLXUINTDB02	Red Hat  8.1  (RHEL)	PostgreSQL 15.13	0	15	8	0	t	1	1	4	2024-10-23 00:00:00	2024-10-23 10:43:56	2025-08-03 10:13:15	\N	 	400
123	10.171.84.154	ICN DB2 PRD	VIDDCLXPICNDB01	Red Hat (RHEL) 8.10	DB2 v11.5.8.0	0	7.5 GB	2	0	t	1	1	1	2024-11-05 10:00:00	2024-11-05 10:58:11	2024-11-05 10:58:11	\N	Afdoli Fahmi , MIS	400
124	10.170.53.202	TRIAL DB SQL SERVER	TRIAL	WINDOWS 2012 R2	SQL Server 2022	0	16	8	9	t	1	1	5	2024-11-13 00:00:00	2024-11-13 07:52:19	2024-11-13 07:52:27	\N	10.170.53.202\n.\\admintemp\nPassword09	400
125	10.143.34.85	newpruworks PRD	pruidlife-prod	CLOUD SQL  SVR	PostgreSQL 15.8	0	16	8	0	t	1	1	5	2024-11-19 00:00:00	2024-11-19 13:53:08	2024-11-19 14:30:32	\N	 "default_password": "\\u003cM?WuPtb",\n  "default_username": "pruuser", "root_password": "K2b\\u003ej1ly"	400
126	10.143.27.236	Cloud INTUATDB PRD	IDLIFED4VZP1CVI	Ubuntu 20	SQL Server 2019	0	6	2	0	t	1	10	1	2024-12-17 10:00:00	2024-12-17 16:00:37	2025-02-06 09:45:15	\N	    "private_address": "10.143.27.236",\n    "root_password": "+}CGp[@-"\n}\nuser sqlserver	400
159	10.143.17.6	PROD pw0vxt smartclaimpg-new-121e1fea	smartclaim	CLOUD	PostgreSQL 12.16	smartclaim	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
127	10.170.109.42	Server Recording ACRA  PRD	VIDPTWNPACRAP01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	1	2025-01-14 00:00:00	2025-01-14 09:07:24	2025-01-14 09:07:37	\N	Login : VIDPTWNPACRAP01\\pruadmin\nPassword : P@ssw0rd\nVIDPTWNPACRAP01	400
128	10.170.49.73	UAT 	VIDDCLXDGAIAPP01	Red Hat Enterprise Linux 	Postgres 14.0	0	16	23	0	t	1	1	4	2025-02-06 00:00:00	2025-02-06 14:38:58	2025-02-06 14:38:58	\N	VIDDCLXDGAIAPP01	400
129	10.171.84.73	VIDDCLXPGA PRD	VIDDCLXPGA	Red Hat Enterprise Linux 	Postgres 14.0	0	8	2	0	t	1	1	2	2025-02-06 00:00:00	2025-02-06 14:44:55	2025-02-06 14:44:55	\N	VIDDCLXPGA	400
130	10.170.53.78	ORACLE PRD	VIDHOWNPINSDB01	WINDOWS 2012 R2	Oracle 11g Windows	0	32	8	0	t	1	1	3	2025-02-21 00:00:00	2025-02-21 15:02:20	2025-02-21 15:02:20	\N	CREATE USER mis_user IDENTIFIED BY Password09;	400
131	10.170.48.190	DCI CFS PRD	VIDHOWPCFSAP1	WINDOWS 2012 R2	Microsoft SQL Server 2012	0	8	4	0	t	1	1	1	2025-02-26 00:00:00	2025-02-26 15:31:15	2025-02-26 15:31:15	\N	Henry Lois Sumendap	400
133	10.170.53.132	PROD	vidholxpodsdb02	Red Hat 8.10 (RHEL)	EDB 14.12	0	168	26	0	t	1	1	1	2025-04-30 00:00:00	2025-04-30 14:56:44	2025-05-06 13:29:11	\N	padmin	400
134	10.143.34.237	pruhub3-168cfd2c	s16gul	CLOUD SQL	PostgreSQL 9	0	16	8	0	t	1	1	1	2025-05-14 00:00:00	2025-05-14 09:13:32	2025-07-21 11:26:51	\N	[{"password":"v1CtdwHkyX@7RYi8","username":"dba_user"},\n{"password":"9TKYrP$8kU15Ny-O","username":"pruhub_user"},\n{"password":"N/TdoFP@ey0nwRWP","username":"service_user"}]	400
135	10.143.17.22	DEV DBA_USERx	10.143.17.22	CLOUD SQL	Postgres 9.0	0	16	8	0	t	1	1	2	2025-05-21 00:00:00	2025-05-21 14:02:27	2025-05-21 14:02:27	\N	pw: lAb43za16dHCMWbTpOFqV3tNJXi449rL\nu: postgres	400
136	10.170.52.68	SHARE PROD	10.170.52.68	WINDOWS 2016	Postgres 8.3	0	24	8	0	t	1	1	1	2025-05-27 00:00:00	2025-05-27 14:35:12	2025-05-27 14:38:46	\N	IPS_Prundetial	400
137	10.170.52.70	SHARE PROD	10.170.52.70	WINDOWS 2012	Postgres 15.13	0	8	8	0	t	1	1	1	2025-05-27 00:00:00	2025-05-27 14:37:44	2025-05-28 16:48:19	\N	88	400
138	10.143.17.10	REDSOFT	INVESTMEN	CLOUD SQL	Microsoft SQL Server 2019	0	16	8	0	t	1	1	1	2025-06-03 00:00:00	2025-06-03 15:19:47	2025-06-03 15:19:47	\N	IP : 10.143.17.10\nUsername : sqlserver\nPassword : ceJym<Le	400
139	10.170.49.251	NRPD	VIDHOLXUINTDB01	Red Hat 7 (Rhell)	PostgreSQL 14.12	0	15	8	0	t	1	1	2	2025-06-17 00:00:00	2025-06-17 11:37:25	2025-06-17 11:37:25	\N	10.170.49.251	400
140	10.170.49.211	DEV NRPOD	VIDHOWNUSFSAP02	Windows Server 2016	PostgreSQL 16.9	0	16	4	0	t	1	1	1	2025-06-23 00:00:00	2025-06-23 15:39:00	2025-07-03 09:25:06	\N	PostgreSQL 16.9\nPRUASIA\\SQLAGTSVCDEV  \nJ4k@rta21	400
141	10.143.17.96	pruhub3-a2202659	c5fzh0	asia-southeast2	POSTGRES_9_6	0	38	1	0	t	1	1	4	2025-07-02 00:00:00	2025-07-02 13:28:37	2025-07-02 14:38:47	\N	    "default_password": "UQTjnEpIOucHfEKaHHA8fDE2578DiXCu",\n    "default_username": "postgres",	400
142	10.171.84.145	clone 92	VIDDCLXPENTDB01T	Red Hat 8.10 (RHEL)	Postgres 15.0	0	19	4	0	t	1	1	1	2025-07-16 00:00:00	2025-07-16 16:51:47	2025-07-16 16:51:47	\N	padmin/Password09 root/today123	400
143	10.143.34.54	PROD fhsl34 pmnwf-new2-6a194f8d	nbwf	CLOUD	PostgreSQL 9.6.24 	PMN DB	12	24	0	t	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Nanda Widi {"password":"4AOT1weD-2-uEotf","username":"nbwf-svc"} 	400
144	10.143.34.5	PROD pxz32v crm-prod-4d1f4c46	CRM	CLOUD ubuntu linux 20.04 LTS	SQLSERVER 2022 STD	SCRM	32	32	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Salman Farizi user/pas : sqlserver/ua}T&-9[ 	400
145	10.143.27.253	UAT w89lzu jatisdev-c9a15088	jatisSMS (Cloud Instance)	CLOUD (Cloud Instance)	SQLSERVER 2019 ENTERPRISE	jatisSMS (Cloud Instance)	4	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Aji user/pass: sqlserver/Svu72BhZ 	400
146	10.143.34.237	PROD s16gul pruhub3-168cfd2c	pruhub	CLOUD	PostgreSQL 9.6.24	pruhub	4	8	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	 password:"v1CtdwHkyX@7RYi8","username":"dba_user" / default_username":"PostgreSQL " "default_password":"BfvuoYlNmX0XRDY4hPHyCh2bTzE244Do" 	400
147	10.143.17.91	UAT ss5reu pmnwf-new-1b3665f1	pmnwf	CLOUD	PostgreSQL 9.6.24	PMN DB	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Fajar Tri nbwf-svc/Yosm@fY$EcZeF6WE 	400
148	10.143.17.92	UAT lo943j viddrlxddgpap01db-new-d5f22d10	\N	Red Hat Enterprise Linux 	PostgreSQL 16.9 	\N	4	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	viddrlxddgpap01db-new-d5f22d10 "default_password": "15d78c3d849493ee",\n "default_username": "digitalpg",	400
149	10.143.17.17	DEV tylzpr mis-api-bc543eee	mis-api	CLOUD	PostgreSQL 16.8 	mis-api	4	8	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	 PostgreSQL /mKvfzOHMGKiZ6uvH7g5qd8EP3Nyrtwfb 	400
150	10.143.17.16	DEV tylzpr mis-newods-37aa20f8	mis-newods	CLOUD	PostgreSQL 16.8 	mis-newods	4	6	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	 PostgreSQL /9QLP2ubRW6FENboO0H7arWr5vq91GJ1S 	400
151	10.143.34.234	PROD q6ec67 magnumpuredb-08fea2c0	magnumpure	CLOUD	PostgreSQL 15.10 	MagnumPure	16	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Odianto user/pas : PostgreSQL /ikGIgklikmFjNxWf0hVq4oNVZNXlWlVB 	400
152	10.143.17.126	UAT wyaxkx magnumpuredb-f1c22de1	magnumpure	CLOUD	PostgreSQL 15.10 	MagnumPure	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Odianto PostgreSQL /baf78c6b70be36ee  ALTER USER prumagnumpure WITH PASSWORD 'cNA4-K/C2VZ3Wh!!';\n5432	400
153	10.143.34.101	PROD m6amcz pap-f0099a49	PAP	CLOUD	PostgreSQL 14.12 	PAP	4	6	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Marantika user/pas : postgres/xIqL6MHtPJWYA1OjaPaW4n9UM844LYdF	400
154	10.143.34.70 	PROD m6amcz psa-25bc426c	PSA	CLOUD	PostgreSQL 14.12 	PSA	4	6	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Dede P user/pas : PostgreSQL /bFAyEyz383ITMZ8MHImEfAnDzKZSTO74 	400
155	10.143.17.29	UAT wsjs97 edocpg-0db5bf0e	edoc	UBUNTU 10,22 GCP	PostgreSQL 13.21 	edoc (cloud_Instance)	2	5	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Benny Setiawan user/pass: "PostgreSQL "/"o1Gy1WbqQ3DZcTt4hyVGzkCzEHnFEKxb" user/pass:"edocplai"/"U0Y42h8mngzu-D8@"	400
156	10.143.34.199	PROD s3rcg0 apidb-e2626704	apidb	CLOUD	PostgreSQL 13.20 	apidb	8	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Syatria Babullah PostgreSQL /BCddZ3lIoxsgMqEd7Un2gB1JcMT7SFsx 	400
157	10.143.17.197	UAT pdf47h apidb-f000bac2	apidb	CLOUD	PostgreSQL 13.20 	apidb	4	8	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	password":"JqoNbmc/hgQud4wP",\n"username":"dev-svc" postgres/Ku6u6mpGsBplAeyeiiG28P8J3gDUk63o	400
158	10.143.34.226	PROD s3rcg0 oltp-5b56f831	oltp	CLOUD	PostgreSQL 13.13	oltp	8	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Syatria Babullah "oltp-svc"/"KT3meM@r-BdEBF1p" 	400
160	10.141.19.86	UAT el8fvd PostgreSQL -digiservice (gke)	PostgreSQL 	CLOUD	PostgreSQL 10.6 	\N	1	2	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Fajar Tri PostgreSQL /P@ssw0rd 	400
161	10.143.17.96	DEV c5fzh0 pruhub3-a2202659	\N	CLOUD	PostgreSQL  9 6	\N	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	 PostgreSQL /UQTjnEpIOucHfEKaHHA8fDE2578DiXCu  dba_user/91s7tmqQzPt$@65-  pruhub_user/j-UESCT26jXXAR-! 	400
162	10.143.34.58	PROD fhsl34 pmnwf-new2-6a194f8d-replica001	PMN DB Replica	CLOUD	PostgreSQL  9 6	PMN DB Replica	12	24	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Fajar Tri  	400
163	10.141.23.11	UAT c5wvjk idlifec5wvjknuf	Renova_Individual	CLOUD	SQLSERVER  2017 STD	Renova (Cloud VM)	8	64	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Kris Ginting user/pass: renovaid/Password12 sa/Password09	400
164	10.143.17.32	DEV lgtk7w pruforce-5c930018	Pruforce Dev	CLOUD	PostgreSQL  16	Pruforce Dev	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
165	10.143.27.7	DEV w89lzu mitracomdev-3dbd2351	Mitracom	CLOUD	SQLSERVER 2019 ENTERPRISE	Mitracom	4	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
166	10.143.34.112	PROD cq4b9l consolidate-db	Consolidate DB	CLOUD	SQLSERVER 2019 ENTERPRISE	Consolidate DB	8	45	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
167	10.143.34.111	PROD cq4b9l internal-db	Internal DB (HR)	CLOUD	SQLSERVER 2019 ENTERPRISE	Internal DB (HR)	4	20	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
168	10.143.34.200	PROD i7e7oy newpruworks	Pruworks	CLOUD	SQLSERVER 2019 ENTERPRISE	Pruworks	8	49	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
169	10.143.17.8	DEV xdh57h radsoftdb	Radsoft dev	CLOUD	SQLSERVER 2019 ENTERPRISE	Radsoft dev	4	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
170	10.143.27.236	UAT h7xg8d pruworks-nprd-1bf475b2	Pruworks UAT	CLOUD	SQLSERVER 2019 ENTERPRISE	Pruworks UAT	4	24	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
171	10.143.27.57	UAT r9vnma crm-nprd-1ccd6221	CRM	CLOUD ubuntu linux 20.04 LTS	SQLSERVER 2022 STD	SCRM	2	9	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Salman Farizi user/pas : sqlserver/vA:sX3d@ 	400
172	10.143.34.79	PROD syxuqi renovadb2-aaf0f976  (Cloud Instance) Renova_Individual PRD	Renova_Individual	CLOUD	SQLSERVER 2019 STD	Renova (Cloud Instance)	4	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Kris Ginting user/pass: renovadb/5J+a]OlQ user/pass: "sqlserver"/"XpIeX_N&"	400
173	10.143.34.206	PROD o35gws smartclaimpg-b9476f39-replica001	smartclaim	CLOUD	PostgreSQL 12.16	smartclaim (replica)	4	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
174	10.143.34.202	PROD o35gws smartclaimpg-b9476f39	smartclaim	CLOUD	PostgreSQL 12.16	smartclaim (master)	4	15	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	"password": "nl!rWHX@vSojmUbn",\n"username": "op-svc"\n\n"password": "rh1mTEj!U23pd6$5",\n  "username": "dba-user"\n\n"password": "rp@o73p6-knfv$lC",\n "username": "release-user"	400
175	10.143.34.42	PROD cmb6ze onepulsepg-60317328	onepulse	CLOUD	PostgreSQL 12.16	One Pulse Platform	2	7	0	t	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Benny Setiawan  	400
176	10.143.17.10	UAT p82cwr radsoftdbuat	Prudential	CLOUD	SQLSERVER 2019 ENTERPRISE	radsoft	4	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Kris Ginting sqlserver/ceJym<Le 	400
177	10.143.27.238	DEV r9vnma crm-reporting-nprd-5ca264f8	CRM Reporting UAT	Ubuntu 20.04	SQL Server 2022 ENTERPRISE	CRM Reporting UAT	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	sqlserver\n\n@78$hZ!L	400
178	10.143.34.109	PROD pxz32v crm-reporting-prod-4b5c8140	CRM Reporting	CLOUD	SQLSERVER 2019 ENTERPRISE	CRM Reporting	8	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
179	10.143.17.69	UAT qdunle psa-a83c68ff	PSA	UBUNTU 10,22 GCP	PostgreSQL 14.12 	PSA	1	3	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Dede P user/pas : PostgreSQL /AmZsWOWWl949v3lAtKMJeT9AVAqlBbHu 	400
180	10.143.34.223	DEV jjnvha edocpg-c18592f8	edoc	CLOUD	PostgreSQL 12.16	edoc (cloud_Instance)	2	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Benny Setiawan user/pass: "PostgreSQL "/"agG0nkLGOCphBdCwsUD5Cd1B8W0TmADT" user/pass: "edocplai"/"IOSBQgiK6hOiEvu-"	400
181	10.143.17.121	UAT eawwbd onepulseplatpg-1a3b455f	\N	CLOUD	PostgreSQL  16	\N	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	 PostgreSQL /b9b4cf99149f76d2 	400
182	10.143.17.88	DEV m9wvmh onepulseplatform-8ec602c4	\N	asia-southeast2	PostgreSQL  12	\N	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	 PostgreSQL /e4f88211cf99b3e7 	400
183	10.143.34.26	PROD babq79 digitalpartner-new-6d79c8d4	Digital Partner	CLOUD	PostgreSQL  12	Digital Partner	4	8	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Herdianto  	400
184	10.143.21.8	UAT gyy08m dbedoc-node-0	edoc	UBUNTU 10,22 GCP	PostgreSQL 12.16	edoc (cloud_VM)	1	1	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Benny Setiawan user/pass: edocplai/edoc2022 	400
185	10.143.36.140	DEV pfpbtb edoc (cloud_VM) edoc PRD	edoc	CLOUD	PostgreSQL 12.16	edoc (cloud_VM)	1	1	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Benny Setiawan user/pass: edocplai/edoc2022 	400
186	10.143.17.202	UAT fynu69 phsdb-f2775ab1	PHS	CLOUD	PostgreSQL  14	PHS	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
187	10.143.34.60	PROD krenc4 dqs-0d921dad	DQS	CLOUD	PostgreSQL  14	DQS	2	6	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	 	400
188	10.143.17.86	DEV yw4ncv dqs-21dddb1e	DQS Dev	CLOUD	PostgreSQL  14	DQS Dev	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
189	10.143.34.106	PROD asne4l pruforce-3f630c90	Pruforce	CLOUD	PostgreSQL  16	Pruforce	2	8	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
190	10.141.12.7	PROD DigiService DigiService	DigiService	CLOUD	PostgreSQL 10.6	\N	2	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	 PostgreSQL /Password09 	400
191	10.143.17.193	UAT pdf47h misdb-252a6e7d	mis-db uat	CLOUD Red Hat Enterprise Linux 	PostgreSQL  13	mis-db uat	2	6	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  "username":"dev-svc"\n"password":"n@WXnqZHwNZg7/td"\n"username":"dev-user"\n"password":"/vSwLnEYYDul8P!G"\n"password":"nog1-ePSZ/vgrL7-","username":"dev-ro"	400
192	10.143.34.230	PROD s3rcg0 oltp-5b56f831-replica001	OLTP Prod	CLOUD	PostgreSQL  13	OLTP Prod	8	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
193	10.143.34.23	PROD o7pm17 datalake01-8b1c79f9	Datalake	CLOUD	PostgreSQL  13	Datalake	8	32	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
194	10.143.17.95	DEV c5wvjk datalake-new-5d7890fa	Datalake Dev	CLOUD	PostgreSQL  13	Datalake Dev	2	8	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
195	10.141.15.39	PROD wwe3r3 idlifewwe3r3jbi	SUN	CLOUD	SQLSERVER  2016 STD	SUN Payment	8	32	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Salman Farizi sun.dbadmin  Password09	400
196	10.141.15.36	PROD wwe3r3 idlifewwe3r3bcp	TLM	CLOUD	SQLSERVER  2016 STD	TLM Payment	8	32	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Salman Farizi user : SRVPLAIPRTLMSMARTS01 Password : Q42PDxA(	400
197	10.143.34.36	STAGGING j5toic mitracommprd-1a1636b9	smsgw_prod	CLOUD SQL UBUNTU 20	SQLSERVER 2019 STD	mitracom	4	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Aji  "default_password":"D<1n=j}K",\n "default_username":"mitracommadm",\n "root" d6fs4NeX" 	400
198	10.141.23.9	DEV c5wvjk win1-c5wvjk-001	ifrs17	CLOUD	SQLSERVER 2019 STD	Ifrs17 (cloud_VM)	10	32	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Agam Adhinegara user/pass: sa/Password09 user/pass : PRUASIA\\407409\tWindows_autentication (superuser)	400
199	10.143.34.120	PROD babq79 pruservices-b6414432	Pruservices	CLOUD	PostgreSQL  16	Pruservices	4	8	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  username: operation_user_prd | password: p+FNaj+34-49{H1J{>9!\n    "password": "ylsaTGbqz!ZcV8@H",\n    "username": "operation_user_prd"	400
200	10.143.17.59	DEV pdf47h keycloackdb-0ad4bfd6	keycloack	UBUNTU 10,22 GCP	PostgreSQL 13.15	keycloack	4	8	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Syatria Babullah user/pas: "PostgreSQL "/d5iv2cp2t2LmRfIXECtypk1JBh71r7bl	400
\.


--
-- Data for Name: hardware270225; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.hardware270225 (id, make, model, serial, os_name, os_version, type, ram, cpu, status, current, company_id, user_id, provaider_id, purchased_at, created_at, updated_at, deleted_at, note) FROM stdin;
125	10.170.49.78	NPRD	sidhouwinepvdb1	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N
121	10.170.49.197	NPRD	vidhowndeprap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N
122	10.170.49.210	NPRD	vidhodwinintdb7	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Dev Moveit
123	10.170.49.216	NPRD	sidhouwinepvap1	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N
96	10.143.27.57	DB SCRM UAT	service db cloud	UBUNTU 10,22 GCP	SQL Server 2022	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	\N
147	10.143.27.238	LINUX SQLSERVER PRD	IDLIFED4VZP1CVI	Ubuntu 20.04	SQL Server 2022	0	8	4	0	t	1	1	5	2024-11-07 00:00:00	2024-11-07 08:34:07	2024-11-07 08:34:08	\N	sqlserver\n\n@78$hZ!L
5	10.170.53.56	Database Leads PRD	VIDDCLXPAOBDB05	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	31	36	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-28 10:44:23	\N	109 GB
10	10.171.84.56	SME Pruworks PRD	VIDDCLXPSMEDB02	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	23G	20	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-10-19 20:05:17	\N	217 GB
6	10.170.53.57	Training PRD	VIDDCLXPAOBDB06	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	32	10	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-10-20 04:04:31	\N	109 GB
16	10.170.53.108	Base DB PRD	VIDDCLXPBSEDB06	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	62	8	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	59 GB
9	10.171.84.55	SME omni PRD	VIDDCLXPSMEDB01	Red Hat 6.10 (RHEL)	PostgreSQL 14.13	0	19	6	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-01-20 16:28:53	\N	79 GB
8	10.170.53.23	PRUForce DB PRD	VIDHOPLINAOBDB1	Red Hat 6.10 (RHEL)	PostgreSQL 14.13 (EnterpriseDB Advanced Server 14.13.1)	0	171	20	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-01-06 11:44:20	\N	1400 GB
103	10.170.52.28	NPRD	WINTEL	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3
104	10.170.53.114	NPRD	vidhownp2faap01 	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3
105	10.170.48.110	NPRD	VIDHOLXPBAKAP01	Red Hat  8.10  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3
108	10.171.86.72	NPRD	LINUX RHELL	Red Hat  7.9  (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.10 to 14.3
109	10.171.213.79	NPRD	VIDDRLXUSMEAP04	Red Hat  8.1 (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.10 to 14.3
110	10.170.49.150	NPRD	LINUX RHELL	Red Hat  7.9  (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-12-13 09:41:37	\N	Postgres v.10 to 14.3 | fuse DB  pruasia\\sqlagtsvcdev\nPassword09
127	10.170.49.81 	NPRD	sidhodwinepvdb1	Windows Server 2012 R2 	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	e-Payment Voucher
113	10.171.210.25	NPRD	VIDDRWNPCCVAP01	Windows Server 2016	SQL Server 2016 express SP3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Uninstal SQLEXPRESS
114	10.171.212.142	NPRD	viddcwndhpxap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N
115	10.170.48.85	NPRD	WINTEL	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N
116	10.170.49.11	NPRD	VIDHOWNUPDCAP01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N
128	10.170.49.88 	NPRD	VIDHOWNUINTDB01	Windows Server 2019	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N
120	10.170.49.196	NPRD	vidhownupacdb01	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Finger Print
107	10.171.84.78	NPRD	viddolxpgpmap01	Red Hat  7.9  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3
69	10.170.48.63	Is not DB Server PRD	sidhopwinscmap1	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Taufik Ridwan
99	10.143.17.69	PSA UAT	PSA	UBUNTU 10,22 GCP	Google Cloud	0	16	8	0	t	1	1	2	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	user/pas : postgres/AmZsWOWWl949v3lAtKMJeT9AVAqlBbHu
118	10.170.49.188	NPRD	vidhodwinintdb1	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N
119	10.170.49.195	NPRD	vidhowndefmdb01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N
60	10.170.49.107	UAT	viddrlxdatsap01	Red Hat 6.10 (RHEL)	Oracle Database 11g Enterprise Edition	0	31	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS
141	10.170.49.179	DR GP	VIDHOLXDGPMAP02 	Red Hat 7.10 (RHEL)	Greenplum Database 4.3.33	0	62	24	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Arif Rahman
133	10.171.211.50	DR GP	SIDDCLXPGPMAP01	Red Hat 6.10 (RHEL)	New Greenplum Master	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi
135	10.171.211.123	DR GP	SIDDCLXPGPNAP01	Red Hat 6.10 (RHEL)	New Greenplum Node 1	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi
136	10.171.211.124	DR GP	SIDDCLXPGPNAP02	Red Hat 6.10 (RHEL)	New Greenplum Node 2	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi
137	10.171.211.125	DR GP	SIDDCLXPGPNAP03	Red Hat 6.10 (RHEL)	New Greenplum Node 3	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi
138	10.171.211.126	DR GP	SIDDCLXPGPNAP04	Red Hat 6.10 (RHEL)	New Greenplum Node 4	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi
139	10.171.211.127	DR GP	SIDDCLXPGPNAP05	Red Hat 6.10 (RHEL)	New Greenplum Node 5	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi
140	10.171.211.128	DR GP	SIDDCLXPGPNAP06	Red Hat 6.10 (RHEL)	New Greenplum Node 6	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi
134	10.171.211.51	DR GP	SIDDCLXPGPSAP01	Red Hat 6.10 (RHEL)	New Greenplum Standby	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi
7	10.170.53.131	New ODS - PROD	VIDHOLXPODSDB01	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	160	16	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	997 GB
56	10.171.84.43	RESDB PRD	VIDDCLXPODMDB01	Red Hat  7.9  (RHEL)	DB2 v10.5.0.3	0	31	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS  \n user SPLAIODM pass: Password09 di ip\n10.171.84.43 (BRMS)
159	10.170.53.78	ORACLE PRD	VIDHOWNPINSDB01	WINDOWS	Oracle 11g Windows	0	32	8	0	t	1	1	3	2025-02-21 00:00:00	2025-02-21 15:02:20	2025-02-21 15:02:20	\N	CREATE USER mis_user IDENTIFIED BY Password09;
48	10.171.84.124	GreenPlum Node 2 PRD	SIDDRLXPGPNAP02	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS
55	10.170.53.99	CM PRD	PRUIDWFCM02	AIX 7	DB2 v10.5.0.8	0	42	3	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS \nkill locking db2 \n- db2top -d bpmdbphs (DB_Name)\n- tekan shift u\n- Klik a lalu ketik id yg mau di kill\n- db2 "force application(28866 contoh)"\ndb2 "force application(22948)"
61	10.171.83.52	DB Server SCCM Server PRD	viddcwnpscmap02	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Abdul Qahar
68	10.170.53.186	Is not DB Server PRD	vidhownpprpap02	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow
74	10.170.53.185	Is not DB Server New Actuary Apps PRD	vidhownpprpap01	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Daniel Agustinus Rahardjo / Salman Farizi 
76	10.170.48.33	Decommissioning NICE  PRD	vidhownpndsdb03	Windows Server 2016	SQL Server 2012	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani
78	10.171.140.90	Is not DB Server ( No DB Service) PRD	viddcwnppbhap01	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Arif Hidayat Husni
58	10.171.82.73	UAT	sidhopwinvnxap1	Red Hat 6.10 (RHEL)	MySQL Database Server	0	31	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS
59	10.170.49.144	UAT	vidhownuinsdb01	Windows Server 2012 R2	Oracle Database 11g Enterprise Edition	0	31	8	0	t	1	1	3	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-18 18:00:58	\N	Afdoli Fahmi , MIS\n.\\sqlagtsvcdev\nPassword09
53	10.171.84.104	BPM PRD	VIDDCLXPBPMDB01	Red Hat 6.10 (RHEL)	DB2 v10.5.0.3	0	58	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS\nkill locking db2 \n- db2top -d bpmdbphs (DB_Name)\n- tekan shift u\n- Klik a lalu ketik id yg mau di kill\n- db2 "force application(28866 contoh)"\ndb2 "force application(22948)"
54	10.170.53.150	HPX PRD	VIDHOLXPHPEDB01	Red Hat  8.10  (RHEL)	DB2 v10.5.0.3	0	15	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS
79	10.143.34.54	PMN DB nbwf PRD	service db cloud	UBUNTU 10,22 GCP	EnterpriseDB 9.6.2.7	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-11-14 17:52:24	\N	10.143.34.54 \nPMN DB
97	10.143.34.5 	DB SCRM PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2022	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	1433  sqlserver/ua}T&-9[
98	10.141.48.131	STAGGING REMOTE SQL NRPD	service db cloud	Windows Server 2016 GCP	Client Cloud Remote Server	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	\N
75	10.170.48.102	Decommissioning PRD	vidhownpintdb07	Windows Server 2016	SQL Server 2012	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow
144	10.170.49. 	DBA_USER DEV	VID	Red Hat Enterprise Linux 	Postgres EDB 14.0	0	62G	24	0	t	1	1	4	2024-10-22 00:00:00	2024-10-22 20:18:04	2024-10-23 07:15:51	\N	10.170.49.180
143	10.170.49.181	GP DEV	VIDHOLXDGPNAP04	Red Hat Enterprise Linux 	Greenplum Database 4.3.33	0	62G	24	0	t	1	1	4	2024-10-22 00:00:00	2024-10-22 20:11:06	2024-10-22 20:22:04	\N	VIDHOLXDGPNAP04
142	10.170.49.180	GP DEV	VIDHOLXDGPNAP03	Red Hat Enterprise Linux 	Greenplum Database 4.3.33	0	62G	24	0	t	1	1	4	2024-10-22 00:00:00	2024-10-22 18:35:26	2024-10-22 20:21:47	\N	VIDHOLXDGPNAP03
148	10.170.53.202	TRIAL DB SQL SERVER	TRIAL	WINDOWS	SQL Server 2022	0	16	8	9	t	1	1	5	2024-11-13 00:00:00	2024-11-13 07:52:19	2024-11-13 07:52:27	\N	10.170.53.202\n.\\admintemp\nPassword09
156	10.170.109.42	Server Recording ACRA  PRD	VIDPTWNPACRAP01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	1	2025-01-14 00:00:00	2025-01-14 09:07:24	2025-01-14 09:07:37	\N	Login : VIDPTWNPACRAP01\\pruadmin\nPassword : P@ssw0rd\nVIDPTWNPACRAP01
117	10.170.49.123	NPRD	SIDHOUWINSAPDB2	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-11-11 13:43:00	\N	PRUASIA\\sqlagtsvcdev\nPassword09
145	10.170.49.168	ON PREM ESUB NEWODS AOB UAT	VIDHOLXUINTDB02	Red Hat  7.9  (RHEL)	PostgreSQL 10.4	0	15	8	0	t	1	1	4	2024-10-23 00:00:00	2024-10-23 10:43:56	2024-10-30 10:35:00	\N	GRANT SELECT ON ALL TABLES IN SCHEMA pd_activity_management TO "mis-read";\nGRANT SELECT ON pd_activity_management.reasons TO  "mis-read";\nGRANT USAGE ON SCHEMA pd_activity_management TO "mis-read";\n\n\n
111	10.170.49.191	NPRD	vidholdodsdb1	Red Hat  7.9  (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-12-13 09:41:05	\N	Upgrade Postgres v.10 to 14.3 pruasia\\sqlagtsvcdev\nPassword09
86	10.141.23.11	Renova (Cloud VM) Renova_Individual UAT	service db cloud	Windows Server 2016	SQL Server 2017 std edition	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-01-10 10:30:37	\N	user/pass: renovaid/Password12 | sa/Password09
152	10.170.49. 	unknow	unknow	unknow	unknow	0	1	1	0	t	1	1	2	2024-12-17 00:00:00	2024-12-17 11:24:28	2024-12-17 15:52:05	\N	zero
126	10.170.49.80	UAT	SIDHOUWINSFTP01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-01-28 10:02:30	\N	Hanan
157	10.170.49.73	UAT 	VIDDCLXDGAIAPP01	Red Hat Enterprise Linux 	Postgres 14.0	0	16	23	0	t	1	1	4	2025-02-06 00:00:00	2025-02-06 14:38:58	2025-02-06 14:38:58	\N	VIDDCLXDGAIAPP01
45	10.171.84.70	GreenPlum Master PRD	SIDDRLXPGPMAP01 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2025-01-15 10:58:50	\N	Afdoli Fahmi , MIS\n/GPDB_DATA/master/gpseg-1/
57	10.170.53.14	MFPDATA PRD	VIDHOPLINIMFDB1	Red Hat (RHEL) 8.10	DB2 v11.5.8.0	0	62	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-05 10:52:32	\N	Afdoli Fahmi , MIS
62	10.170.53.198	DB Server iCare & IVRDB PRD	vidhowpivrdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow
67	10.170.53.199	DB Server iCare & IVRDB PRD	viddrwpivrdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow
71	10.171.210.50	NICE Engage Unified PRD	siddrwnpneuap01	Windows Server 2016	no db	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-02 15:33:59	\N	Ridwan Royani
81	10.141.15.39	SUN SUN PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-11-26 13:43:18	\N	SUN\n10.141.15.39 (user DB)\nsun.dbadmin \nPassword09
146	10.171.84.154	ICN PRD	VIDDCLXPICNDB01	Red Hat (RHEL) 8.10	DB2 v11.5.8.0	0	7.5 GB	2	0	t	1	1	1	2024-11-05 10:00:00	2024-11-05 10:58:11	2024-11-05 10:58:11	\N	Afdoli Fahmi , MIS
151	10.143.17.126	x86_64-pc-linux-gnu Debian  PRD	 on x86_64-pc-linux-gnu, compiled by Debian 	CLOUD SQL	PostgreSQL 15.8	0	16	32	0	t	1	1	4	2024-12-13 00:00:00	2024-12-13 14:55:20	2024-12-16 09:53:41	\N	ALTER USER prumagnumpure WITH PASSWORD 'cNA4-K/C2VZ3Wh!!';\n5432\n
155	10.143.27.236	Cloud INTUATDB PRD	IDLIFED4VZP1CVI	Ubuntu 20	SQL Server 2019	0	6	2	0	t	1	10	1	2024-12-17 10:00:00	2024-12-17 16:00:37	2025-02-06 09:45:15	\N	    "private_address": "10.143.27.236",\n    "root_password": "+}CGp[@-"\n}\nuser sqlserver
28	10.170.48.112	Customer Analytic PRD	SIDHOPWINDALDB1	Windows Server 2016	SQL Server 2019 (RTM)	0	48	3	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-28 10:03:49	\N	Afdoli Fahmi \nHani Asri Guardiani
154	10.170.49. 	unknow	unknow	unknow	unknow	0	22	2	0	t	1	1	2	2024-12-17 00:00:00	2024-12-17 15:53:01	2024-12-17 15:53:01	\N	zero
18	10.170.53.147	Consolidate Database Server(XML) PRD	VIDHOWNPINTDB01	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-10 11:13:20	\N	Afdoli Fahmi \nowner Nanda widy
19	10.170.53.106	ODS PRD	VIDHOWNPODSDB01	Windows Server 2016	SQL Server 2016	0	32	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 
21	10.170.48.98	Reporting DB SRSS PRD	VIDHOWNPREPDB01	Windows Server 2016	SQL Server 2016	0	32	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 
22	10.170.48.177	Database Solarwind, SCCM PRD	SIDHOPWINIFRDB1	Windows Server 2016	SQL Server 2016	0	16	3	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-27 15:48:08	\N	Afdoli Fahmi \nSQLAGTSVCPROD Password09
23	10.170.48.58	Internal DB - 03 PRD	VIDHOWNPINTDB03	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 
24	10.170.48.211	NICE DB PRD	VIDHOWNPNDSDB01	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani
25	10.170.48.44	NICE DB PRD	VIDHOWNPNDSDB02	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani
26	10.170.48.186	Ops Dashboard DB PRD	VIDHOWNPOPSDB01	Windows Server 2016	SQL Server 2016	0	8	2	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 
27	10.170.48.85	GPP Report PRD	SIDHOPWINMDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 
29	10.170.53.46	CRM Archive PRD	VIDHOWNPCRMDB03	Windows Server 2016	SQL Server 2016	0	24	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Victor Liliwidjaja
30	10.170.48.84	Reinsurance DB PRD	VIDHOWNPREIDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Fikrilsyah Algoumar
31	10.170.48.77	E-Submission NB PRD	VIDHOWNPXARDB01	Windows Server 2016	SQL Server 2016	0	8	2	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-10 11:13:44	\N	Nanda Widy
32	10.170.48.122	Sharepoint DB PRD	SIDHOPWINSHPDB1	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Syofianer Fitra
33	10.170.48.215	K2 DB server PRD	VIDHOWNPKTWDB01	Windows Server 2016	SQL Server 2016	0	20	2	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Syofianer Fitra
34	10.170.53.91	SUN GL PRD	SIDHOPWINSUNDB1	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Syofianer Fitra
35	10.170.53.187	New Actuary DB PRD	VIDHOWNPPRPDB01	Windows Server 2016	SQL Server 2016	0	64	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Syofianer Fitra
15	10.171.84.92	Postgre Enablement Tribe COMPLIANCE PRD	VIDDCLXPENTDB01	Red Hat 6.10 (RHEL)	PostgreSQL 10.4	0	15	4	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	10 GB
17	10.171.84.100	AI DB PRD	VIDDCLXPAICDB01	Red Hat 6.10 (RHEL)	PostgreSQL 10.4	0	32	4	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	197 GB
14	10.170.53.200	Corespondence DB PRD	VIDDCLXPCDSDB01	Red Hat 6.10 (RHEL)	PostgreSQL 10.7 	0	31	4	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	443 GB
11	10.171.84.68	SME DB PRD	VIDDCLXPSMEDB04-new	Red Hat 6.10 (RHEL)	PostgreSQL 10.7 	0	19	6	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	 GB
2	10.170.53.103	AOB EPOLICY DB (WAB,Fuse)  PRD	VIDDCLXPAOBDB04	Red Hat  7.9  (RHEL)	EnterpriseDB 14.13.1	0	46	20	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-05 09:56:15	\N	200 GB DISK --- ada versi 14 UP
1	10.170.53.102	AOB DB ESUB PRD	VIDDCLXPAOBDB03	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.2.7	0	32	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	814 GB
13	10.171.84.117	Magnum Pure PRD	VIDDCLXPMGPDB01	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.2.7	0	16	16	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	571 GB
12	10.170.53.101	nbwf,  DB Workflow PRD	VIDDCLXPAOBDB02	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.2.7	0	50	28	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-28 10:24:26	\N	892 GB
4	10.171.140.16	Payment Database PRD	VIDDCLXPNPHDB01-New	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	32	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	688 GB
3	10.170.53.29	BPM DB PRD	VIDHOPLINBPMDB1	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	64	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	148 GB
20	10.170.53.36	Internal DB (Moveit) PRD	VIDHOWNPINTDB02	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-14 10:30:13	\N	Afdoli Fahmi -- > moveitdmz Password09
36	10.170.53.68	CRM PRD	VIDHOWNPCRMDB02	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Victor Liliwidjaja
37	10.170.53.44	CRM PRD	VIDHOWNPCRMDB01	Windows Server 2016	SQL Server 2016	0	39	12	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Victor Liliwidjaja
38	10.170.53.105	DataMart PRD	VIDHOWNPDTMDB01	Windows Server 2016	SQL Server 2016	0	32	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Fikrilsyah Algoumar
39	 10.170.53.49	PG BCA PRD	VIDHOWNPH2BDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Bhimo Bhaskoro
40	10.170.53.153	OCR DB PRD	VIDDCWNPOCRDB01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Juliana
41	10.170.53.5	EPOS DB PRD	VIDHOPWINPOSDB1	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 
42	10.171.84.205	New IFRS  PRD	VIDDRWNPIFRDB01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Mimi Winata
43	10.171.84.215	Power BI PRD	VIDDCWNPPBIAP01	Windows Server 2016	SQL Server 2016	0	96	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Rizky Karunia
129	10.170.216.100	PRD	SIDHOWNPCCVAP01	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Upgrade to 2016 SP 3
130	10.170.53.61	PRD	vidhownpcrmap03	Windows Server 2019 STD	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Microsoft SQL Server 2008 R2 
150	10.143.34.85	PRD	pruidlife-prod	CLOUD SQL  SVR	newpruworks	0	16	8	0	t	1	1	5	2024-11-19 00:00:00	2024-11-19 13:53:08	2024-11-19 14:30:32	\N	 "default_password": "\\u003cM?WuPtb",\n  "default_username": "pruuser", "root_password": "K2b\\u003ej1ly"
46	10.171.84.71 	GreenPlum Second Master PRD	SIDDRLXPGPSAP01	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS
47	10.171.84.123	GreenPlum Node 1 PRD	SIDDRLXPGPNAP01	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS
49	10.171.84.125	GreenPlum Node 3 PRD	SIDDRLXPGPNAP03 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS
50	10.171.84.126	GreenPlum Node 4 PRD	SIDDRLXPGPNAP04 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS
51	10.171.84.128 	GreenPlum Node 5 PRD	SIDDRLXPGPNAP05	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS
52	10.171.84.129	GreenPlum Node 6 PRD	SIDDRLXPGPNAP06	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS
63	10.170.48.37	DB Nice Server Playback Portal PRD	vidhownpnpsdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-02 15:35:03	\N	Ridwan Royani
64	10.170.48.101	DB Server New AWMS Server (Tower) PRD	viddcwnpawmap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Abdul Qahar
65	10.170.48.35	DB Server Sentinel  PRD	vidhownpnmsap02	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-02 15:35:36	\N	Ridwan Royani, Manage by Nice Vendor
66	10.170.109.19	DB Server Q-Matic PRD	vidptwnpqmtap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani
70	10.170.216.196	DB Server WINPAKPRO PRD	sidpcwnpacdap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow
72	10.170.48.235	DB Server(NewSolarWins DB) PRD	vidhopwinifrdb1	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow
73	10.170.216.69	DB Server FXAW PRD	vidpcwnpawmap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow
77	10.170.48.128	DB Server SOLARWIN_ORION PRD	vidhopwinswdap1	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow
80	10.141.15.36	TLM TLM PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-11-29 16:10:01	\N	RDP\nuser : SRVPLAIPRTLMSMARTS01\nPassword : Q42PDxA(
82	10.143.34.42	One Pulse Platform onepulse PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	\N
83	10.143.17.6	smartclaim smartclaim PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	\N
84	10.143.34.206	smartclaim ( replica) smartclaim PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	\N
85	10.143.34.202	smartclaim ( master) smartclaim PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	\N
87	10.143.34.79	Renova (Cloud Instance) Renova_Individual PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2019 std edition	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-01-10 10:33:08	\N	user/pass: renovadb/5J+a]OlQ | user/pass: sqlserver/XpIeX_N&
88	10.141.23.9	Ifrs17 (cloud_VM) ifrs17 PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016 std edition	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: sa/Password09 | user/pass : PRUASIA\\407409\tWindows_autentication (superuser)
89	10.143.27.253	jatisSMS (Cloud Instance)  PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016 std edition	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: sqlserver/Svu72BhZ
90	10.143.21.8	edoc (cloud_VM) edoc PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: edocplai/edoc2022
91	10.143.17.29	edoc (cloud_Instance) edoc PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: postgres/o1Gy1WbqQ3DZcTt4hyVGzkCzEHnFEKxb | user/pass:edocplai/U0Y42h8mngzu-D8@
92	10.143.36.140	edoc (cloud_VM) edoc PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: edocplai/edoc2022
93	10.143.34.223	edoc (cloud_Instance) edoc PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: postgres/agG0nkLGOCphBdCwsUD5Cd1B8W0TmADT | user/pass: edocplai/IOSBQgiK6hOiEvu-
95	10.143.17.59	keycloack keycloack PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 13.13	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pas: postgres/d5iv2cp2t2LmRfIXECtypk1JBh71r7bl
100	10.143.34.70	PSA PRD	PSA	UBUNTU 10,22 GCP	Google Cloud	0	16	8	0	t	1	1	2	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	user/pas : postgres/bFAyEyz383ITMZ8MHImEfAnDzKZSTO74
101	10.143.34.101	PSA PRD	PSA	UBUNTU 10,22 GCP	Google Cloud	0	16	8	0	t	1	1	2	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	user/pas : postgres/xIqL6MHtPJWYA1OjaPaW4n9UM844LYdF
102	10.170.52.70	PRD	VIDHOWNPSFSAP04	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3
106	10.170.48.109	PRD	VIDHOLXPBAKAP02	Red Hat  7.9  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3
112	10.171.212.215	PRD	VIDDRWNDNRSDB01	Windows Server 2016	SQL Server 2016 express SP3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Uninstal SQLEXPRESS
131	10.170.49.136	DBA_USER DEV	VIDDRLXUGBQDB01	Red Hat  8.10  (RHEL)	Postgres 16.0	0	125GB	32	0	t	1	1	4	2024-10-10 00:00:00	2024-10-10 21:31:41	2024-10-10 21:31:41	\N	DEV NEW Postgres 16 | dba_user dba_user | 5432 | owner | Radit
158	10.171.84.73	VIDDCLXPGA PRD	VIDDCLXPGA	Red Hat Enterprise Linux 	Postgres 14.0	0	8	2	0	t	1	1	2	2025-02-06 00:00:00	2025-02-06 14:44:55	2025-02-06 14:44:55	\N	VIDDCLXPGA
94	10.143.34.226	OLTP DB  PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 13.13	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	oltp-svc/KT3meM@r-BdEBF1p
132	10.171.86.72	NBWF UAT	SR02701142	Red Hat  7.9  (RHEL)	Postgres EDB 14.0	0	16	8	0	t	1	1	4	2024-10-12 00:00:00	2024-10-12 16:31:46	2024-10-12 16:31:46	\N	SR02701142
124	10.170.49.217	NPRD	vidhownuefmap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-02-26 14:53:20	\N	AJI\n\nPRUASIA\\sqlagtsvcdev  -> Password09
161	10.170.48.190	DCI CFS PRD	VIDHOWPCFSAP1	WINDOWS 2012 R2	Microsoft SQL Server 2012	0	8	4	0	t	1	1	1	2025-02-26 00:00:00	2025-02-26 15:31:15	2025-02-26 15:31:15	\N	Henry Lois Sumendap
\.


--
-- Data for Name: hardware_050425; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.hardware_050425 (id, make, model, serial, os_name, os_version, type, ram, cpu, status, current, company_id, user_id, provaider_id, purchased_at, created_at, updated_at, deleted_at, note) FROM stdin;
122	10.170.49.210	NPRD	vidhodwinintdb7	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Dev Moveit
123	10.170.49.216	NPRD	sidhouwinepvap1	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N
96	10.143.27.57	DB SCRM UAT	service db cloud	UBUNTU 10,22 GCP	SQL Server 2022	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	\N
147	10.143.27.238	LINUX SQLSERVER PRD	IDLIFED4VZP1CVI	Ubuntu 20.04	SQL Server 2022	0	8	4	0	t	1	1	5	2024-11-07 00:00:00	2024-11-07 08:34:07	2024-11-07 08:34:08	\N	sqlserver\n\n@78$hZ!L
5	10.170.53.56	Database Leads PRD	VIDDCLXPAOBDB05	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	31	36	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-28 10:44:23	\N	109 GB
10	10.171.84.56	SME Pruworks PRD	VIDDCLXPSMEDB02	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	23G	20	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-10-19 20:05:17	\N	217 GB
6	10.170.53.57	Training PRD	VIDDCLXPAOBDB06	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	32	10	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-10-20 04:04:31	\N	109 GB
103	10.170.52.28	NPRD	WINTEL	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3
104	10.170.53.114	NPRD	vidhownp2faap01 	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3
105	10.170.48.110	NPRD	VIDHOLXPBAKAP01	Red Hat  8.10  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3
108	10.171.86.72	NPRD	LINUX RHELL	Red Hat  7.9  (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.10 to 14.3
109	10.171.213.79	NPRD	VIDDRLXUSMEAP04	Red Hat  8.1 (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.10 to 14.3
110	10.170.49.150	NPRD	LINUX RHELL	Red Hat  7.9  (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-12-13 09:41:37	\N	Postgres v.10 to 14.3 | fuse DB  pruasia\\sqlagtsvcdev\nPassword09
127	10.170.49.81 	NPRD	sidhodwinepvdb1	Windows Server 2012 R2 	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	e-Payment Voucher
113	10.171.210.25	NPRD	VIDDRWNPCCVAP01	Windows Server 2016	SQL Server 2016 express SP3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Uninstal SQLEXPRESS
114	10.171.212.142	NPRD	viddcwndhpxap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N
115	10.170.48.85	NPRD	WINTEL	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N
116	10.170.49.11	NPRD	VIDHOWNUPDCAP01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N
128	10.170.49.88 	NPRD	VIDHOWNUINTDB01	Windows Server 2019	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N
120	10.170.49.196	NPRD	vidhownupacdb01	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Finger Print
69	10.170.48.63	Is not DB Server PRD	sidhopwinscmap1	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Taufik Ridwan
99	10.143.17.69	PSA UAT	PSA	UBUNTU 10,22 GCP	Google Cloud	0	16	8	0	t	1	1	2	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	user/pas : postgres/AmZsWOWWl949v3lAtKMJeT9AVAqlBbHu
118	10.170.49.188	NPRD	vidhodwinintdb1	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N
119	10.170.49.195	NPRD	vidhowndefmdb01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N
60	10.170.49.107	UAT	viddrlxdatsap01	Red Hat 6.10 (RHEL)	Oracle Database 11g Enterprise Edition	0	31	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS
8	10.170.53.23	PRUForce DB PRD	VIDHOPLINAOBDB1	Red Hat 6.10 (RHEL)	(EnterpriseDB Advanced Server 14.13.1)	0	171	20	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-01-06 11:44:20	\N	1400 GB
133	10.171.211.50	DR GP	SIDDCLXPGPMAP01	Red Hat 6.10 (RHEL)	Greenplum Node Master	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi
7	10.170.53.131	New ODS - PROD	VIDHOLXPODSDB01	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	160	16	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	997 GB
48	10.171.84.124	GreenPlum Node 2 PRD	SIDDRLXPGPNAP02	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS
61	10.171.83.52	DB Server SCCM Server PRD	viddcwnpscmap02	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Abdul Qahar
68	10.170.53.186	Is not DB Server PRD	vidhownpprpap02	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow
74	10.170.53.185	Is not DB Server New Actuary Apps PRD	vidhownpprpap01	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Daniel Agustinus Rahardjo / Salman Farizi 
76	10.170.48.33	Decommissioning NICE  PRD	vidhownpndsdb03	Windows Server 2016	SQL Server 2012	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani
78	10.171.140.90	Is not DB Server ( No DB Service) PRD	viddcwnppbhap01	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Arif Hidayat Husni
58	10.171.82.73	UAT	sidhopwinvnxap1	Red Hat 6.10 (RHEL)	MySQL Database Server	0	31	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS
9	10.171.84.55	SME omni PRD	VIDDCLXPSMEDB01	Red Hat 6.10 (RHEL)	PostgreSQL 14.13	0	31	24	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-03-20 11:29:37	\N	79 GB
59	10.170.49.144	UAT	vidhownuinsdb01	Windows Server 2012 R2	Oracle Database 11g Enterprise Edition	0	31	8	0	t	1	1	3	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-18 18:00:58	\N	Afdoli Fahmi , MIS\n.\\sqlagtsvcdev\nPassword09
121	10.170.49.197	NPRD	vidhowndeprap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-03-25 17:39:18	\N	11
79	10.143.34.54	PMN DB nbwf PRD	service db cloud	UBUNTU 10,22 GCP	EnterpriseDB 9.6.2.7	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-11-14 17:52:24	\N	10.143.34.54 \nPMN DB
83	10.143.17.6	smartclaim smartclaim PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	\N
98	10.141.48.131	STAGGING REMOTE SQL NRPD	service db cloud	Windows Server 2016 GCP	Client Cloud Remote Server	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	\N
75	10.170.48.102	Decommissioning PRD	vidhownpintdb07	Windows Server 2016	SQL Server 2012	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow
156	10.170.109.42	Server Recording ACRA  PRD	VIDPTWNPACRAP01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	1	2025-01-14 00:00:00	2025-01-14 09:07:24	2025-01-14 09:07:37	\N	Login : VIDPTWNPACRAP01\\pruadmin\nPassword : P@ssw0rd\nVIDPTWNPACRAP01
117	10.170.49.123	NPRD	SIDHOUWINSAPDB2	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-11-11 13:43:00	\N	PRUASIA\\sqlagtsvcdev\nPassword09
145	10.170.49.168	ON PREM ESUB NEWODS AOB UAT	VIDHOLXUINTDB02	Red Hat  7.9  (RHEL)	PostgreSQL 10.4	0	15	8	0	t	1	1	4	2024-10-23 00:00:00	2024-10-23 10:43:56	2024-10-30 10:35:00	\N	GRANT SELECT ON ALL TABLES IN SCHEMA pd_activity_management TO "mis-read";\nGRANT SELECT ON pd_activity_management.reasons TO  "mis-read";\nGRANT USAGE ON SCHEMA pd_activity_management TO "mis-read";\n\n\n
111	10.170.49.191	NPRD	vidholdodsdb1	Red Hat  7.9  (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-12-13 09:41:05	\N	Upgrade Postgres v.10 to 14.3 pruasia\\sqlagtsvcdev\nPassword09
86	10.141.23.11	Renova (Cloud VM) Renova_Individual UAT	service db cloud	Windows Server 2016	SQL Server 2017 std edition	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-01-10 10:30:37	\N	user/pass: renovaid/Password12 | sa/Password09
126	10.170.49.80	UAT	SIDHOUWINSFTP01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-01-28 10:02:30	\N	Hanan
157	10.170.49.73	UAT 	VIDDCLXDGAIAPP01	Red Hat Enterprise Linux 	Postgres 14.0	0	16	23	0	t	1	1	4	2025-02-06 00:00:00	2025-02-06 14:38:58	2025-02-06 14:38:58	\N	VIDDCLXDGAIAPP01
45	10.171.84.70	GreenPlum Master PRD	SIDDRLXPGPMAP01 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2025-01-15 10:58:50	\N	Afdoli Fahmi , MIS\n/GPDB_DATA/master/gpseg-1/
62	10.170.53.198	DB Server iCare & IVRDB PRD	vidhowpivrdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow
67	10.170.53.199	DB Server iCare & IVRDB PRD	viddrwpivrdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow
55	10.170.53.99	CM DB2 PRD	PRUIDWFCM02	AIX 7	DB2 v10.5.0.8	0	42	3	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS \nkill locking db2 \n- db2top -d bpmdbphs (DB_Name)\n- tekan shift u\n- Klik a lalu ketik id yg mau di kill\n- db2 "force application(28866 contoh)"\ndb2 "force application(22948)"
57	10.170.53.14	MFPDATA DB2 PRD	VIDHOPLINIMFDB1	Red Hat (RHEL) 8.10	DB2 v11.5.8.0	0	62	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-05 10:52:32	\N	Afdoli Fahmi , MIS
148	10.170.53.202	TRIAL DB SQL SERVER	TRIAL	WINDOWS 2012 R2	SQL Server 2022	0	16	8	9	t	1	1	5	2024-11-13 00:00:00	2024-11-13 07:52:19	2024-11-13 07:52:27	\N	10.170.53.202\n.\\admintemp\nPassword09
159	10.170.53.78	ORACLE PRD	VIDHOWNPINSDB01	WINDOWS 2012 R2	Oracle 11g Windows	0	32	8	0	t	1	1	3	2025-02-21 00:00:00	2025-02-21 15:02:20	2025-02-21 15:02:20	\N	CREATE USER mis_user IDENTIFIED BY Password09;
144	10.170.49. 	DBA_USER DEV	VID	Red Hat Enterprise Linux 	(EnterpriseDB Advanced Server 14.13.1)	0	62G	24	0	t	1	1	4	2024-10-22 00:00:00	2024-10-22 20:18:04	2024-10-23 07:15:51	\N	10.170.49.180
134	10.171.211.51	DR GP	SIDDCLXPGPSAP01	Red Hat 6.10 (RHEL)	Greenplum Node Standby	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi
142	10.170.49.180	GP DEV	VIDHOLXDGPNAP03	Red Hat Enterprise Linux 	Greenplum Node 4.3.33	0	62G	24	0	t	1	1	4	2024-10-22 00:00:00	2024-10-22 18:35:26	2024-10-22 20:21:47	\N	VIDHOLXDGPNAP03
143	10.170.49.181	GP DEV	VIDHOLXDGPNAP04	Red Hat Enterprise Linux 	Greenplum Node 4.3.33	0	62G	24	0	t	1	1	4	2024-10-22 00:00:00	2024-10-22 20:11:06	2024-10-22 20:22:04	\N	VIDHOLXDGPNAP04
71	10.171.210.50	NICE Engage Unified PRD	siddrwnpneuap01	Windows Server 2016	no db	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-02 15:33:59	\N	Ridwan Royani
81	10.141.15.39	SUN SUN PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-11-26 13:43:18	\N	SUN\n10.141.15.39 (user DB)\nsun.dbadmin \nPassword09
151	10.143.17.126	x86_64-pc-linux-gnu Debian  PRD	 on x86_64-pc-linux-gnu, compiled by Debian 	CLOUD SQL	PostgreSQL 15.8	0	16	32	0	t	1	1	4	2024-12-13 00:00:00	2024-12-13 14:55:20	2024-12-16 09:53:41	\N	ALTER USER prumagnumpure WITH PASSWORD 'cNA4-K/C2VZ3Wh!!';\n5432\n
155	10.143.27.236	Cloud INTUATDB PRD	IDLIFED4VZP1CVI	Ubuntu 20	SQL Server 2019	0	6	2	0	t	1	10	1	2024-12-17 10:00:00	2024-12-17 16:00:37	2025-02-06 09:45:15	\N	    "private_address": "10.143.27.236",\n    "root_password": "+}CGp[@-"\n}\nuser sqlserver
19	10.170.53.106	ODS PRD	VIDHOWNPODSDB01	Windows Server 2016	SQL Server 2016	0	32	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 
21	10.170.48.98	Reporting DB SRSS PRD	VIDHOWNPREPDB01	Windows Server 2016	SQL Server 2016	0	32	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 
23	10.170.48.58	Internal DB - 03 PRD	VIDHOWNPINTDB03	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 
24	10.170.48.211	NICE DB PRD	VIDHOWNPNDSDB01	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani
25	10.170.48.44	NICE DB PRD	VIDHOWNPNDSDB02	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani
26	10.170.48.186	Ops Dashboard DB PRD	VIDHOWNPOPSDB01	Windows Server 2016	SQL Server 2016	0	8	2	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 
27	10.170.48.85	GPP Report PRD	SIDHOPWINMDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 
29	10.170.53.46	CRM Archive PRD	VIDHOWNPCRMDB03	Windows Server 2016	SQL Server 2016	0	24	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Victor Liliwidjaja
30	10.170.48.84	Reinsurance DB PRD	VIDHOWNPREIDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Fikrilsyah Algoumar
31	10.170.48.77	E-Submission NB PRD	VIDHOWNPXARDB01	Windows Server 2016	SQL Server 2016	0	8	2	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-10 11:13:44	\N	Nanda Widy
34	10.170.53.91	SUN GL PRD	SIDHOPWINSUNDB1	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Syofianer Fitra
15	10.171.84.92	Postgre Enablement Tribe COMPLIANCE PRD	VIDDCLXPENTDB01	Red Hat 6.10 (RHEL)	PostgreSQL 10.4	0	15	4	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	10 GB
17	10.171.84.100	AI DB PRD	VIDDCLXPAICDB01	Red Hat 6.10 (RHEL)	PostgreSQL 10.4	0	32	4	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	197 GB
11	10.171.84.68	SME DB PRD	VIDDCLXPSMEDB04-new	Red Hat 6.10 (RHEL)	PostgreSQL 10.7 	0	19	6	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	 GB
2	10.170.53.103	AOB EPOLICY DB (WAB,Fuse)  PRD	VIDDCLXPAOBDB04	Red Hat  7.9  (RHEL)	EnterpriseDB 14.13.1	0	46	20	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-05 09:56:15	\N	200 GB DISK --- ada versi 14 UP
1	10.170.53.102	AOB DB ESUB PRD	VIDDCLXPAOBDB03	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.2.7	0	32	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	814 GB
4	10.171.140.16	Payment Database PRD	VIDDCLXPNPHDB01-New	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	32	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	688 GB
3	10.170.53.29	BPM DB PRD	VIDHOPLINBPMDB1	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	64	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	148 GB
20	10.170.53.36	Internal DB (Moveit) PRD	VIDHOWNPINTDB02	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-14 10:30:13	\N	Afdoli Fahmi -- > moveitdmz Password09
36	10.170.53.68	CRM PRD	VIDHOWNPCRMDB02	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Victor Liliwidjaja
37	10.170.53.44	CRM PRD	VIDHOWNPCRMDB01	Windows Server 2016	SQL Server 2016	0	39	12	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Victor Liliwidjaja
38	10.170.53.105	DataMart PRD	VIDHOWNPDTMDB01	Windows Server 2016	SQL Server 2016	0	32	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Fikrilsyah Algoumar
39	 10.170.53.49	PG BCA PRD	VIDHOWNPH2BDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Bhimo Bhaskoro
33	10.170.48.215	K2 DB server PRD	VIDHOWNPKTWDB01	Windows Server 2016	SQL Server 2016	0	20	2	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-27 11:53:25	\N	Syofianer Fitra
32	10.170.48.122	Sharepoint DB PRD	SIDHOPWINSHPDB1	Windows Server 2016	SQL Server 2016	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-27 11:54:03	\N	Syofianer Fitra
28	10.170.48.112	Customer Analytic PRD	SIDHOPWINDALDB1	Windows Server 2016	SQL Server 2019	0	48	3	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-28 10:03:49	\N	Afdoli Fahmi \nHani Asri Guardiani
12	10.170.53.101	nbwf,  DB Workflow PRD	VIDDCLXPAOBDB02	Red Hat  7.9  (RHEL)	(EnterpriseDB Advanced Server 14.13.1)	0	50	28	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-28 10:24:26	\N	892 GB
40	10.170.53.153	OCR DB PRD	VIDDCWNPOCRDB01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Juliana
41	10.170.53.5	EPOS DB PRD	VIDHOPWINPOSDB1	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 
42	10.171.84.205	New IFRS  PRD	VIDDRWNPIFRDB01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Mimi Winata
43	10.171.84.215	Power BI PRD	VIDDCWNPPBIAP01	Windows Server 2016	SQL Server 2016	0	96	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Rizky Karunia
129	10.170.216.100	PRD	SIDHOWNPCCVAP01	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Upgrade to 2016 SP 3
130	10.170.53.61	PRD	vidhownpcrmap03	Windows Server 2019 STD	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Microsoft SQL Server 2008 R2 
46	10.171.84.71 	GreenPlum Second Master PRD	SIDDRLXPGPSAP01	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS
47	10.171.84.123	GreenPlum Node 1 PRD	SIDDRLXPGPNAP01	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS
49	10.171.84.125	GreenPlum Node 3 PRD	SIDDRLXPGPNAP03 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS
50	10.171.84.126	GreenPlum Node 4 PRD	SIDDRLXPGPNAP04 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS
51	10.171.84.128 	GreenPlum Node 5 PRD	SIDDRLXPGPNAP05	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS
52	10.171.84.129	GreenPlum Node 6 PRD	SIDDRLXPGPNAP06	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS
63	10.170.48.37	DB Nice Server Playback Portal PRD	vidhownpnpsdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-02 15:35:03	\N	Ridwan Royani
64	10.170.48.101	DB Server New AWMS Server (Tower) PRD	viddcwnpawmap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Abdul Qahar
65	10.170.48.35	DB Server Sentinel  PRD	vidhownpnmsap02	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-02 15:35:36	\N	Ridwan Royani, Manage by Nice Vendor
66	10.170.109.19	DB Server Q-Matic PRD	vidptwnpqmtap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani
70	10.170.216.196	DB Server WINPAKPRO PRD	sidpcwnpacdap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow
72	10.170.48.235	DB Server(NewSolarWins DB) PRD	vidhopwinifrdb1	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow
73	10.170.216.69	DB Server FXAW PRD	vidpcwnpawmap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow
77	10.170.48.128	DB Server SOLARWIN_ORION PRD	vidhopwinswdap1	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow
80	10.141.15.36	TLM TLM PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-11-29 16:10:01	\N	RDP\nuser : SRVPLAIPRTLMSMARTS01\nPassword : Q42PDxA(
82	10.143.34.42	One Pulse Platform onepulse PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	\N
84	10.143.34.206	smartclaim ( replica) smartclaim PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	\N
87	10.143.34.79	Renova (Cloud Instance) Renova_Individual PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2019 std edition	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-01-10 10:33:08	\N	user/pass: renovadb/5J+a]OlQ | user/pass: sqlserver/XpIeX_N&
89	10.143.27.253	jatisSMS (Cloud Instance)  PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016 std edition	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: sqlserver/Svu72BhZ
90	10.143.21.8	edoc (cloud_VM) edoc PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: edocplai/edoc2022
91	10.143.17.29	edoc (cloud_Instance) edoc PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: postgres/o1Gy1WbqQ3DZcTt4hyVGzkCzEHnFEKxb | user/pass:edocplai/U0Y42h8mngzu-D8@
92	10.143.36.140	edoc (cloud_VM) edoc PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: edocplai/edoc2022
93	10.143.34.223	edoc (cloud_Instance) edoc PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: postgres/agG0nkLGOCphBdCwsUD5Cd1B8W0TmADT | user/pass: edocplai/IOSBQgiK6hOiEvu-
95	10.143.17.59	keycloack keycloack PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 13.13	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pas: postgres/d5iv2cp2t2LmRfIXECtypk1JBh71r7bl
100	10.143.34.70	PSA PRD	PSA	UBUNTU 10,22 GCP	Google Cloud	0	16	8	0	t	1	1	2	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	user/pas : postgres/bFAyEyz383ITMZ8MHImEfAnDzKZSTO74
101	10.143.34.101	PSA PRD	PSA	UBUNTU 10,22 GCP	Google Cloud	0	16	8	0	t	1	1	2	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	user/pas : postgres/xIqL6MHtPJWYA1OjaPaW4n9UM844LYdF
102	10.170.52.70	PRD	VIDHOWNPSFSAP04	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3
106	10.170.48.109	PRD	VIDHOLXPBAKAP02	Red Hat  7.9  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3
112	10.171.212.215	PRD	VIDDRWNDNRSDB01	Windows Server 2016	SQL Server 2016 express SP3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Uninstal SQLEXPRESS
131	10.170.49.136	DBA_USER DEV	VIDDRLXUGBQDB01	Red Hat  8.10  (RHEL)	Postgres 16.0	0	125GB	32	0	t	1	1	4	2024-10-10 00:00:00	2024-10-10 21:31:41	2024-10-10 21:31:41	\N	DEV NEW Postgres 16 | dba_user dba_user | 5432 | owner | Radit
158	10.171.84.73	VIDDCLXPGA PRD	VIDDCLXPGA	Red Hat Enterprise Linux 	Postgres 14.0	0	8	2	0	t	1	1	2	2025-02-06 00:00:00	2025-02-06 14:44:55	2025-02-06 14:44:55	\N	VIDDCLXPGA
94	10.143.34.226	OLTP DB  PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 13.13	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	oltp-svc/KT3meM@r-BdEBF1p
161	10.170.48.190	DCI CFS PRD	VIDHOWPCFSAP1	WINDOWS 2012 R2	Microsoft SQL Server 2012	0	8	4	0	t	1	1	1	2025-02-26 00:00:00	2025-02-26 15:31:15	2025-02-26 15:31:15	\N	Henry Lois Sumendap
56	10.171.84.43	RESDB DB2 PRD	VIDDCLXPODMDB01	Red Hat  7.9  (RHEL)	DB2 v10.5.0.3	0	31	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS  \n user SPLAIODM pass: Password09 di ip\n10.171.84.43 (BRMS)
53	10.171.84.104	BPM DB2 PRD	VIDDCLXPBPMDB01	Red Hat 6.10 (RHEL)	DB2 v10.5.0.3	0	58	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS\nkill locking db2 \n- db2top -d bpmdbphs (DB_Name)\n- tekan shift u\n- Klik a lalu ketik id yg mau di kill\n- db2 "force application(28866 contoh)"\ndb2 "force application(22948)"
146	10.171.84.154	ICN DB2 PRD	VIDDCLXPICNDB01	Red Hat (RHEL) 8.10	DB2 v11.5.8.0	0	7.5 GB	2	0	t	1	1	1	2024-11-05 10:00:00	2024-11-05 10:58:11	2024-11-05 10:58:11	\N	Afdoli Fahmi , MIS
150	10.143.34.85	newpruworks PRD	pruidlife-prod	CLOUD SQL  SVR	PostgreSQL 15.8	0	16	8	0	t	1	1	5	2024-11-19 00:00:00	2024-11-19 13:53:08	2024-11-19 14:30:32	\N	 "default_password": "\\u003cM?WuPtb",\n  "default_username": "pruuser", "root_password": "K2b\\u003ej1ly"
13	10.171.84.117	Magnum Pure PRD	VIDDCLXPMGPDB01	Red Hat  7.9  (RHEL)	(EnterpriseDB Advanced Server 9.6.2.7) 	0	16	16	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	571 GB
132	10.171.86.72	NBWF UAT	SR02701142	Red Hat  7.9  (RHEL)	(EnterpriseDB Advanced Server 14.13.1)	0	16	8	0	t	1	1	4	2024-10-12 00:00:00	2024-10-12 16:31:46	2024-10-12 16:31:46	\N	SR02701142
135	10.171.211.123	DR GP	SIDDCLXPGPNAP01	Red Hat 6.10 (RHEL)	Greenplum Node 1	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi
136	10.171.211.124	DR GP	SIDDCLXPGPNAP02	Red Hat 6.10 (RHEL)	Greenplum Node 2	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi
137	10.171.211.125	DR GP	SIDDCLXPGPNAP03	Red Hat 6.10 (RHEL)	Greenplum Node 3	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi
138	10.171.211.126	DR GP	SIDDCLXPGPNAP04	Red Hat 6.10 (RHEL)	Greenplum Node 4	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi
139	10.171.211.127	DR GP	SIDDCLXPGPNAP05	Red Hat 6.10 (RHEL)	Greenplum Node 5	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi
140	10.171.211.128	DR GP	SIDDCLXPGPNAP06	Red Hat 6.10 (RHEL)	Greenplum Node 6	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi
124	10.170.49.217	NPRD	vidhownuefmap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-04-22 16:24:12	\N	AJI  E-FORM-APPS\n.\\sqlagtsvcdev  -> Password09
85	10.143.34.202	smartclaim ( master) smartclaim PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-03-13 09:58:30	\N	"password": "nl!rWHX@vSojmUbn",\n"username": "op-svc"\n\n"password": "rh1mTEj!U23pd6$5",\n  "username": "dba-user"\n\n"password": "rp@o73p6-knfv$lC",\n "username": "release-user"
107	10.171.84.78	NPRD	VIDHOLXGBQMAP01	Red Hat  7.9  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2025-03-20 08:53:44	\N	Upgrade Postgres v.8.3 to 14.3
162	10.143.34.234	MAGNUMEPURE PRD GKE	GKEMAGNUMEPURE	Debian clang version 12.0	PostgreSQL 15.12 	0	64	16	0	t	1	1	1	2025-03-10 00:00:00	2025-03-17 10:56:10	2025-03-20 10:38:39	\N	 "default_password": "ikGIgklikmFjNxWf0hVq4oNVZNXlWlVB",\n  "default_username": "postgres",
163	10.143.34.36	mitracommadm-stagging PRD	IDLIFED4VZP1CVI-1a1636b9	CLOUD SQL UBUNTU 20	Microsoft SQL Server 2019	0	10	4	0	t	1	1	1	2025-03-20 00:00:00	2025-03-20 10:17:03	2025-03-20 10:42:06	\N	    "default_password":"D<1n=j}K",\n    "default_username":"mitracommadm",\n    "root" d6fs4NeX"
88	10.141.23.9	Ifrs17 (cloud_VM) ifrs17 PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016 std edition	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-03-24 14:08:55	\N	user/pass: sa/Password09 |  apref: c5wvjk
125	10.170.49.78	NPRD	sidhouwinepvdb1	Windows Server 2016	SQL Server 2016 SP 3	1	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-03-25 17:39:00	\N	111
35	10.170.53.187	New Actuary DB PRD	VIDHOWNPPRPDB01	Windows Server 2016	SQL Server 2016	0	64	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-03-27 08:19:59	\N	Salman Farizi \n260325->addcpu 2
22	10.170.48.177	Database Solarwind, scom, SCCM PRD	SIDHOPWINIFRDB1	Windows Server 2016	SQL Server 2016	0	16	3	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-03-27 11:54:30	\N	Afdoli Fahmi , mis_user\nSQLAGTSVCPROD Password09
16	10.170.53.108	Base DB PRD	VIDDCLXPBSEDB06	Red Hat 8.10 (RHEL)	PostgreSQL 14.12	0	62	8	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-14 14:10:21	\N	59 GB
14	10.170.53.200	Corespondence DB PRD	VIDDCLXPCDSDB01	Red Hat (RHEL) 7.9	PostgreSQL 14.12	0	31	4	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-15 10:30:32	\N	443 GB
141	10.170.49.179	DR GP	VIDHOLXDGPMAP02 	Red Hat 7.10 (RHEL)	Greenplum Node 4.3.33	0	62	24	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2025-04-17 17:08:26	\N	Arif Rahman  - Postgres + greenplum padmin password_09 root today123
164	10.171.211.16	DB2 - DEV	PRUIDWFCM02	AIX 2	DB2 AIX	0	8	8	0	t	1	1	2	2025-04-25 00:00:00	2025-04-25 11:18:31	2025-04-25 14:22:08	\N	   test
97	10.143.34.5 	DB SCRM PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2022	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-04-25 15:31:30	\N	1433  sqlserver/ua}T&-9[  simplecrm
165	10.143.17.197	Cloud	apidb_uat	linux debian 12	PostgreSQL 13.20	0	16	8	0	t	1	1	4	2025-04-28 00:00:00	2025-04-28 14:58:13	2025-04-28 14:58:13	\N	{\n\t\t"password":"JqoNbmc/hgQud4wP",\n\t\t"username":"dev-svc"\n\t}\npostgres/Ku6u6mpGsBplAeyeiiG28P8J3gDUk63o
54	10.170.53.150	HPX DB2  PRD	VIDHOLXPHPEDB01	Red Hat  8.10  (RHEL)	DB2 v10.5.0.3	0	15	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-29 14:30:39	\N	Afdoli Fahmi , MIS, HPXDE
168	10.170.53.132	PROD	vidholxpodsdb02	Red Hat 8.10 (RHEL)	Postgres 9.4	0	168	26	0	t	1	1	1	2025-04-30 00:00:00	2025-04-30 14:56:44	2025-04-30 15:00:41	\N	padmin
18	10.170.53.147	Consolidate Database Server(XML) PRD	VIDHOWNPINTDB01	Windows Server 2016	SQL Server 2016	0	44	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-30 16:40:07	\N	Afdoli Fahmi \nowner Nanda widy
\.


--
-- Data for Name: hardware_050825; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.hardware_050825 (id, make, model, serial, os_name, os_version, type, ram, cpu, status, current, company_id, user_id, provaider_id, purchased_at, created_at, updated_at, deleted_at, note, max_con) FROM stdin;
2	10.170.53.103	AOB EPOLICY DB (WAB,Fuse)  PRD	VIDDCLXPAOBDB04	Red Hat  7.9  (RHEL)	EnterpriseDB 14.13	0	46	20	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-05-28 15:06:28	\N	200 GB DISK --- NIDLIFEAPPSUP ada versi 14 UP	400
3	10.170.53.29	BPM DB PRD	VIDHOPLINBPMDB1	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	64	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	148 GB	400
15	10.171.84.92	Postgre Enablement Tribe COMPLIANCE PRD	VIDDCLXPENTDB01	Red Hat 8.10 (RHEL)	PostgreSQL 14.12	0	15	4	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-05-05 08:38:54	\N	10 GB	400
16	10.170.53.108	Base DB PRD	VIDDCLXPBSEDB06	Red Hat 8.10 (RHEL)	PostgreSQL 14.12	0	62	8	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-14 14:10:21	\N	59 GB	400
17	10.171.84.100	AI DB PRD	VIDDCLXPAICDB01	Red Hat 6.10 (RHEL)	PostgreSQL 10.4	0	32	4	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	197 GB	400
18	10.170.53.147	Consolidate Database Server(XML) PRD	VIDHOWNPINTDB01	Windows Server 2016	SQL Server 2016	0	44	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-30 16:40:07	\N	Afdoli Fahmi \nowner Nanda widy	400
19	10.170.53.106	ODS PRD IDNPLAODSDB	VIDHOWNPODSDB01	Windows Server 2016	SQL Server 2016	0	64	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-07-17 16:57:15	\N	Afdoli Fahmi  IDNPLAODSDB	400
20	10.170.53.36	Internal DB (Moveit) PRD	VIDHOWNPINTDB02	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-14 10:30:13	\N	Afdoli Fahmi -- > moveitdmz Password09	400
21	10.170.48.98	Reporting DB SRSS PRD	VIDHOWNPREPDB01	Windows Server 2016	SQL Server 2016	0	32	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 	400
6	10.170.53.57	Training PRD	VIDDCLXPAOBDB06	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	32	10	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-10-20 04:04:31	\N	109 GB	400
22	10.170.48.177	Database Solarwind, scom, SCCM PRD	SIDHOPWINIFRDB1	Windows Server 2016	SQL Server 2016	0	16	3	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-03-27 11:54:30	\N	Afdoli Fahmi , mis_user\nSQLAGTSVCPROD Password09	400
23	10.170.48.58	Internal DB - 03 PRD	VIDHOWNPINTDB03	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 	400
24	10.170.48.211	NICE DB PRD	VIDHOWNPNDSDB01	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani	400
25	10.170.48.44	NICE DB PRD	VIDHOWNPNDSDB02	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani	400
26	10.170.48.186	Ops Dashboard DB PRD	VIDHOWNPOPSDB01	Windows Server 2016	SQL Server 2016	0	8	2	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 	400
27	10.170.48.85	GPP Report PRD	SIDHOPWINMDB01	Windows Server 2016	SQL Server 2016	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-07-02 10:08:54	\N	Afdoli Fahmi GPP	400
28	10.170.48.112	Customer Analytic PRD	SIDHOPWINDALDB1	Windows Server 2016	SQL Server 2019	0	48	3	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-28 10:03:49	\N	Afdoli Fahmi \nHani Asri Guardiani	400
29	10.170.53.46	CRM Archive PRD	VIDHOWNPCRMDB03	Windows Server 2016	SQL Server 2016	0	24	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Victor Liliwidjaja	400
30	10.170.48.84	Reinsurance DB PRD	VIDHOWNPREIDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Fikrilsyah Algoumar	400
31	10.170.48.77	E-Submission NB PRD	VIDHOWNPXARDB01	Windows Server 2016	SQL Server 2016	0	8	2	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-10 11:13:44	\N	Nanda Widy	400
32	10.170.48.122	Sharepoint DB PRD	SIDHOPWINSHPDB1	Windows Server 2016	SQL Server 2016	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-27 11:54:03	\N	Syofianer Fitra	400
33	10.170.48.215	K2 DB server PRD	VIDHOWNPKTWDB01	Windows Server 2016	SQL Server 2016	0	20	2	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-27 11:53:25	\N	Syofianer Fitra	400
34	10.170.53.91	SUN GL PRD	SIDHOPWINSUNDB1	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Syofianer Fitra	400
35	10.170.53.187	New Actuary DB PRD	VIDHOWNPPRPDB01	Windows Server 2016	SQL Server 2016	0	64	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-03-27 08:19:59	\N	Salman Farizi \n260325->addcpu 2	400
36	10.170.53.68	CRM PRD	VIDHOWNPCRMDB02	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Victor Liliwidjaja	400
37	10.170.53.44	CRM PRD	VIDHOWNPCRMDB01	Windows Server 2016	SQL Server 2016	0	39	12	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Victor Liliwidjaja	400
38	10.170.53.105	DataMart PRD	VIDHOWNPDTMDB01	Windows Server 2019	SQL Server 2016	0	32	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-05-28 16:46:00	\N	Fikrilsyah Algoumar	400
39	 10.170.53.49	PG BCA PRD	VIDHOWNPH2BDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Bhimo Bhaskoro	400
40	10.170.53.153	OCR DB PRD	VIDDCWNPOCRDB01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Juliana	400
41	10.170.53.5	EPOS DB PRD	VIDHOPWINPOSDB1	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 	400
42	10.171.84.205	New IFRS  PRD	VIDDRWNPIFRDB01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Mimi Winata	400
43	10.171.84.215	Power BI PRD	VIDDCWNPPBIAP01	Windows Server 2016	SQL Server 2016	0	96	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Rizky Karunia	400
44	10.171.84.70	GreenPlum Master PRD	SIDDRLXPGPMAP01 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2025-08-05 13:58:34	\N	Afdoli Fahmi , MIS\n/GPDB_DATA/master/gpseg-1/	400
45	10.171.84.71 	GreenPlum Second Master PRD	SIDDRLXPGPSAP01	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
1	10.170.53.102	AOB DB ESUB PRD	VIDDCLXPAOBDB03	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.2.7	0	32	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	814 GB	400
46	10.171.84.123	GreenPlum Node 1 PRD	SIDDRLXPGPNAP01	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
113	10.170.49.11	NPRD	VIDHOWNUPDCAP01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-06-11 13:53:48	\N	SQLAGTSVCDEV  Password09	400
47	10.171.84.124	GreenPlum Node 2 PRD	SIDDRLXPGPNAP02	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
48	10.171.84.125	GreenPlum Node 3 PRD	SIDDRLXPGPNAP03 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
49	10.171.84.126	GreenPlum Node 4 PRD	SIDDRLXPGPNAP04 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
50	10.171.84.128 	GreenPlum Node 5 PRD	SIDDRLXPGPNAP05	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
51	10.171.84.129	GreenPlum Node 6 PRD	SIDDRLXPGPNAP06	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
52	10.171.84.104	BPM DB2 PRD	VIDDCLXPBPMDB01	Red Hat 6.10 (RHEL)	DB2 v10.5.0.3	0	58	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS\nkill locking db2 \n- db2top -d bpmdbphs (DB_Name)\n- tekan shift u\n- Klik a lalu ketik id yg mau di kill\n- db2 "force application(28866 contoh)"\ndb2 "force application(22948)"	400
53	10.170.53.150	HPX DB2  PRD	VIDHOLXPHPEDB01	Red Hat  8.10  (RHEL)	DB2 v10.5.0.3	0	15	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-29 14:30:39	\N	Afdoli Fahmi , MIS, HPXDE	400
54	10.170.53.99	CM DB2 PRD	PRUIDWFCM02	AIX 7	DB2 v10.5.0.8	0	42	3	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS \nkill locking db2 \n- db2top -d bpmdbphs (DB_Name)\n- tekan shift u\n- Klik a lalu ketik id yg mau di kill\n- db2 "force application(28866 contoh)"\ndb2 "force application(22948)"	400
55	10.171.84.43	RESDB DB2 PRD	VIDDCLXPODMDB01	Red Hat  7.9  (RHEL)	DB2 v10.5.0.3	0	31	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS  \n user SPLAIODM pass: Password09 di ip\n10.171.84.43 (BRMS)	400
56	10.170.53.14	MFPDATA DB2 PRD	VIDHOPLINIMFDB1	Red Hat (RHEL) 8.10	DB2 v11.5.8.0	0	62	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-05 10:52:32	\N	Afdoli Fahmi , MIS	400
57	10.171.82.73	UAT	sidhopwinvnxap1	Red Hat 6.10 (RHEL)	MySQL Database Server	0	31	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS	400
58	10.170.49.144	UAT	vidhownuinsdb01	Windows Server 2012 R2	Oracle Database 11g Enterprise Edition	0	31	8	0	t	1	1	3	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-18 18:00:58	\N	Afdoli Fahmi , MIS\n.\\sqlagtsvcdev\nPassword09	400
59	10.170.49.107	UAT	viddrlxdatsap01	Red Hat 6.10 (RHEL)	Oracle Database 11g Enterprise Edition	0	31	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS	400
60	10.171.83.52	DB Server SCCM Server PRD	viddcwnpscmap02	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Abdul Qahar	400
61	10.170.53.198	DB Server iCare & IVRDB PRD	vidhowpivrdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
62	10.170.48.37	DB Nice Server Playback Portal PRD	vidhownpnpsdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-02 15:35:03	\N	Ridwan Royani	400
63	10.170.48.101	DB Server New AWMS Server (Tower) PRD	viddcwnpawmap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-07-30 12:03:48	\N	Abdul Qahar MSSQL$FXAW mis_user	400
64	10.170.48.35	DB Server Sentinel  PRD	vidhownpnmsap02	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-02 15:35:36	\N	Ridwan Royani, Manage by Nice Vendor	400
65	10.170.109.19	DB Server Q-Matic PRD	vidptwnpqmtap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani	400
66	10.170.53.199	DB Server iCare & IVRDB PRD	viddrwpivrdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-06-19 14:56:10	\N	mis_user Password09	400
67	10.170.53.186	Is not DB Server PRD	vidhownpprpap02	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
68	10.170.48.63	Is not DB Server PRD	sidhopwinscmap1	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Taufik Ridwan	400
69	10.170.216.196	DB Server WINPAKPRO PRD	sidpcwnpacdap01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-07-16 17:51:06	\N	Fingerprint Tower	400
70	10.171.210.50	NICE Engage Unified PRD	siddrwnpneuap01	Windows Server 2016	no db	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-02 15:33:59	\N	Ridwan Royani	400
71	10.170.48.235	DB Server(NewSolarWins DB) PRD	vidhopwinifrdb1	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
72	10.170.216.69	DB Server FXAW PRD	vidpcwnpawmap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
73	10.170.53.185	Is not DB Server New Actuary Apps PRD	vidhownpprpap01	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Daniel Agustinus Rahardjo / Salman Farizi 	400
74	10.170.48.102	Decommissioning PRD	vidhownpintdb07	Windows Server 2016	SQL Server 2012	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
75	10.170.48.33	Decommissioning NICE  PRD	vidhownpndsdb03	Windows Server 2016	SQL Server 2012	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani	400
76	10.170.48.128	DB Server SOLARWIN_ORION PRD	vidhopwinswdap1	Windows Server 2016	SQL EXPRESS 2017	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-07-22 14:12:49	\N	unknow	400
4	10.171.140.16	Payment Database PRD	VIDDCLXPNPHDB01-New	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	32	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	688 GB	400
77	10.171.140.90	Is not DB Server ( No DB Service) PRD	viddcwnppbhap01	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Arif Hidayat Husni	400
78	10.143.34.54	PMN DB nbwf PRD	fhsl34	UBUNTU 10,22 GCP	EnterpriseDB 9.6.2.7	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-07-21 11:27:30	\N	10.143.34.54 \nPMN DB pmnwf-new2-6a194f8d	400
79	10.141.15.36	TLM TLM PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-11-29 16:10:01	\N	RDP\nuser : SRVPLAIPRTLMSMARTS01\nPassword : Q42PDxA(	400
80	10.141.15.39	SUN SUN PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-11-26 13:43:18	\N	SUN\n10.141.15.39 (user DB)\nsun.dbadmin \nPassword09	400
81	10.143.34.42	One Pulse Platform onepulse PRD	cmb6ze	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-07-21 11:23:52	\N	cmb6ze	400
82	10.143.17.6	smartclaim smartclaim PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	\N	400
83	10.143.34.206	smartclaim ( replica) smartclaim PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	\N	400
84	10.143.34.202	smartclaim ( master) smartclaim PRD	o35gws	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-07-21 11:22:35	\N	"password": "nl!rWHX@vSojmUbn",\n"username": "op-svc"\n\n"password": "rh1mTEj!U23pd6$5",\n  "username": "dba-user"\n\n"password": "rp@o73p6-knfv$lC",\n "username": "release-user"	400
85	10.141.23.11	Renova (Cloud VM) Renova_Individual UAT	service db cloud	Windows Server 2016	SQL Server 2017 std edition	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-01-10 10:30:37	\N	user/pass: renovaid/Password12 | sa/Password09	400
86	10.143.34.79	Renova (Cloud Instance) Renova_Individual PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2019 std edition	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-01-10 10:33:08	\N	user/pass: renovadb/5J+a]OlQ | user/pass: sqlserver/XpIeX_N&	400
87	10.141.23.9	Ifrs17 (cloud_VM) ifrs17 PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016 std edition	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-03-24 14:08:55	\N	user/pass: sa/Password09 |  apref: c5wvjk	400
88	10.143.27.253	jatisSMS (Cloud Instance)  PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016 std edition	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: sqlserver/Svu72BhZ	400
89	10.143.21.8	edoc (cloud_VM) edoc PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: edocplai/edoc2022	400
90	10.143.17.29	edoc (cloud_Instance) edoc PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: postgres/o1Gy1WbqQ3DZcTt4hyVGzkCzEHnFEKxb | user/pass:edocplai/U0Y42h8mngzu-D8@	400
91	10.143.36.140	edoc (cloud_VM) edoc PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: edocplai/edoc2022	400
92	10.143.34.223	edoc (cloud_Instance) edoc PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: postgres/agG0nkLGOCphBdCwsUD5Cd1B8W0TmADT | user/pass: edocplai/IOSBQgiK6hOiEvu-	400
93	10.143.34.226	OLTP DB  PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 13.13	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	oltp-svc/KT3meM@r-BdEBF1p	400
94	10.143.17.59	keycloack keycloack PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 13.13	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pas: postgres/d5iv2cp2t2LmRfIXECtypk1JBh71r7bl	400
95	10.143.27.57	DB SCRM UAT	service db cloud	UBUNTU 10,22 GCP	SQL Server 2022	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	\N	400
96	10.143.34.5 	DB SCRM PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2022	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-04-25 15:31:30	\N	1433  sqlserver/ua}T&-9[  simplecrm	400
97	10.141.48.131	STAGGING REMOTE SQL NRPD	service db cloud	Windows Server 2016 GCP	Client Cloud Remote Server	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	\N	400
98	10.143.17.69	PSA UAT	PSA	UBUNTU 10,22 GCP	Google Cloud	0	16	8	0	t	1	1	2	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	user/pas : postgres/AmZsWOWWl949v3lAtKMJeT9AVAqlBbHu	400
99	10.143.34.70	PSA PRD	PSA	UBUNTU 10,22 GCP	Google Cloud	0	16	8	0	t	1	1	2	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	user/pas : postgres/bFAyEyz383ITMZ8MHImEfAnDzKZSTO74	400
100	10.143.34.101	PSA PRD	PSA	UBUNTU 10,22 GCP	Google Cloud	0	16	8	0	t	1	1	2	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	user/pas : postgres/xIqL6MHtPJWYA1OjaPaW4n9UM844LYdF	400
101	10.170.52.70	PRD	VIDHOWNPSFSAP04	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
102	10.170.52.28	NPRD	WINTEL	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
103	10.170.53.114	NPRD	vidhownp2faap01 	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
104	10.170.48.110	NPRD	VIDHOLXPBAKAP01	Red Hat  8.10  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
105	10.170.48.109	PRD	VIDHOLXPBAKAP02	Red Hat  7.9  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
106	10.171.84.78	NPRD	VIDHOLXGBQMAP01	Red Hat  7.9  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2025-03-20 08:53:44	\N	Upgrade Postgres v.8.3 to 14.3	400
5	10.170.53.56	Database Leads PRD	VIDDCLXPAOBDB05	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	31	36	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-28 10:44:23	\N	109 GB	400
107	10.171.213.79	NPRD	VIDDRLXUSMEAP04	Red Hat  8.1 (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.10 to 14.3	400
108	10.170.49.150	NPRD	SIDHODLINFUSDB1	Red Hat  8.1  (RHEL)	PostgreSQL 15.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2025-08-03 10:13:45	\N	Postgres v.10 to 14.3 | fuse DB  pruasia\\sqlagtsvcdev\nPassword09	400
109	10.170.49.191	NPRD	vidholdodsdb1	Red Hat  7.9  (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-12-13 09:41:05	\N	Upgrade Postgres v.10 to 14.3 pruasia\\sqlagtsvcdev\nPassword09	400
110	10.171.212.215	PRD	VIDDRWNDNRSDB01	Windows Server 2016	SQL Server 2016 express SP3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Uninstal SQLEXPRESS	400
111	10.171.210.25	NPRD	VIDDRWNPCCVAP01	Windows Server 2016	SQL Server 2016 express SP3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Uninstal SQLEXPRESS	400
112	10.171.212.142	NPRD	viddcwndhpxap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N	400
114	10.170.49.123	NPRD	SIDHOUWINSAPDB2	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-11-11 13:43:00	\N	PRUASIA\\sqlagtsvcdev\nPassword09	400
115	10.170.49.188	NPRD	vidhodwinintdb1	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N	400
116	10.170.49.195	NPRD	vidhowndefmdb01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N	400
117	10.170.49.196	NPRD	vidhownupacdb01	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Finger Print	400
118	10.170.49.197	NPRD	vidhowndeprap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-03-25 17:39:18	\N	11	400
119	10.170.49.210	NPRD	vidhodwinintdb7	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Dev Moveit	400
120	10.170.49.216	NPRD	sidhouwinepvap1	Windows Server 2016	SQL Server 2016 SP 3	0	16,200	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-05-04 16:18:45	\N	123	400
121	10.170.49.217	NPRD	vidhownuefmap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-04-22 16:24:12	\N	AJI  E-FORM-APPS\n.\\sqlagtsvcdev  -> Password09	400
122	10.170.49.78	NPRD	sidhouwinepvdb1	Windows Server 2016	SQL Server 2016 SP 3	1	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-03-25 17:39:00	\N	111	400
123	10.170.49.80	UAT	SIDHOUWINSFTP01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-01-28 10:02:30	\N	Hanan	400
124	10.170.49.81 	NPRD	sidhodwinepvdb1	Windows Server 2012 R2 	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	e-Payment Voucher	400
125	10.170.49.88 	NPRD	VIDHOWNUINTDB01	Windows Server 2019	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N	400
126	10.170.216.100	PRD	SIDHOWNPCCVAP01	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Upgrade to 2016 SP 3	400
127	10.170.53.61	PRD	vidhownpcrmap03	Windows Server 2019 STD	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Microsoft SQL Server 2008 R2 	400
128	10.170.49.136	DBA_USER DEV	VIDDRLXUGBQDB01	Red Hat  8.10  (RHEL)	Postgres 16.0	0	125GB	32	0	t	1	1	4	2024-10-10 00:00:00	2024-10-10 21:31:41	2024-10-10 21:31:41	\N	DEV NEW Postgres 16 | dba_user dba_user | 5432 | owner | Radit	400
129	10.171.86.72	NBWF UAT	VIDDRLXUMSCDB01	Red Hat  7.9  (RHEL)	(EnterpriseDB Advanced Server 14.13.1)	0	15	8	0	t	1	1	4	2024-10-12 00:00:00	2024-10-12 16:31:46	2025-08-05 13:53:56	\N	SR02701142	400
130	10.171.211.50	DR GP	SIDDCLXPGPMAP01	Red Hat 6.10 (RHEL)	Greenplum Node Master	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
131	10.171.211.51	DR GP	SIDDCLXPGPSAP01	Red Hat 6.10 (RHEL)	Greenplum Node Standby	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
132	10.171.211.123	DR GP	SIDDCLXPGPNAP01	Red Hat 6.10 (RHEL)	Greenplum Node 1	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
133	10.171.211.124	DR GP	SIDDCLXPGPNAP02	Red Hat 6.10 (RHEL)	Greenplum Node 2	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
134	10.171.211.125	DR GP	SIDDCLXPGPNAP03	Red Hat 6.10 (RHEL)	Greenplum Node 3	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
135	10.171.211.126	DR GP	SIDDCLXPGPNAP04	Red Hat 6.10 (RHEL)	Greenplum Node 4	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
136	10.171.211.127	DR GP	SIDDCLXPGPNAP05	Red Hat 6.10 (RHEL)	Greenplum Node 5	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
138	10.170.49.179	DR GP	VIDHOLXDGPMAP02 	Red Hat 8.10 (RHEL)	Postgres 16.0	0	62	24	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2025-07-02 14:21:44	\N	Arif Rahman  - Postgres + mis_user padmin password_09 root today123	400
139	10.170.49.180	GP DEV	VIDHOLXDGPNAP03	Red Hat Enterprise Linux 	Greenplum Node 4.3.33	0	62G	24	0	t	1	1	4	2024-10-22 00:00:00	2024-10-22 18:35:26	2024-10-22 20:21:47	\N	VIDHOLXDGPNAP03	400
140	10.170.49.181	GP DEV	VIDHOLXDGPNAP04	Red Hat Enterprise Linux 	Greenplum Node 4.3.33	0	62G	24	0	t	1	1	4	2024-10-22 00:00:00	2024-10-22 20:11:06	2024-10-22 20:22:04	\N	VIDHOLXDGPNAP04	400
141	10.170.49. 	DBA_USER DEV	VID	Red Hat Enterprise Linux 	(EnterpriseDB Advanced Server 14.13.1)	0	62G	24	0	t	1	1	4	2024-10-22 00:00:00	2024-10-22 20:18:04	2024-10-23 07:15:51	\N	10.170.49.180	400
142	10.170.49.168	ON PREM ESUB NEWODS AOB UAT	VIDHOLXUINTDB02	Red Hat  8.1  (RHEL)	PostgreSQL 15.13	0	15	8	0	t	1	1	4	2024-10-23 00:00:00	2024-10-23 10:43:56	2025-08-03 10:13:15	\N	GRANT SELECT ON ALL TABLES IN SCHEMA pd_activity_management TO "mis-read";\nGRANT SELECT ON pd_activity_management.reasons TO  "mis-read";\nGRANT USAGE ON SCHEMA pd_activity_management TO "mis-read";\n\n\n	400
143	10.171.84.154	ICN DB2 PRD	VIDDCLXPICNDB01	Red Hat (RHEL) 8.10	DB2 v11.5.8.0	0	7.5 GB	2	0	t	1	1	1	2024-11-05 10:00:00	2024-11-05 10:58:11	2024-11-05 10:58:11	\N	Afdoli Fahmi , MIS	400
144	10.143.27.238	LINUX SQLSERVER PRD	IDLIFED4VZP1CVI	Ubuntu 20.04	SQL Server 2022	0	8	4	0	t	1	1	5	2024-11-07 00:00:00	2024-11-07 08:34:07	2024-11-07 08:34:08	\N	sqlserver\n\n@78$hZ!L	400
145	10.170.53.202	TRIAL DB SQL SERVER	TRIAL	WINDOWS 2012 R2	SQL Server 2022	0	16	8	9	t	1	1	5	2024-11-13 00:00:00	2024-11-13 07:52:19	2024-11-13 07:52:27	\N	10.170.53.202\n.\\admintemp\nPassword09	400
146	10.143.34.85	newpruworks PRD	pruidlife-prod	CLOUD SQL  SVR	PostgreSQL 15.8	0	16	8	0	t	1	1	5	2024-11-19 00:00:00	2024-11-19 13:53:08	2024-11-19 14:30:32	\N	 "default_password": "\\u003cM?WuPtb",\n  "default_username": "pruuser", "root_password": "K2b\\u003ej1ly"	400
147	10.143.17.126	x86_64-pc-linux-gnu Debian  PRD	 on x86_64-pc-linux-gnu, compiled by Debian 	CLOUD SQL	PostgreSQL 15.8	0	16	32	0	t	1	1	4	2024-12-13 00:00:00	2024-12-13 14:55:20	2024-12-16 09:53:41	\N	ALTER USER prumagnumpure WITH PASSWORD 'cNA4-K/C2VZ3Wh!!';\n5432\n	400
148	10.143.27.236	Cloud INTUATDB PRD	IDLIFED4VZP1CVI	Ubuntu 20	SQL Server 2019	0	6	2	0	t	1	10	1	2024-12-17 10:00:00	2024-12-17 16:00:37	2025-02-06 09:45:15	\N	    "private_address": "10.143.27.236",\n    "root_password": "+}CGp[@-"\n}\nuser sqlserver	400
149	10.170.109.42	Server Recording ACRA  PRD	VIDPTWNPACRAP01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	1	2025-01-14 00:00:00	2025-01-14 09:07:24	2025-01-14 09:07:37	\N	Login : VIDPTWNPACRAP01\\pruadmin\nPassword : P@ssw0rd\nVIDPTWNPACRAP01	400
150	10.170.49.73	UAT 	VIDDCLXDGAIAPP01	Red Hat Enterprise Linux 	Postgres 14.0	0	16	23	0	t	1	1	4	2025-02-06 00:00:00	2025-02-06 14:38:58	2025-02-06 14:38:58	\N	VIDDCLXDGAIAPP01	400
151	10.171.84.73	VIDDCLXPGA PRD	VIDDCLXPGA	Red Hat Enterprise Linux 	Postgres 14.0	0	8	2	0	t	1	1	2	2025-02-06 00:00:00	2025-02-06 14:44:55	2025-02-06 14:44:55	\N	VIDDCLXPGA	400
152	10.170.53.78	ORACLE PRD	VIDHOWNPINSDB01	WINDOWS 2012 R2	Oracle 11g Windows	0	32	8	0	t	1	1	3	2025-02-21 00:00:00	2025-02-21 15:02:20	2025-02-21 15:02:20	\N	CREATE USER mis_user IDENTIFIED BY Password09;	400
153	10.170.48.190	DCI CFS PRD	VIDHOWPCFSAP1	WINDOWS 2012 R2	Microsoft SQL Server 2012	0	8	4	0	t	1	1	1	2025-02-26 00:00:00	2025-02-26 15:31:15	2025-02-26 15:31:15	\N	Henry Lois Sumendap	400
154	10.143.34.234	MAGNUMEPURE PRD GKE	GKEMAGNUMEPURE	Debian clang version 12.0	PostgreSQL 15.12 	0	64	16	0	t	1	1	1	2025-03-10 00:00:00	2025-03-17 10:56:10	2025-03-20 10:38:39	\N	 "default_password": "ikGIgklikmFjNxWf0hVq4oNVZNXlWlVB",\n  "default_username": "postgres",	400
155	10.143.34.36	mitracommadm-stagging PRD	IDLIFED4VZP1CVI-1a1636b9	CLOUD SQL UBUNTU 20	Microsoft SQL Server 2019	0	10	4	0	t	1	1	1	2025-03-20 00:00:00	2025-03-20 10:17:03	2025-03-20 10:42:06	\N	    "default_password":"D<1n=j}K",\n    "default_username":"mitracommadm",\n    "root" d6fs4NeX"	400
156	10.171.211.16	DB2 - DEV	PRUIDWFCM02	AIX 2	DB2 AIX	0	8	8	0	t	1	1	2	2025-04-25 00:00:00	2025-04-25 11:18:31	2025-04-25 14:22:08	\N	   test	400
157	10.143.17.197	Cloud	apidb_uat	linux debian 12	PostgreSQL 13.20	0	16	8	0	t	1	1	4	2025-04-28 00:00:00	2025-04-28 14:58:13	2025-04-28 14:58:13	\N	{\n\t\t"password":"JqoNbmc/hgQud4wP",\n\t\t"username":"dev-svc"\n\t}\npostgres/Ku6u6mpGsBplAeyeiiG28P8J3gDUk63o	400
158	10.170.53.132	PROD	vidholxpodsdb02	Red Hat 8.10 (RHEL)	EDB 14.12	0	168	26	0	t	1	1	1	2025-04-30 00:00:00	2025-04-30 14:56:44	2025-05-06 13:29:11	\N	padmin	400
159	10.143.17.193	PROD misdb	10.143.17.193	Red Hat Enterprise Linux 	Postgres 16.0	0	16	8	0	t	1	\N	2	2025-05-09 00:00:00	2025-05-09 14:13:17	2025-05-09 14:20:21	\N	"username":"dev-svc"\n"password":"n@WXnqZHwNZg7/td"\n"username":"dev-user"\n"password":"/vSwLnEYYDul8P!G"\n"password":"nog1-ePSZ/vgrL7-","username":"dev-ro"	\N
160	10.143.34.237	pruhub3-168cfd2c	s16gul	CLOUD SQL	PostgreSQL 9	0	16	8	0	t	1	1	1	2025-05-14 00:00:00	2025-05-14 09:13:32	2025-07-21 11:26:51	\N	[{"password":"v1CtdwHkyX@7RYi8","username":"dba_user"},\n{"password":"9TKYrP$8kU15Ny-O","username":"pruhub_user"},\n{"password":"N/TdoFP@ey0nwRWP","username":"service_user"}]	\N
161	10.143.17.22	DEV DBA_USERx	10.143.17.22	CLOUD SQL	Postgres 9.0	0	16	8	0	t	1	1	2	2025-05-21 00:00:00	2025-05-21 14:02:27	2025-05-21 14:02:27	\N	pw: lAb43za16dHCMWbTpOFqV3tNJXi449rL\nu: postgres	\N
162	10.143.17.16	CLOUD POSTGRES	nprd-DB-dev-tylzpr	CLOUD SQL	Postgres 16.8	0	32	16	0	t	1	1	1	2025-05-26 00:00:00	2025-05-26 15:49:47	2025-05-26 15:56:43	\N	"password": "9QLP2ubRW6FENboO0H7arWr5vq91GJ1S"\n"username": "postgres"	\N
163	10.143.17.17	CLOUD POSTGRES	nprd-API-dev-tylzpr	CLOUD SQL	Postgres 16.8	0	32	16	0	t	1	1	4	2025-05-26 00:00:00	2025-05-26 15:52:54	2025-05-26 15:57:00	\N	"password": "mKvfzOHMGKiZ6uvH7g5qd8EP3Nyrtwfb"\n"username": "postgres"	\N
164	10.170.52.68	SHARE PROD	10.170.52.68	WINDOWS 2016	Postgres 8.3	0	24	8	0	t	1	1	1	2025-05-27 00:00:00	2025-05-27 14:35:12	2025-05-27 14:38:46	\N	IPS_Prundetial	\N
165	10.170.52.70	SHARE PROD	10.170.52.70	WINDOWS 2012	Postgres 15.13	0	8	8	0	t	1	1	1	2025-05-27 00:00:00	2025-05-27 14:37:44	2025-05-28 16:48:19	\N	88	\N
166	10.143.17.10	REDSOFT	INVESTMEN	CLOUD SQL	Microsoft SQL Server 2019	0	16	8	0	t	1	1	1	2025-06-03 00:00:00	2025-06-03 15:19:47	2025-06-03 15:19:47	\N	IP : 10.143.17.10\nUsername : sqlserver\nPassword : ceJym<Le	\N
167	10.170.49.251	NRPD	VIDHOLXUINTDB01	Red Hat 7 (Rhell)	PostgreSQL 14.12	0	15	8	0	t	1	1	2	2025-06-17 00:00:00	2025-06-17 11:37:25	2025-06-17 11:37:25	\N	10.170.49.251	\N
168	10.170.49.211	DEV NRPOD	VIDHOWNUSFSAP02	Windows Server 2016	PostgreSQL 16.9	0	16	4	0	t	1	1	1	2025-06-23 00:00:00	2025-06-23 15:39:00	2025-07-03 09:25:06	\N	PostgreSQL 16.9\nPRUASIA\\SQLAGTSVCDEV  \nJ4k@rta21 \n	\N
7	10.170.53.131	New ODS - PROD	VIDHOLXPODSDB01	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	160	16	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	997 GB	400
8	10.170.53.23	PRUForce DB PRD	VIDHOPLINAOBDB1	Red Hat 6.10 (RHEL)	(EnterpriseDB Advanced Server 14.13.1)	0	171	20	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-01-06 11:44:20	\N	1400 GB	400
9	10.171.84.55	SME omni PRD	VIDDCLXPSMEDB01	Red Hat 6.10 (RHEL)	PostgreSQL 14.13	0	31	24	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-03-20 11:29:37	\N	79 GB	400
10	10.171.84.56	SME Pruworks PRD	VIDDCLXPSMEDB02	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	23G	20	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-10-19 20:05:17	\N	217 GB	400
11	10.171.84.68	SME DB PRD	VIDDCLXPSMEDB04-new	Red Hat 6.10 (RHEL)	PostgreSQL 10.7 	0	19	6	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	 GB	400
12	10.170.53.101	nbwf,  DB Workflow PRD	VIDDCLXPAOBDB02	Red Hat  7.9  (RHEL)	(EnterpriseDB Advanced Server 14.13.1)	0	50	28	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-28 10:24:26	\N	892 GB	400
13	10.171.84.117	Magnum Pure PRD	VIDDCLXPMGPDB01	Red Hat  7.9  (RHEL)	(EnterpriseDB Advanced Server 9.6.2.7) 	0	16	16	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	571 GB	400
14	10.170.53.200	Corespondence DB PRD	VIDDCLXPCDSDB01	Red Hat (RHEL) 7.9	PostgreSQL 14.12	0	31	4	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-15 10:30:32	\N	443 GB	400
137	10.171.211.128	DR GP	SIDDCLXPGPNAP06	Red Hat 6.10 (RHEL)	Greenplum Node 6	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
169	10.143.17.96	pruhub3-a2202659	c5fzh0	asia-southeast2	POSTGRES_9_6	0	38	1	0	t	1	1	4	2025-07-02 00:00:00	2025-07-02 13:28:37	2025-07-02 14:38:47	\N	    "default_password": "UQTjnEpIOucHfEKaHHA8fDE2578DiXCu",\n    "default_username": "postgres",	\N
170	10.143.17.121	onepulseplatpg-1a3b455f 	eawwbd	asia-southeast2	POSTGRES_12	0	38	1	0	t	1	1	4	2025-07-02 00:00:00	2025-07-02 13:29:56	2025-07-02 14:39:18	\N	  "default_password": "b9b4cf99149f76d2",\n  "default_username": "postgres",	\N
171	10.143.17.88	onepulseplatform-8ec602c4	m9wvmh	asia-southeast2	POSTGRES_12	0	38	1	0	t	1	1	4	2025-07-02 00:00:00	2025-07-02 13:30:55	2025-07-02 14:39:34	\N	"default_password": "e4f88211cf99b3e7",\n  "default_username": "postgres",	\N
172	10.171.84.145	clone 92	VIDDCLXPENTDB01T	Red Hat 8.10 (RHEL)	Postgres 15.0	0	19	4	0	t	1	1	1	2025-07-16 00:00:00	2025-07-16 16:51:47	2025-07-16 16:51:47	\N	padmin/Password09 root/today123	\N
173	10.143.34.26	digitalpartner-new-6d79c8d4	babq79	Red Hat Enterprise Linux 	Postgres 12	0	16	8	0	t	1	1	2	2025-07-21 00:00:00	2025-07-21 11:25:14	2025-07-21 11:25:15	\N	digitalpartner-new-6d79c8d4	\N
174	10.143.17.92	viddrlxddgpap01db-new-d5f22d10	lo943j	Red Hat Enterprise Linux 	Postgres 12	0	16	8	0	t	1	1	1	2025-07-21 00:00:00	2025-07-21 11:26:05	2025-07-21 11:39:28	\N	viddrlxddgpap01db-new-d5f22d10 "default_password": "15d78c3d849493ee",\n "default_username": "digitalpg",	\N
175	10.143.34.58	pmnwf-new2-6a194f8d-replica001	fhsl34a	Red Hat Enterprise Linux 	POSTGRES_9_6	0	16	8	0	t	1	1	1	2025-07-21 00:00:00	2025-07-21 11:38:52	2025-07-21 11:38:52	\N	POSTGRES_9_6	\N
\.


--
-- Data for Name: hardware_131024; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.hardware_131024 (id, make, model, serial, os_name, os_version, type, ram, cpu, status, current, company_id, user_id, provaider_id, purchased_at, created_at, updated_at, deleted_at, note) FROM stdin;
132	10.171.86.72	UAT NBWF	SR02701142	Red Hat 7 (Rhell)	Postgres EDB 14.0	0	16	8	0	t	1	\N	4	2024-10-12 00:00:00	2024-10-12 16:31:46	2024-10-12 16:31:46	\N	SR02701142
55	10.170.53.99	CM	PRUIDWFCM02	AIX	DB2 v10.5.0.8	0	42	3	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-12 16:33:42	\N	Afdoli Fahmi , MIS \nkill locking db2 \n- db2top -d bpmdbphs (DB_Name)\n- tekan shift u\n- Klik a lalu ketik id yg mau di kill\n- db2 "force application(28866 contoh)"\ndb2 "force application(22948)"
48	10.171.84.124	GreenPlum Node 2	SIDDRLXPGPNAP02	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Afdoli Fahmi , MIS
80	10.141.15.36	TLM TLM	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016	0	16	8	0	t	1	1	2	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	user : SRVPLAIPRTLMSMARTS01 Password : Q42PDxA(
81	10.141.15.39	SUN SUN	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016	0	16	8	0	t	1	1	2	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	sun.dbadmin�Password09
86	10.141.23.11	Renova (Cloud VM) Renova_Individual	service db cloud	UBUNTU 10,22 GCP	SQL Server 2017 std edition	0	16	8	0	t	1	1	2	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	user/pass: renovaid/Password12 | sa/Password09
87	10.143.34.79	Renova (Cloud Instance) Renova_Individual	service db cloud	UBUNTU 10,22 GCP	SQL Server 2019 std edition	0	16	8	0	t	1	1	2	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	user/pass: renovadb/5J+a]OlQ | user/pass: sqlserver/XpIeX_N&
88	10.141.23.9	Ifrs17 (cloud_VM) ifrs17	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016 std edition	0	16	8	0	t	1	1	2	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	user/pass: sa/Password09 | user/pass : PRUASIA\\407409\tWindows_autentication (superuser)
89	10.143.27.253	jatisSMS (Cloud Instance) 	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016 std edition	0	16	8	0	t	1	1	2	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	user/pass: sqlserver/Svu72BhZ
97	10.143.34.5 	PROD DB SCRM	service db cloud	UBUNTU 10,22 GCP	SQL Server 2022	0	16	8	0	t	1	1	2	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	\N
96	10.143.27.57	UAT DB SCRM	service db cloud	UBUNTU 10,22 GCP	SQL Server 2022	0	16	8	0	t	1	1	2	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	\N
100	10.143.34.70	PROD PSA	PSA	UBUNTU 10,22 GCP	Google Cloud	0	16	8	0	t	1	1	2	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	user/pas : postgres/bFAyEyz383ITMZ8MHImEfAnDzKZSTO74
99	10.143.17.69	UAT PSA	PSA	UBUNTU 10,22 GCP	Google Cloud	0	16	8	0	t	1	1	2	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	user/pas : postgres/AmZsWOWWl949v3lAtKMJeT9AVAqlBbHu
61	10.171.83.52	DB Server SCCM Server	viddcwnpscmap02	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Abdul Qahar
62	10.170.53.198	DB Server iCare & IVRDB	vidhowpivrdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	uknow
63	10.170.48.37	DB Server Playback Portal	vidhownpnpsdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Ridwan Royani
64	10.170.48.101	DB Server New AWMS Server (Tower)	viddcwnpawmap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Abdul Qahar
65	10.170.48.35	DB Server Sentinel	vidhownpnmsap02	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Ridwan Royani
66	10.170.109.19	DB Server Q-Matic	vidptwnpqmtap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Ridwan Royani
67	10.170.53.199	DB Server iCare & IVRDB	viddrwpivrdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	uknow
69	10.170.48.63	Is not DB Server	sidhopwinscmap1	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Taufik Ridwan
71	10.171.210.50	Decommissioning	siddrwnpneuap01	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Ridwan Royani
19	10.170.53.106	ODS	VIDHOWNPODSDB01	Windows Server 2016	SQL Server 2016	0	32	4	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-12 12:46:52	\N	Afdoli Fahmi 
57	10.170.53.14	MFPDATA	VIDHOPLINIMFDB1	Red Hat (RHEL) 8.10	DB2 v10.5.0.5	0	62	8	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-11 10:45:38	\N	Afdoli Fahmi , MIS
56	10.171.84.43	RESDB	VIDDCLXPODMDB01	Red Hat (RHEL) 7.9	DB2 v10.5.0.3	0	31	4	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-11 14:13:04	\N	Afdoli Fahmi , MIS  \n user SPLAIODM pass: Password09 di ip\n10.171.84.43 (BRMS)
79	10.143.34.54	PMN DB nbwf	service db cloud	UBUNTU 10,22 GCP	EnterpriseDB 9.6.2.7	0	16	8	0	t	1	1	2	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	\N
3	10.170.53.29	BPM DB	VIDHOPLINBPMDB1	Red Hat (RHEL)	EnterpriseDB 9.6.5.10	0	64	4	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	148 GB
60	10.170.49.107	UAT	viddrlxdatsap01	Red Hat 6.10 (RHEL)	Oracle Database Server	0	31	8	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Afdoli Fahmi , MIS
7	10.170.53.131	New ODS - PROD	VIDHOLXPODSDB01	Red Hat (RHEL)	EnterpriseDB 9.6.5.10	0	160	16	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-09 17:54:55	\N	997 GB
12	10.170.53.101	nbwf,  DB Workflow	VIDDCLXPAOBDB02	Red Hat (RHEL)	EnterpriseDB 9.6.2.7	0	44	16	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	892 GB
16	10.170.53.108	Base DB	VIDDCLXPBSEDB06	Red Hat (RHEL)	PostgreSQL 14.12	0	62	8	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-12 10:58:26	\N	59 GB
101	10.143.34.101	PROD PSA	PSA	UBUNTU 10,22 GCP	Google Cloud	0	16	8	0	t	1	1	2	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	user/pas : postgres/xIqL6MHtPJWYA1OjaPaW4n9UM844LYdF
29	10.170.53.46	CRM Archive	VIDHOWNPCRMDB03	Windows Server 2016	SQL Server 2016	0	24	4	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Victor Liliwidjaja
30	10.170.48.84	Reinsurance DB Prod	VIDHOWNPREIDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Fikrilsyah Algoumar
31	10.170.48.77	E-Submission NB	VIDHOWNPXARDB01	Windows Server 2016	SQL Server 2016	0	8	2	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Martinus Marlim
76	10.170.48.33	Decommissioning NICE 	vidhownpndsdb03	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Ridwan Royani
78	10.171.140.90	Is not DB Server ( No DB Service)	viddcwnppbhap01	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Arif Hidayat Husni
20	10.170.53.36	Internal DB (Moveit)	VIDHOWNPINTDB02	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Afdoli Fahmi 
21	10.170.48.98	Reporting DB SRSS	VIDHOWNPREPDB01	Windows Server 2016	SQL Server 2016	0	32	4	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Afdoli Fahmi 
18	10.170.53.147	Consolidate Database Server(XML)	VIDHOWNPINTDB01	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Afdoli Fahmi 
4	10.171.140.16	Payment Database	VIDDCLXPNPHDB01-New	Red Hat (RHEL)	EnterpriseDB 9.6.5.10	0	32	4	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	688 GB
13	10.171.84.117	Magnum Pure	VIDDCLXPMGPDB01	Red Hat (RHEL)	EnterpriseDB 9.6.2.7	0	16	16	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	571 GB
59	10.170.49.144	UAT	vidhownuinsdb01	Windows Server 2012 R2	Oracle Database Server	0	31	8	0	t	1	1	3	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-12 12:52:34	\N	Afdoli Fahmi , MIS
8	10.170.53.23	PRUForce DB	VIDHOPLINAOBDB1	Red Hat (RHEL)	EnterpriseDB 9.6.5.10	0	328	40	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	1400 GB
53	10.171.84.104	BPM	VIDDCLXPBPMDB01	Red Hat 6.10 (RHEL)	DB2 v10.5.0.3	0	58	8	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-12 16:33:16	\N	Afdoli Fahmi , MIS\nkill locking db2 \n- db2top -d bpmdbphs (DB_Name)\n- tekan shift u\n- Klik a lalu ketik id yg mau di kill\n- db2 "force application(28866 contoh)"\ndb2 "force application(22948)"
1	10.170.53.102	AOB DB ESUB	VIDDCLXPAOBDB03	Red Hat (RHEL)	EnterpriseDB 9.6.2.7	0	32	4	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	814 GB
2	10.170.53.103	AOB EPOLICY DB (WAB,Fuse) 	VIDDCLXPAOBDB04	Red Hat (RHEL)	EnterpriseDB 9.6.2.7	0	32	6	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-08 21:25:18	\N	200 GB DISK
49	10.171.84.125	GreenPlum Node 3	SIDDRLXPGPNAP03 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Afdoli Fahmi , MIS
50	10.171.84.126	GreenPlum Node 4	SIDDRLXPGPNAP04 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Afdoli Fahmi , MIS
51	10.171.84.128 	GreenPlum Node 5	SIDDRLXPGPNAP05	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Afdoli Fahmi , MIS
52	10.171.84.129	GreenPlum Node 6	SIDDRLXPGPNAP06	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Afdoli Fahmi , MIS
54	10.170.53.150	HPX	VIDHOLXPHPEDB01	Red Hat  8.10  (RHEL)	DB2 v10.5.0.3	0	15	4	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-10 13:58:17	\N	Afdoli Fahmi , MIS
45	10.171.84.70	GreenPlum Master	SIDDRLXPGPMAP01 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Afdoli Fahmi , MIS
46	10.171.84.71 	GreenPlum Secondary Master	SIDDRLXPGPSAP01	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Afdoli Fahmi , MIS
47	10.171.84.123	GreenPlum Node 1	SIDDRLXPGPNAP01	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Afdoli Fahmi , MIS
58	10.171.82.73	UAT	sidhopwinvnxap1	Red Hat 6.10 (RHEL)	MySQL Database Server	0	31	8	0	t	1	1	1	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Afdoli Fahmi , MIS
70	10.170.216.196	DB Server WINPAKPRO	sidpcwnpacdap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	uknow
72	10.170.48.235	DB Server(NewSolarWins DB)	vidhopwinifrdb1	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	uknow
73	10.170.216.69	DB Server FXAW	vidpcwnpawmap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	uknow
75	10.170.48.102	Decommissioning	vidhownpintdb07	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	uknow
102	10.170.52.70	PROD	VIDHOWNPSFSAP04	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	Upgrade Postgres v.8.3 to 14.3
82	10.143.34.42	One Pulse Platform onepulse	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	\N
83	10.143.17.6	smartclaim smartclaim	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	\N
84	10.143.34.206	smartclaim ( replica) smartclaim	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	\N
85	10.143.34.202	smartclaim ( master) smartclaim	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	\N
103	10.170.52.28	NPRD	WINTEL	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	Upgrade Postgres v.8.3 to 14.3
104	10.170.53.114	NPRD	vidhownp2faap01 	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	Upgrade Postgres v.8.3 to 14.3
94	10.143.34.226	oltp 	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 13.13	0	16	8	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	oltp-svc/KT3meM@r-BdEBF1p
95	10.143.17.59	keycloack keycloack	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 13.13	0	16	8	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	user/pas: postgres/d5iv2cp2t2LmRfIXECtypk1JBh71r7bl
90	10.143.21.8	edoc (cloud_VM) edoc	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	user/pass: edocplai/edoc2022
91	10.143.17.29	edoc (cloud_Instance) edoc	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	user/pass: postgres/o1Gy1WbqQ3DZcTt4hyVGzkCzEHnFEKxb | user/pass:edocplai/U0Y42h8mngzu-D8@
92	10.143.36.140	edoc (cloud_VM) edoc	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	user/pass: edocplai/edoc2022
93	10.143.34.223	edoc (cloud_Instance) edoc	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	user/pass: postgres/agG0nkLGOCphBdCwsUD5Cd1B8W0TmADT | user/pass: edocplai/IOSBQgiK6hOiEvu-
105	10.170.48.110	NPRD	VIDHOLXPBAKAP01	Red Hat  8.10  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	Upgrade Postgres v.8.3 to 14.3
106	10.170.48.109	PROD	VIDHOLXPBAKAP02	Red Hat  7.9  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	Upgrade Postgres v.8.3 to 14.3
108	10.171.86.72	NPRD	LINUX RHELL	Red Hat  7.9  (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	Upgrade Postgres v.10 to 14.3
109	10.171.213.79	NPRD	VIDDRLXUSMEAP04	Red Hat  8.1 (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	Upgrade Postgres v.10 to 14.3
110	10.170.49.150	NPRD	LINUX RHELL	Red Hat  7.9  (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	Upgrade Postgres v.10 to 14.3
111	10.170.49.191	NPRD	vidholdodsdb1	Red Hat  7.9  (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	Upgrade Postgres v.10 to 14.3
131	10.170.49.136	DEV DBA_USER	VIDDRLXUGBQDB01	Red Hat  8.10  (RHEL)	Postgres 16.0	0	125GB	32	0	t	1	1	4	2024-10-10 00:00:00	2024-10-10 21:31:41	2024-10-10 21:31:41	\N	DEV NEW Postgres 16 | dba_user dba_user | 5432 | owner | Radit
10	10.171.84.56	SME Pruworks	VIDDCLXPSMEDB02	Red Hat (RHEL)	 PostgreSQL 10.7 	0	23G	20	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-09 14:16:46	\N	217 GB
6	10.170.53.57	Training	VIDDCLXPAOBDB06	Red Hat (RHEL)	PostgreSQL 10.4	0	32	10	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	109 GB
15	10.171.84.92	Postgre Enablement Tribe COMPLIANCE	VIDDCLXPENTDB01	Red Hat (RHEL)	PostgreSQL 10.4	0	15	4	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	10 GB
14	10.170.53.200	Corespondence DB	VIDDCLXPCDSDB01	Red Hat (RHEL)	PostgreSQL 10.7 	0	31	4	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	443 GB
9	10.171.84.55	SME omni	VIDDCLXPSMEDB01	Red Hat (RHEL)	 PostgreSQL 10.7	0	19	6	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	79 GB
36	10.170.53.68	CRM	VIDHOWNPCRMDB02	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Victor Liliwidjaja
37	10.170.53.44	CRM	VIDHOWNPCRMDB01	Windows Server 2016	SQL Server 2016	0	39	12	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Victor Liliwidjaja
38	10.170.53.105	DataMart	VIDHOWNPDTMDB01	Windows Server 2016	SQL Server 2016	0	32	4	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Fikrilsyah Algoumar
39	 10.170.53.49	PG BCA	VIDHOWNPH2BDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Bhimo Bhaskoro
40	10.170.53.153	OCR DB	VIDDCWNPOCRDB01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-08 17:06:04	\N	Juliana
117	10.170.49.123	NPRD	SIDHOUWINSAPDB2	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	\N
11	10.171.84.68	SME DB	VIDDCLXPSMEDB04-new	Red Hat (RHEL)	 PostgreSQL 10.7	0	19	6	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	 GB
5	10.170.53.56	Database Leads	VIDDCLXPAOBDB05	Red Hat (RHEL)	PostgreSQL 14.12	0	32	10	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	109 GB
107	10.171.84.78	NPRD	viddolxpgpmap01	Red Hat  7.9  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	Upgrade Postgres v.8.3 to 14.3
17	10.171.84.100	AI DB	VIDDCLXPAICDB01	Red Hat (RHEL)	PostgreSQL 10.4	0	32	4	0	t	1	1	4	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	197 GB
68	10.170.53.186	Is not DB Server	vidhownpprpap02	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	uknow
74	10.170.53.185	Is not DB Server New Actuary Apps	vidhownpprpap01	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Daniel Agustinus Rahardjo / Salman Farizi 
120	10.170.49.196	NPRD	vidhownupacdb01	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	Finger Print
122	10.170.49.210	NPRD	vidhodwinintdb7	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	Dev Moveit
127	10.170.49.81 	NPRD	sidhodwinepvdb1	Windows Server 2012 R2 	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	e-Payment Voucher
112	10.171.212.215	PROD	VIDDRWNDNRSDB01	Windows Server 2016	SQL Server 2016 express SP3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	Uninstal SQLEXPRESS
113	10.171.210.25	NPRD	VIDDRWNPCCVAP01	Windows Server 2016	SQL Server 2016 express SP3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	Uninstal SQLEXPRESS
114	10.171.212.142	NPRD	viddcwndhpxap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	\N
115	10.170.48.85	NPRD	WINTEL	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	\N
116	10.170.49.11	NPRD	VIDHOWNUPDCAP01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	\N
128	10.170.49.88 	NPRD	VIDHOWNUINTDB01	Windows Server 2019	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	\N
98	10.141.48.131	NRPD STAGGING REMOTE SQL none	service db cloud	Windows Server 2016 GCP	none	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	\N
77	10.170.48.128	DB Server SOLARWIN_ORION	vidhopwinswdap1	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	uknow
25	10.170.48.44	NICE DB	VIDHOWNPNDSDB02	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Ridwan Royani
43	10.171.84.215	Power BI	VIDDCWNPPBIAP01	Windows Server 2016	SQL Server 2016	0	96	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Rizky Karunia
42	10.171.84.205	New IFRS 	VIDDRWNPIFRDB01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-08 17:06:20	\N	Mimi Winata
41	10.170.53.5	EPOS DB	VIDHOPWINPOSDB1	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-08 17:06:34	\N	Afdoli Fahmi 
26	10.170.48.186	Ops Dashboard DB	VIDHOWNPOPSDB01	Windows Server 2016	SQL Server 2016	0	8	2	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Afdoli Fahmi 
22	10.170.48.177	Database Solarwind, SCCM	SIDHOPWINIFRDB1	Windows Server 2016	SQL Server 2016	0	16	3	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Afdoli Fahmi 
23	10.170.48.58	Internal DB - 03	VIDHOWNPINTDB03	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Afdoli Fahmi 
24	10.170.48.211	NICE DB	VIDHOWNPNDSDB01	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Ridwan Royani
27	10.170.48.85	GPP Report	SIDHOPWINMDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Afdoli Fahmi 
28	10.170.48.112	Customer Analytic	SIDHOPWINDALDB1	Windows Server 2016	SQL Server 2016	0	32	12	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Afdoli Fahmi 
32	10.170.48.122	Sharepoint DB	SIDHOPWINSHPDB1	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Syofianer Fitra
33	10.170.48.215	K2 DB server	VIDHOWNPKTWDB01	Windows Server 2016	SQL Server 2016	0	20	2	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Syofianer Fitra
34	10.170.53.91	SUN GL	SIDHOPWINSUNDB1	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Syofianer Fitra
35	10.170.53.187	PROD New Actuary DB	VIDHOWNPPRPDB01	Windows Server 2016	SQL Server 2016	0	64	4	0	t	1	1	5	2024-01-01 12:00:12	2024-01-01 12:00:12	2024-10-01 12:00:12	\N	Syofianer Fitra
129	10.170.216.100	PROD	SIDHOWNPCCVAP01	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	Upgrade to 2016 SP 3
130	10.170.53.61	PROD	vidhownpcrmap03	Windows Server 2019 STD	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	Microsoft SQL Server 2008 R2 
118	10.170.49.188	NPRD	vidhodwinintdb1	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	\N
119	10.170.49.195	NPRD	vidhowndefmdb01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	\N
121	10.170.49.197	NPRD	vidhowndeprap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	\N
123	10.170.49.216	NPRD	sidhouwinepvap1	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	\N
124	10.170.49.217	NPRD	vidhownuefmap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	\N
125	10.170.49.78	NPRD	sidhouwinepvdb1	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	\N
126	10.170.49.80	UAT	SIDHOUWINSFTP01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	\N
\.


--
-- Data for Name: hardware_140525; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.hardware_140525 (id, make, model, serial, os_name, os_version, type, ram, cpu, status, current, company_id, user_id, provaider_id, purchased_at, created_at, updated_at, deleted_at, note, max_con) FROM stdin;
96	10.143.27.57	DB SCRM UAT	service db cloud	UBUNTU 10,22 GCP	SQL Server 2022	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	\N	400
147	10.143.27.238	LINUX SQLSERVER PRD	IDLIFED4VZP1CVI	Ubuntu 20.04	SQL Server 2022	0	8	4	0	t	1	1	5	2024-11-07 00:00:00	2024-11-07 08:34:07	2024-11-07 08:34:08	\N	sqlserver\n\n@78$hZ!L	400
5	10.170.53.56	Database Leads PRD	VIDDCLXPAOBDB05	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	31	36	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-28 10:44:23	\N	109 GB	400
10	10.171.84.56	SME Pruworks PRD	VIDDCLXPSMEDB02	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	23G	20	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-10-19 20:05:17	\N	217 GB	400
6	10.170.53.57	Training PRD	VIDDCLXPAOBDB06	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	32	10	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-10-20 04:04:31	\N	109 GB	400
103	10.170.52.28	NPRD	WINTEL	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
104	10.170.53.114	NPRD	vidhownp2faap01 	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
105	10.170.48.110	NPRD	VIDHOLXPBAKAP01	Red Hat  8.10  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
108	10.171.86.72	NPRD	LINUX RHELL	Red Hat  7.9  (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.10 to 14.3	400
109	10.171.213.79	NPRD	VIDDRLXUSMEAP04	Red Hat  8.1 (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.10 to 14.3	400
110	10.170.49.150	NPRD	LINUX RHELL	Red Hat  7.9  (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-12-13 09:41:37	\N	Postgres v.10 to 14.3 | fuse DB  pruasia\\sqlagtsvcdev\nPassword09	400
127	10.170.49.81 	NPRD	sidhodwinepvdb1	Windows Server 2012 R2 	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	e-Payment Voucher	400
113	10.171.210.25	NPRD	VIDDRWNPCCVAP01	Windows Server 2016	SQL Server 2016 express SP3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Uninstal SQLEXPRESS	400
114	10.171.212.142	NPRD	viddcwndhpxap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N	400
115	10.170.48.85	NPRD	WINTEL	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N	400
116	10.170.49.11	NPRD	VIDHOWNUPDCAP01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N	400
128	10.170.49.88 	NPRD	VIDHOWNUINTDB01	Windows Server 2019	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N	400
69	10.170.48.63	Is not DB Server PRD	sidhopwinscmap1	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Taufik Ridwan	400
99	10.143.17.69	PSA UAT	PSA	UBUNTU 10,22 GCP	Google Cloud	0	16	8	0	t	1	1	2	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	user/pas : postgres/AmZsWOWWl949v3lAtKMJeT9AVAqlBbHu	400
118	10.170.49.188	NPRD	vidhodwinintdb1	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N	400
119	10.170.49.195	NPRD	vidhowndefmdb01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N	400
60	10.170.49.107	UAT	viddrlxdatsap01	Red Hat 6.10 (RHEL)	Oracle Database 11g Enterprise Edition	0	31	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS	400
8	10.170.53.23	PRUForce DB PRD	VIDHOPLINAOBDB1	Red Hat 6.10 (RHEL)	(EnterpriseDB Advanced Server 14.13.1)	0	171	20	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-01-06 11:44:20	\N	1400 GB	400
133	10.171.211.50	DR GP	SIDDCLXPGPMAP01	Red Hat 6.10 (RHEL)	Greenplum Node Master	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
7	10.170.53.131	New ODS - PROD	VIDHOLXPODSDB01	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	160	16	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	997 GB	400
48	10.171.84.124	GreenPlum Node 2 PRD	SIDDRLXPGPNAP02	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
61	10.171.83.52	DB Server SCCM Server PRD	viddcwnpscmap02	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Abdul Qahar	400
68	10.170.53.186	Is not DB Server PRD	vidhownpprpap02	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
74	10.170.53.185	Is not DB Server New Actuary Apps PRD	vidhownpprpap01	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Daniel Agustinus Rahardjo / Salman Farizi 	400
76	10.170.48.33	Decommissioning NICE  PRD	vidhownpndsdb03	Windows Server 2016	SQL Server 2012	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani	400
78	10.171.140.90	Is not DB Server ( No DB Service) PRD	viddcwnppbhap01	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Arif Hidayat Husni	400
58	10.171.82.73	UAT	sidhopwinvnxap1	Red Hat 6.10 (RHEL)	MySQL Database Server	0	31	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS	400
9	10.171.84.55	SME omni PRD	VIDDCLXPSMEDB01	Red Hat 6.10 (RHEL)	PostgreSQL 14.13	0	31	24	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-03-20 11:29:37	\N	79 GB	400
121	10.170.49.197	NPRD	vidhowndeprap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-03-25 17:39:18	\N	11	400
79	10.143.34.54	PMN DB nbwf PRD	service db cloud	UBUNTU 10,22 GCP	EnterpriseDB 9.6.2.7	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-11-14 17:52:24	\N	10.143.34.54 \nPMN DB	400
123	10.170.49.216	NPRD	sidhouwinepvap1	Windows Server 2016	SQL Server 2016 SP 3	0	16,200	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-05-04 16:18:45	\N	123	400
75	10.170.48.102	Decommissioning PRD	vidhownpintdb07	Windows Server 2016	SQL Server 2012	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
156	10.170.109.42	Server Recording ACRA  PRD	VIDPTWNPACRAP01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	1	2025-01-14 00:00:00	2025-01-14 09:07:24	2025-01-14 09:07:37	\N	Login : VIDPTWNPACRAP01\\pruadmin\nPassword : P@ssw0rd\nVIDPTWNPACRAP01	400
117	10.170.49.123	NPRD	SIDHOUWINSAPDB2	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-11-11 13:43:00	\N	PRUASIA\\sqlagtsvcdev\nPassword09	400
111	10.170.49.191	NPRD	vidholdodsdb1	Red Hat  7.9  (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-12-13 09:41:05	\N	Upgrade Postgres v.10 to 14.3 pruasia\\sqlagtsvcdev\nPassword09	400
86	10.141.23.11	Renova (Cloud VM) Renova_Individual UAT	service db cloud	Windows Server 2016	SQL Server 2017 std edition	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-01-10 10:30:37	\N	user/pass: renovaid/Password12 | sa/Password09	400
126	10.170.49.80	UAT	SIDHOUWINSFTP01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-01-28 10:02:30	\N	Hanan	400
157	10.170.49.73	UAT 	VIDDCLXDGAIAPP01	Red Hat Enterprise Linux 	Postgres 14.0	0	16	23	0	t	1	1	4	2025-02-06 00:00:00	2025-02-06 14:38:58	2025-02-06 14:38:58	\N	VIDDCLXDGAIAPP01	400
45	10.171.84.70	GreenPlum Master PRD	SIDDRLXPGPMAP01 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2025-01-15 10:58:50	\N	Afdoli Fahmi , MIS\n/GPDB_DATA/master/gpseg-1/	400
62	10.170.53.198	DB Server iCare & IVRDB PRD	vidhowpivrdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
67	10.170.53.199	DB Server iCare & IVRDB PRD	viddrwpivrdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
55	10.170.53.99	CM DB2 PRD	PRUIDWFCM02	AIX 7	DB2 v10.5.0.8	0	42	3	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS \nkill locking db2 \n- db2top -d bpmdbphs (DB_Name)\n- tekan shift u\n- Klik a lalu ketik id yg mau di kill\n- db2 "force application(28866 contoh)"\ndb2 "force application(22948)"	400
57	10.170.53.14	MFPDATA DB2 PRD	VIDHOPLINIMFDB1	Red Hat (RHEL) 8.10	DB2 v11.5.8.0	0	62	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-05 10:52:32	\N	Afdoli Fahmi , MIS	400
148	10.170.53.202	TRIAL DB SQL SERVER	TRIAL	WINDOWS 2012 R2	SQL Server 2022	0	16	8	9	t	1	1	5	2024-11-13 00:00:00	2024-11-13 07:52:19	2024-11-13 07:52:27	\N	10.170.53.202\n.\\admintemp\nPassword09	400
159	10.170.53.78	ORACLE PRD	VIDHOWNPINSDB01	WINDOWS 2012 R2	Oracle 11g Windows	0	32	8	0	t	1	1	3	2025-02-21 00:00:00	2025-02-21 15:02:20	2025-02-21 15:02:20	\N	CREATE USER mis_user IDENTIFIED BY Password09;	400
144	10.170.49. 	DBA_USER DEV	VID	Red Hat Enterprise Linux 	(EnterpriseDB Advanced Server 14.13.1)	0	62G	24	0	t	1	1	4	2024-10-22 00:00:00	2024-10-22 20:18:04	2024-10-23 07:15:51	\N	10.170.49.180	400
134	10.171.211.51	DR GP	SIDDCLXPGPSAP01	Red Hat 6.10 (RHEL)	Greenplum Node Standby	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
142	10.170.49.180	GP DEV	VIDHOLXDGPNAP03	Red Hat Enterprise Linux 	Greenplum Node 4.3.33	0	62G	24	0	t	1	1	4	2024-10-22 00:00:00	2024-10-22 18:35:26	2024-10-22 20:21:47	\N	VIDHOLXDGPNAP03	400
143	10.170.49.181	GP DEV	VIDHOLXDGPNAP04	Red Hat Enterprise Linux 	Greenplum Node 4.3.33	0	62G	24	0	t	1	1	4	2024-10-22 00:00:00	2024-10-22 20:11:06	2024-10-22 20:22:04	\N	VIDHOLXDGPNAP04	400
71	10.171.210.50	NICE Engage Unified PRD	siddrwnpneuap01	Windows Server 2016	no db	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-02 15:33:59	\N	Ridwan Royani	400
81	10.141.15.39	SUN SUN PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-11-26 13:43:18	\N	SUN\n10.141.15.39 (user DB)\nsun.dbadmin \nPassword09	400
151	10.143.17.126	x86_64-pc-linux-gnu Debian  PRD	 on x86_64-pc-linux-gnu, compiled by Debian 	CLOUD SQL	PostgreSQL 15.8	0	16	32	0	t	1	1	4	2024-12-13 00:00:00	2024-12-13 14:55:20	2024-12-16 09:53:41	\N	ALTER USER prumagnumpure WITH PASSWORD 'cNA4-K/C2VZ3Wh!!';\n5432\n	400
155	10.143.27.236	Cloud INTUATDB PRD	IDLIFED4VZP1CVI	Ubuntu 20	SQL Server 2019	0	6	2	0	t	1	10	1	2024-12-17 10:00:00	2024-12-17 16:00:37	2025-02-06 09:45:15	\N	    "private_address": "10.143.27.236",\n    "root_password": "+}CGp[@-"\n}\nuser sqlserver	400
19	10.170.53.106	ODS PRD	VIDHOWNPODSDB01	Windows Server 2016	SQL Server 2016	0	32	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 	400
21	10.170.48.98	Reporting DB SRSS PRD	VIDHOWNPREPDB01	Windows Server 2016	SQL Server 2016	0	32	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 	400
23	10.170.48.58	Internal DB - 03 PRD	VIDHOWNPINTDB03	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 	400
24	10.170.48.211	NICE DB PRD	VIDHOWNPNDSDB01	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani	400
25	10.170.48.44	NICE DB PRD	VIDHOWNPNDSDB02	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani	400
26	10.170.48.186	Ops Dashboard DB PRD	VIDHOWNPOPSDB01	Windows Server 2016	SQL Server 2016	0	8	2	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 	400
27	10.170.48.85	GPP Report PRD	SIDHOPWINMDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 	400
29	10.170.53.46	CRM Archive PRD	VIDHOWNPCRMDB03	Windows Server 2016	SQL Server 2016	0	24	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Victor Liliwidjaja	400
30	10.170.48.84	Reinsurance DB PRD	VIDHOWNPREIDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Fikrilsyah Algoumar	400
31	10.170.48.77	E-Submission NB PRD	VIDHOWNPXARDB01	Windows Server 2016	SQL Server 2016	0	8	2	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-10 11:13:44	\N	Nanda Widy	400
34	10.170.53.91	SUN GL PRD	SIDHOPWINSUNDB1	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Syofianer Fitra	400
17	10.171.84.100	AI DB PRD	VIDDCLXPAICDB01	Red Hat 6.10 (RHEL)	PostgreSQL 10.4	0	32	4	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	197 GB	400
11	10.171.84.68	SME DB PRD	VIDDCLXPSMEDB04-new	Red Hat 6.10 (RHEL)	PostgreSQL 10.7 	0	19	6	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	 GB	400
1	10.170.53.102	AOB DB ESUB PRD	VIDDCLXPAOBDB03	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.2.7	0	32	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	814 GB	400
4	10.171.140.16	Payment Database PRD	VIDDCLXPNPHDB01-New	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	32	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	688 GB	400
3	10.170.53.29	BPM DB PRD	VIDHOPLINBPMDB1	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	64	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	148 GB	400
20	10.170.53.36	Internal DB (Moveit) PRD	VIDHOWNPINTDB02	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-14 10:30:13	\N	Afdoli Fahmi -- > moveitdmz Password09	400
36	10.170.53.68	CRM PRD	VIDHOWNPCRMDB02	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Victor Liliwidjaja	400
37	10.170.53.44	CRM PRD	VIDHOWNPCRMDB01	Windows Server 2016	SQL Server 2016	0	39	12	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Victor Liliwidjaja	400
38	10.170.53.105	DataMart PRD	VIDHOWNPDTMDB01	Windows Server 2016	SQL Server 2016	0	32	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Fikrilsyah Algoumar	400
39	 10.170.53.49	PG BCA PRD	VIDHOWNPH2BDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Bhimo Bhaskoro	400
33	10.170.48.215	K2 DB server PRD	VIDHOWNPKTWDB01	Windows Server 2016	SQL Server 2016	0	20	2	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-27 11:53:25	\N	Syofianer Fitra	400
32	10.170.48.122	Sharepoint DB PRD	SIDHOPWINSHPDB1	Windows Server 2016	SQL Server 2016	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-27 11:54:03	\N	Syofianer Fitra	400
28	10.170.48.112	Customer Analytic PRD	SIDHOPWINDALDB1	Windows Server 2016	SQL Server 2019	0	48	3	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-28 10:03:49	\N	Afdoli Fahmi \nHani Asri Guardiani	400
12	10.170.53.101	nbwf,  DB Workflow PRD	VIDDCLXPAOBDB02	Red Hat  7.9  (RHEL)	(EnterpriseDB Advanced Server 14.13.1)	0	50	28	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-28 10:24:26	\N	892 GB	400
40	10.170.53.153	OCR DB PRD	VIDDCWNPOCRDB01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Juliana	400
41	10.170.53.5	EPOS DB PRD	VIDHOPWINPOSDB1	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 	400
42	10.171.84.205	New IFRS  PRD	VIDDRWNPIFRDB01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Mimi Winata	400
43	10.171.84.215	Power BI PRD	VIDDCWNPPBIAP01	Windows Server 2016	SQL Server 2016	0	96	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Rizky Karunia	400
129	10.170.216.100	PRD	SIDHOWNPCCVAP01	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Upgrade to 2016 SP 3	400
130	10.170.53.61	PRD	vidhownpcrmap03	Windows Server 2019 STD	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Microsoft SQL Server 2008 R2 	400
46	10.171.84.71 	GreenPlum Second Master PRD	SIDDRLXPGPSAP01	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
47	10.171.84.123	GreenPlum Node 1 PRD	SIDDRLXPGPNAP01	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
50	10.171.84.126	GreenPlum Node 4 PRD	SIDDRLXPGPNAP04 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
51	10.171.84.128 	GreenPlum Node 5 PRD	SIDDRLXPGPNAP05	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
52	10.171.84.129	GreenPlum Node 6 PRD	SIDDRLXPGPNAP06	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
63	10.170.48.37	DB Nice Server Playback Portal PRD	vidhownpnpsdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-02 15:35:03	\N	Ridwan Royani	400
64	10.170.48.101	DB Server New AWMS Server (Tower) PRD	viddcwnpawmap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Abdul Qahar	400
65	10.170.48.35	DB Server Sentinel  PRD	vidhownpnmsap02	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-02 15:35:36	\N	Ridwan Royani, Manage by Nice Vendor	400
66	10.170.109.19	DB Server Q-Matic PRD	vidptwnpqmtap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani	400
70	10.170.216.196	DB Server WINPAKPRO PRD	sidpcwnpacdap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
72	10.170.48.235	DB Server(NewSolarWins DB) PRD	vidhopwinifrdb1	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
73	10.170.216.69	DB Server FXAW PRD	vidpcwnpawmap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
77	10.170.48.128	DB Server SOLARWIN_ORION PRD	vidhopwinswdap1	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
80	10.141.15.36	TLM TLM PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-11-29 16:10:01	\N	RDP\nuser : SRVPLAIPRTLMSMARTS01\nPassword : Q42PDxA(	400
82	10.143.34.42	One Pulse Platform onepulse PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	\N	400
84	10.143.34.206	smartclaim ( replica) smartclaim PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	\N	400
87	10.143.34.79	Renova (Cloud Instance) Renova_Individual PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2019 std edition	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-01-10 10:33:08	\N	user/pass: renovadb/5J+a]OlQ | user/pass: sqlserver/XpIeX_N&	400
89	10.143.27.253	jatisSMS (Cloud Instance)  PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016 std edition	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: sqlserver/Svu72BhZ	400
90	10.143.21.8	edoc (cloud_VM) edoc PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: edocplai/edoc2022	400
92	10.143.36.140	edoc (cloud_VM) edoc PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: edocplai/edoc2022	400
93	10.143.34.223	edoc (cloud_Instance) edoc PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: postgres/agG0nkLGOCphBdCwsUD5Cd1B8W0TmADT | user/pass: edocplai/IOSBQgiK6hOiEvu-	400
95	10.143.17.59	keycloack keycloack PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 13.13	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pas: postgres/d5iv2cp2t2LmRfIXECtypk1JBh71r7bl	400
100	10.143.34.70	PSA PRD	PSA	UBUNTU 10,22 GCP	Google Cloud	0	16	8	0	t	1	1	2	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	user/pas : postgres/bFAyEyz383ITMZ8MHImEfAnDzKZSTO74	400
101	10.143.34.101	PSA PRD	PSA	UBUNTU 10,22 GCP	Google Cloud	0	16	8	0	t	1	1	2	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	user/pas : postgres/xIqL6MHtPJWYA1OjaPaW4n9UM844LYdF	400
102	10.170.52.70	PRD	VIDHOWNPSFSAP04	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
106	10.170.48.109	PRD	VIDHOLXPBAKAP02	Red Hat  7.9  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
112	10.171.212.215	PRD	VIDDRWNDNRSDB01	Windows Server 2016	SQL Server 2016 express SP3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Uninstal SQLEXPRESS	400
131	10.170.49.136	DBA_USER DEV	VIDDRLXUGBQDB01	Red Hat  8.10  (RHEL)	Postgres 16.0	0	125GB	32	0	t	1	1	4	2024-10-10 00:00:00	2024-10-10 21:31:41	2024-10-10 21:31:41	\N	DEV NEW Postgres 16 | dba_user dba_user | 5432 | owner | Radit	400
158	10.171.84.73	VIDDCLXPGA PRD	VIDDCLXPGA	Red Hat Enterprise Linux 	Postgres 14.0	0	8	2	0	t	1	1	2	2025-02-06 00:00:00	2025-02-06 14:44:55	2025-02-06 14:44:55	\N	VIDDCLXPGA	400
94	10.143.34.226	OLTP DB  PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 13.13	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	oltp-svc/KT3meM@r-BdEBF1p	400
161	10.170.48.190	DCI CFS PRD	VIDHOWPCFSAP1	WINDOWS 2012 R2	Microsoft SQL Server 2012	0	8	4	0	t	1	1	1	2025-02-26 00:00:00	2025-02-26 15:31:15	2025-02-26 15:31:15	\N	Henry Lois Sumendap	400
56	10.171.84.43	RESDB DB2 PRD	VIDDCLXPODMDB01	Red Hat  7.9  (RHEL)	DB2 v10.5.0.3	0	31	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS  \n user SPLAIODM pass: Password09 di ip\n10.171.84.43 (BRMS)	400
53	10.171.84.104	BPM DB2 PRD	VIDDCLXPBPMDB01	Red Hat 6.10 (RHEL)	DB2 v10.5.0.3	0	58	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS\nkill locking db2 \n- db2top -d bpmdbphs (DB_Name)\n- tekan shift u\n- Klik a lalu ketik id yg mau di kill\n- db2 "force application(28866 contoh)"\ndb2 "force application(22948)"	400
146	10.171.84.154	ICN DB2 PRD	VIDDCLXPICNDB01	Red Hat (RHEL) 8.10	DB2 v11.5.8.0	0	7.5 GB	2	0	t	1	1	1	2024-11-05 10:00:00	2024-11-05 10:58:11	2024-11-05 10:58:11	\N	Afdoli Fahmi , MIS	400
150	10.143.34.85	newpruworks PRD	pruidlife-prod	CLOUD SQL  SVR	PostgreSQL 15.8	0	16	8	0	t	1	1	5	2024-11-19 00:00:00	2024-11-19 13:53:08	2024-11-19 14:30:32	\N	 "default_password": "\\u003cM?WuPtb",\n  "default_username": "pruuser", "root_password": "K2b\\u003ej1ly"	400
13	10.171.84.117	Magnum Pure PRD	VIDDCLXPMGPDB01	Red Hat  7.9  (RHEL)	(EnterpriseDB Advanced Server 9.6.2.7) 	0	16	16	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	571 GB	400
132	10.171.86.72	NBWF UAT	SR02701142	Red Hat  7.9  (RHEL)	(EnterpriseDB Advanced Server 14.13.1)	0	16	8	0	t	1	1	4	2024-10-12 00:00:00	2024-10-12 16:31:46	2024-10-12 16:31:46	\N	SR02701142	400
135	10.171.211.123	DR GP	SIDDCLXPGPNAP01	Red Hat 6.10 (RHEL)	Greenplum Node 1	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
136	10.171.211.124	DR GP	SIDDCLXPGPNAP02	Red Hat 6.10 (RHEL)	Greenplum Node 2	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
137	10.171.211.125	DR GP	SIDDCLXPGPNAP03	Red Hat 6.10 (RHEL)	Greenplum Node 3	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
138	10.171.211.126	DR GP	SIDDCLXPGPNAP04	Red Hat 6.10 (RHEL)	Greenplum Node 4	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
139	10.171.211.127	DR GP	SIDDCLXPGPNAP05	Red Hat 6.10 (RHEL)	Greenplum Node 5	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
140	10.171.211.128	DR GP	SIDDCLXPGPNAP06	Red Hat 6.10 (RHEL)	Greenplum Node 6	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
124	10.170.49.217	NPRD	vidhownuefmap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-04-22 16:24:12	\N	AJI  E-FORM-APPS\n.\\sqlagtsvcdev  -> Password09	400
107	10.171.84.78	NPRD	VIDHOLXGBQMAP01	Red Hat  7.9  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2025-03-20 08:53:44	\N	Upgrade Postgres v.8.3 to 14.3	400
162	10.143.34.234	MAGNUMEPURE PRD GKE	GKEMAGNUMEPURE	Debian clang version 12.0	PostgreSQL 15.12 	0	64	16	0	t	1	1	1	2025-03-10 00:00:00	2025-03-17 10:56:10	2025-03-20 10:38:39	\N	 "default_password": "ikGIgklikmFjNxWf0hVq4oNVZNXlWlVB",\n  "default_username": "postgres",	400
122	10.170.49.210	NPRD	vidhodwinintdb7	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Dev Moveit	400
120	10.170.49.196	NPRD	vidhownupacdb01	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Finger Print	400
59	10.170.49.144	UAT	vidhownuinsdb01	Windows Server 2012 R2	Oracle Database 11g Enterprise Edition	0	31	8	0	t	1	1	3	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-18 18:00:58	\N	Afdoli Fahmi , MIS\n.\\sqlagtsvcdev\nPassword09	400
98	10.141.48.131	STAGGING REMOTE SQL NRPD	service db cloud	Windows Server 2016 GCP	Client Cloud Remote Server	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	\N	400
145	10.170.49.168	ON PREM ESUB NEWODS AOB UAT	VIDHOLXUINTDB02	Red Hat  7.9  (RHEL)	PostgreSQL 10.4	0	15	8	0	t	1	1	4	2024-10-23 00:00:00	2024-10-23 10:43:56	2024-10-30 10:35:00	\N	GRANT SELECT ON ALL TABLES IN SCHEMA pd_activity_management TO "mis-read";\nGRANT SELECT ON pd_activity_management.reasons TO  "mis-read";\nGRANT USAGE ON SCHEMA pd_activity_management TO "mis-read";\n\n\n	400
2	10.170.53.103	AOB EPOLICY DB (WAB,Fuse)  PRD	VIDDCLXPAOBDB04	Red Hat  7.9  (RHEL)	EnterpriseDB 14.13.1	0	46	20	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-05 09:56:15	\N	200 GB DISK --- ada versi 14 UP	400
49	10.171.84.125	GreenPlum Node 3 PRD	SIDDRLXPGPNAP03 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	0	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
83	10.143.17.6	smartclaim smartclaim PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	\N	400
91	10.143.17.29	edoc (cloud_Instance) edoc PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	user/pass: postgres/o1Gy1WbqQ3DZcTt4hyVGzkCzEHnFEKxb | user/pass:edocplai/U0Y42h8mngzu-D8@	400
85	10.143.34.202	smartclaim ( master) smartclaim PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-03-13 09:58:30	\N	"password": "nl!rWHX@vSojmUbn",\n"username": "op-svc"\n\n"password": "rh1mTEj!U23pd6$5",\n  "username": "dba-user"\n\n"password": "rp@o73p6-knfv$lC",\n "username": "release-user"	400
163	10.143.34.36	mitracommadm-stagging PRD	IDLIFED4VZP1CVI-1a1636b9	CLOUD SQL UBUNTU 20	Microsoft SQL Server 2019	0	10	4	0	t	1	1	1	2025-03-20 00:00:00	2025-03-20 10:17:03	2025-03-20 10:42:06	\N	    "default_password":"D<1n=j}K",\n    "default_username":"mitracommadm",\n    "root" d6fs4NeX"	400
88	10.141.23.9	Ifrs17 (cloud_VM) ifrs17 PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2016 std edition	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-03-24 14:08:55	\N	user/pass: sa/Password09 |  apref: c5wvjk	400
125	10.170.49.78	NPRD	sidhouwinepvdb1	Windows Server 2016	SQL Server 2016 SP 3	1	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-03-25 17:39:00	\N	111	400
35	10.170.53.187	New Actuary DB PRD	VIDHOWNPPRPDB01	Windows Server 2016	SQL Server 2016	0	64	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-03-27 08:19:59	\N	Salman Farizi \n260325->addcpu 2	400
22	10.170.48.177	Database Solarwind, scom, SCCM PRD	SIDHOPWINIFRDB1	Windows Server 2016	SQL Server 2016	0	16	3	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-03-27 11:54:30	\N	Afdoli Fahmi , mis_user\nSQLAGTSVCPROD Password09	400
16	10.170.53.108	Base DB PRD	VIDDCLXPBSEDB06	Red Hat 8.10 (RHEL)	PostgreSQL 14.12	0	62	8	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-14 14:10:21	\N	59 GB	400
14	10.170.53.200	Corespondence DB PRD	VIDDCLXPCDSDB01	Red Hat (RHEL) 7.9	PostgreSQL 14.12	0	31	4	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-15 10:30:32	\N	443 GB	400
141	10.170.49.179	DR GP	VIDHOLXDGPMAP02 	Red Hat 7.10 (RHEL)	Greenplum Node 4.3.33	0	62	24	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2025-04-17 17:08:26	\N	Arif Rahman  - Postgres + greenplum padmin password_09 root today123	400
164	10.171.211.16	DB2 - DEV	PRUIDWFCM02	AIX 2	DB2 AIX	0	8	8	0	t	1	1	2	2025-04-25 00:00:00	2025-04-25 11:18:31	2025-04-25 14:22:08	\N	   test	400
97	10.143.34.5 	DB SCRM PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2022	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-04-25 15:31:30	\N	1433  sqlserver/ua}T&-9[  simplecrm	400
165	10.143.17.197	Cloud	apidb_uat	linux debian 12	PostgreSQL 13.20	0	16	8	0	t	1	1	4	2025-04-28 00:00:00	2025-04-28 14:58:13	2025-04-28 14:58:13	\N	{\n\t\t"password":"JqoNbmc/hgQud4wP",\n\t\t"username":"dev-svc"\n\t}\npostgres/Ku6u6mpGsBplAeyeiiG28P8J3gDUk63o	400
54	10.170.53.150	HPX DB2  PRD	VIDHOLXPHPEDB01	Red Hat  8.10  (RHEL)	DB2 v10.5.0.3	0	15	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-29 14:30:39	\N	Afdoli Fahmi , MIS, HPXDE	400
18	10.170.53.147	Consolidate Database Server(XML) PRD	VIDHOWNPINTDB01	Windows Server 2016	SQL Server 2016	0	44	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-30 16:40:07	\N	Afdoli Fahmi \nowner Nanda widy	400
15	10.171.84.92	Postgre Enablement Tribe COMPLIANCE PRD	VIDDCLXPENTDB01	Red Hat 8.10 (RHEL)	PostgreSQL 14.12	0	15	4	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-05-05 08:38:54	\N	10 GB	400
168	10.170.53.132	PROD	vidholxpodsdb02	Red Hat 8.10 (RHEL)	EDB 14.12	0	168	26	0	t	1	1	1	2025-04-30 00:00:00	2025-04-30 14:56:44	2025-05-06 13:29:11	\N	padmin	400
169	10.143.17.193	PROD misdb	10.143.17.193	Red Hat Enterprise Linux 	Postgres 16.0	0	16	8	0	t	1	\N	2	2025-05-09 00:00:00	2025-05-09 14:13:17	2025-05-09 14:20:21	\N	"username":"dev-svc"\n"password":"n@WXnqZHwNZg7/td"\n"username":"dev-user"\n"password":"/vSwLnEYYDul8P!G"\n"password":"nog1-ePSZ/vgrL7-","username":"dev-ro"	\N
170	10.143.34.237	PROD	pruhub3	CLOUD SQL	PostgreSQL 9	0	16	8	0	t	1	1	1	2025-05-14 00:00:00	2025-05-14 09:13:32	2025-05-14 09:14:35	\N	[{"password":"v1CtdwHkyX@7RYi8","username":"dba_user"},\n{"password":"9TKYrP$8kU15Ny-O","username":"pruhub_user"},\n{"password":"N/TdoFP@ey0nwRWP","username":"service_user"}]	\N
\.


--
-- Data for Name: hardware_2; Type: TABLE DATA; Schema: public; Owner: mis_user
--

COPY public.hardware_2 (id, make, model, serial, os_name, os_version, type, ram, cpu, status, current, company_id, user_id, provaider_id, purchased_at, created_at, updated_at, deleted_at, note, max_con) FROM stdin;
3	10.170.53.29	BPM DB PRD	VIDHOPLINBPMDB1	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	64	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	148 GB	400
4	10.171.140.16	Payment Database PRD	VIDDCLXPNPHDB01-New	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	32	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	688 GB	400
5	10.170.53.56	Database Leads PRD	VIDDCLXPAOBDB05	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	31	36	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-28 10:44:23	\N	109 GB	400
6	10.170.53.57	Training PRD	VIDDCLXPAOBDB06	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	32	10	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-10-20 04:04:31	\N	109 GB	400
7	10.170.53.131	New ODS - PROD	VIDHOLXPODSDB01	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.5.10	0	160	16	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	997 GB	400
8	10.170.53.23	PRUForce DB PRD	VIDHOPLINAOBDB1	Red Hat 6.10 (RHEL)	(EnterpriseDB Advanced Server 14.13.1)	0	171	20	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-01-06 11:44:20	\N	1400 GB	400
9	10.171.84.55	SME omni PRD	VIDDCLXPSMEDB01	Red Hat 6.10 (RHEL)	PostgreSQL 14.13	0	31	24	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-03-20 11:29:37	\N	79 GB	400
10	10.171.84.56	SME Pruworks PRD	VIDDCLXPSMEDB02	Red Hat 6.10 (RHEL)	PostgreSQL 14.12	0	23G	20	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-10-19 20:05:17	\N	217 GB	400
11	10.171.84.68	SME DB PRD	VIDDCLXPSMEDB04-new	Red Hat 6.10 (RHEL)	PostgreSQL 10.7 	0	19	6	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	 GB	400
12	10.170.53.101	nbwf,  DB Workflow PRD	VIDDCLXPAOBDB02	Red Hat  7.9  (RHEL)	(EnterpriseDB Advanced Server 14.13.1)	0	50	28	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-28 10:24:26	\N	892 GB	400
13	10.171.84.117	Magnum Pure PRD	VIDDCLXPMGPDB01	Red Hat  7.9  (RHEL)	(EnterpriseDB Advanced Server 9.6.2.7) 	0	16	16	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	571 GB	400
14	10.170.53.200	Corespondence DB PRD	VIDDCLXPCDSDB01	Red Hat (RHEL) 7.9	PostgreSQL 14.12	0	31	4	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-15 10:30:32	\N	443 GB	400
15	10.171.84.92	Postgre Enablement Tribe COMPLIANCE PRD	VIDDCLXPENTDB01	Red Hat 8.10 (RHEL)	PostgreSQL 14.12	0	15	4	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-05-05 08:38:54	\N	10 GB	400
16	10.170.53.108	Base DB PRD	VIDDCLXPBSEDB06	Red Hat 8.10 (RHEL)	PostgreSQL 14.12	0	62	8	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-14 14:10:21	\N	59 GB	400
17	10.171.84.100	AI DB PRD	VIDDCLXPAICDB01	Red Hat 6.10 (RHEL)	PostgreSQL 10.4	0	32	4	0	t	1	1	4	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	197 GB	400
18	10.170.53.147	Consolidate Database Server(XML) PRD	VIDHOWNPINTDB01	Windows Server 2016	SQL Server 2016	0	44	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-30 16:40:07	\N	Afdoli Fahmi \nowner Nanda widy	400
19	10.170.53.106	ODS PRD IDNPLAODSDB	VIDHOWNPODSDB01	Windows Server 2016	SQL Server 2016	0	64	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-07-17 16:57:15	\N	Afdoli Fahmi  IDNPLAODSDB	400
20	10.170.53.36	Internal DB (Moveit) PRD	VIDHOWNPINTDB02	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-14 10:30:13	\N	Afdoli Fahmi -- > moveitdmz Password09	400
21	10.170.48.98	Reporting DB SRSS PRD	VIDHOWNPREPDB01	Windows Server 2016	SQL Server 2016	0	32	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 	400
22	10.170.48.177	Database Solarwind, scom, SCCM PRD	SIDHOPWINIFRDB1	Windows Server 2016	SQL Server 2016	0	16	3	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-03-27 11:54:30	\N	Afdoli Fahmi , mis_user\nSQLAGTSVCPROD Password09	400
23	10.170.48.58	Internal DB - 03 PRD	VIDHOWNPINTDB03	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 	400
24	10.170.48.211	NICE DB PRD	VIDHOWNPNDSDB01	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani	400
25	10.170.48.44	NICE DB PRD	VIDHOWNPNDSDB02	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani	400
26	10.170.48.186	Ops Dashboard DB PRD	VIDHOWNPOPSDB01	Windows Server 2016	SQL Server 2016	0	8	2	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 	400
27	10.170.48.85	GPP Report PRD	SIDHOPWINMDB01	Windows Server 2016	SQL Server 2016	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-07-02 10:08:54	\N	Afdoli Fahmi GPP	400
28	10.170.48.112	Customer Analytic PRD	SIDHOPWINDALDB1	Windows Server 2016	SQL Server 2019	0	48	3	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-28 10:03:49	\N	Afdoli Fahmi \nHani Asri Guardiani	400
29	10.170.53.46	CRM Archive PRD	VIDHOWNPCRMDB03	Windows Server 2016	SQL Server 2016	0	24	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Victor Liliwidjaja	400
30	10.170.48.84	Reinsurance DB PRD	VIDHOWNPREIDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Fikrilsyah Algoumar	400
31	10.170.48.77	E-Submission NB PRD	VIDHOWNPXARDB01	Windows Server 2016	SQL Server 2016	0	8	2	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-10 11:13:44	\N	Nanda Widy	400
32	10.170.48.122	Sharepoint DB PRD	SIDHOPWINSHPDB1	Windows Server 2016	SQL Server 2016	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-27 11:54:03	\N	Syofianer Fitra	400
34	10.170.53.91	SUN GL PRD	SIDHOPWINSUNDB1	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Syofianer Fitra	400
35	10.170.53.187	New Actuary DB PRD	VIDHOWNPPRPDB01	Windows Server 2016	SQL Server 2016	0	64	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-03-27 08:19:59	\N	Salman Farizi \n260325->addcpu 2	400
36	10.170.53.68	CRM PRD	VIDHOWNPCRMDB02	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Victor Liliwidjaja	400
37	10.170.53.44	CRM PRD	VIDHOWNPCRMDB01	Windows Server 2016	SQL Server 2016	0	39	12	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Victor Liliwidjaja	400
38	10.170.53.105	DataMart PRD	VIDHOWNPDTMDB01	Windows Server 2019	SQL Server 2016	0	32	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-05-28 16:46:00	\N	Fikrilsyah Algoumar	400
39	 10.170.53.49	PG BCA PRD	VIDHOWNPH2BDB01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Bhimo Bhaskoro	400
40	10.170.53.153	OCR DB PRD	VIDDCWNPOCRDB01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Juliana	400
41	10.170.53.5	EPOS DB PRD	VIDHOPWINPOSDB1	Windows Server 2016	SQL Server 2016	0	32	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi 	400
42	10.171.84.205	New IFRS  PRD	VIDDRWNPIFRDB01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Mimi Winata	400
43	10.171.84.215	Power BI PRD	VIDDCWNPPBIAP01	Windows Server 2016	SQL Server 2016	0	96	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Rizky Karunia	400
44	10.171.84.70	GreenPlum Master PRD	SIDDRLXPGPMAP01 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2025-08-05 13:58:34	\N	Afdoli Fahmi , MIS\n/GPDB_DATA/master/gpseg-1/	400
45	10.171.84.71 	GreenPlum Second Master PRD	SIDDRLXPGPSAP01	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
46	10.171.84.123	GreenPlum Node 1 PRD	SIDDRLXPGPNAP01	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
47	10.171.84.124	GreenPlum Node 2 PRD	SIDDRLXPGPNAP02	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
48	10.171.84.125	GreenPlum Node 3 PRD	SIDDRLXPGPNAP03 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
49	10.171.84.126	GreenPlum Node 4 PRD	SIDDRLXPGPNAP04 	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
50	10.171.84.128 	GreenPlum Node 5 PRD	SIDDRLXPGPNAP05	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
51	10.171.84.129	GreenPlum Node 6 PRD	SIDDRLXPGPNAP06	Red Hat 6.10 (RHEL)	Greenplum Database 4.3.33	0	252	32	8	t	1	1	1	2024-07-01 08:00:00	2024-07-01 08:00:00	2024-07-01 08:00:00	\N	Afdoli Fahmi , MIS	400
52	10.171.84.104	BPM DB2 PRD	VIDDCLXPBPMDB01	Red Hat 6.10 (RHEL)	DB2 v10.5.0.3	0	58	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS\nkill locking db2  	400
53	10.170.53.150	HPX DB2  PRD	VIDHOLXPHPEDB01	Red Hat  8.10  (RHEL)	DB2 v10.5.0.3	0	15	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-04-29 14:30:39	\N	Afdoli Fahmi , MIS, HPXDE	400
54	10.170.53.99	CM DB2 PRD	PRUIDWFCM02	AIX 7	DB2 v10.5.0.8	0	42	3	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS \nkill locking db2  	400
56	10.170.53.14	MFPDATA DB2 PRD	VIDHOPLINIMFDB1	Red Hat (RHEL) 8.10	DB2 v11.5.8.0	0	62	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-05 10:52:32	\N	Afdoli Fahmi , MIS	400
57	10.171.82.73	UAT	sidhopwinvnxap1	Red Hat 6.10 (RHEL)	MySQL Database Server	0	31	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS	400
58	10.170.49.144	UAT	vidhownuinsdb01	Windows Server 2012 R2	Oracle Database 11g Enterprise Edition	0	31	8	0	t	1	1	3	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-11-18 18:00:58	\N	Afdoli Fahmi , MIS\n.\\sqlagtsvcdev\nPassword09	400
59	10.170.49.107	UAT	viddrlxdatsap01	Red Hat 6.10 (RHEL)	Oracle Database 11g Enterprise Edition	0	31	8	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS	400
60	10.171.83.52	DB Server SCCM Server PRD	viddcwnpscmap02	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Abdul Qahar	400
61	10.170.53.198	DB Server iCare & IVRDB PRD	vidhowpivrdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
62	10.170.48.37	DB Nice Server Playback Portal PRD	vidhownpnpsdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-02 15:35:03	\N	Ridwan Royani	400
63	10.170.48.101	DB Server New AWMS Server (Tower) PRD	viddcwnpawmap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-07-30 12:03:48	\N	Abdul Qahar MSSQL$FXAW mis_user	400
65	10.170.109.19	DB Server Q-Matic PRD	vidptwnpqmtap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani	400
66	10.170.53.199	DB Server iCare & IVRDB PRD	viddrwpivrdb01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-06-19 14:56:10	\N	mis_user Password09	400
67	10.170.53.186	Is not DB Server PRD	vidhownpprpap02	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
68	10.170.48.63	Is not DB Server PRD	sidhopwinscmap1	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Taufik Ridwan	400
69	10.170.216.196	DB Server WINPAKPRO PRD	sidpcwnpacdap01	Windows Server 2016	SQL Server 2016	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-07-16 17:51:06	\N	Fingerprint Tower	400
70	10.171.210.50	NICE Engage Unified PRD	siddrwnpneuap01	Windows Server 2016	no db	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-02 15:33:59	\N	Ridwan Royani	400
71	10.170.48.235	DB Server(NewSolarWins DB) PRD	vidhopwinifrdb1	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
72	10.170.216.69	DB Server FXAW PRD	vidpcwnpawmap01	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
73	10.170.53.185	Is not DB Server New Actuary Apps PRD	vidhownpprpap01	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Daniel Agustinus Rahardjo / Salman Farizi 	400
74	10.170.48.102	Decommissioning PRD	vidhownpintdb07	Windows Server 2016	SQL Server 2012	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	unknow	400
75	10.170.48.33	Decommissioning NICE  PRD	vidhownpndsdb03	Windows Server 2016	SQL Server 2012	0	16	8	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Ridwan Royani	400
76	10.170.48.128	DB Server SOLARWIN_ORION PRD	vidhopwinswdap1	Windows Server 2016	SQL EXPRESS 2017	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-07-22 14:12:49	\N	unknow	400
77	10.171.140.90	Is not DB Server ( No DB Service) PRD	viddcwnppbhap01	Windows Server 2016	no db	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Arif Hidayat Husni	400
82	10.143.17.6	smartclaim smartclaim PRD	service db cloud	UBUNTU 10,22 GCP	PostgreSQL 12.16	0	16	8	0	t	1	1	4	2024-05-01 08:00:00	2024-05-01 08:00:00	2024-05-01 08:00:00	\N	\N	400
96	10.143.34.5 	DB SCRM PRD	service db cloud	UBUNTU 10,22 GCP	SQL Server 2022	0	16	8	0	t	1	1	2	2024-05-01 08:00:00	2024-05-01 08:00:00	2025-04-25 15:31:30	\N	1433  sqlserver/ua}T&-9[  simplecrm	400
97	10.141.48.131	STAGGING REMOTE SQL NRPD	service db cloud	Windows Server 2016 GCP	Client Cloud Remote Server	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	\N	400
101	10.170.52.70	PRD	VIDHOWNPSFSAP04	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
102	10.170.52.28	NPRD	WINTEL	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
104	10.170.48.110	NPRD	VIDHOLXPBAKAP01	Red Hat  8.10  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
105	10.170.48.109	PRD	VIDHOLXPBAKAP02	Red Hat  7.9  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
106	10.171.84.78	NPRD	VIDHOLXGBQMAP01	Red Hat  7.9  (RHEL)	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2025-03-20 08:53:44	\N	Upgrade Postgres v.8.3 to 14.3	400
107	10.171.213.79	NPRD	VIDDRLXUSMEAP04	Red Hat  8.1 (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.10 to 14.3	400
108	10.170.49.150	NPRD	SIDHODLINFUSDB1	Red Hat  8.1  (RHEL)	PostgreSQL 15.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2025-08-03 10:13:45	\N	Postgres v.10 to 14.3 | fuse DB  pruasia\\sqlagtsvcdev\nPassword09	400
109	10.170.49.191	NPRD	vidholdodsdb1	Red Hat  7.9  (RHEL)	PostgreSQL 14.13	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-12-13 09:41:05	\N	Upgrade Postgres v.10 to 14.3 pruasia\\sqlagtsvcdev\nPassword09	400
110	10.171.212.215	PRD	VIDDRWNDNRSDB01	Windows Server 2016	SQL Server 2016 express SP3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Uninstal SQLEXPRESS	400
111	10.171.210.25	NPRD	VIDDRWNPCCVAP01	Windows Server 2016	SQL Server 2016 express SP3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Uninstal SQLEXPRESS	400
112	10.171.212.142	NPRD	viddcwndhpxap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N	400
113	10.170.49.11	NPRD	VIDHOWNUPDCAP01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-06-11 13:53:48	\N	SQLAGTSVCDEV  Password09	400
114	10.170.49.123	NPRD	SIDHOUWINSAPDB2	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-11-11 13:43:00	\N	PRUASIA\\sqlagtsvcdev\nPassword09	400
115	10.170.49.188	NPRD	vidhodwinintdb1	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N	400
117	10.170.49.196	NPRD	vidhownupacdb01	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Finger Print	400
118	10.170.49.197	NPRD	vidhowndeprap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-03-25 17:39:18	\N	11	400
119	10.170.49.210	NPRD	vidhodwinintdb7	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Dev Moveit	400
120	10.170.49.216	NPRD	sidhouwinepvap1	Windows Server 2016	SQL Server 2016 SP 3	0	16,200	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-05-04 16:18:45	\N	123	400
121	10.170.49.217	NPRD	vidhownuefmap01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-04-22 16:24:12	\N	AJI  E-FORM-APPS\n.\\sqlagtsvcdev  -> Password09	400
122	10.170.49.78	NPRD	sidhouwinepvdb1	Windows Server 2016	SQL Server 2016 SP 3	1	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-03-25 17:39:00	\N	111	400
123	10.170.49.80	UAT	SIDHOUWINSFTP01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2025-01-28 10:02:30	\N	Hanan	400
124	10.170.49.81 	NPRD	sidhodwinepvdb1	Windows Server 2012 R2 	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	e-Payment Voucher	400
125	10.170.49.88 	NPRD	VIDHOWNUINTDB01	Windows Server 2019	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N	400
126	10.170.216.100	PRD	SIDHOWNPCCVAP01	Windows Server 2012 R2	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Upgrade to 2016 SP 3	400
127	10.170.53.61	PRD	vidhownpcrmap03	Windows Server 2019 STD	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	Microsoft SQL Server 2008 R2 	400
128	10.170.49.136	DBA_USER DEV	VIDDRLXUGBQDB01	Red Hat  8.10  (RHEL)	Postgres 16.0	0	125GB	32	0	t	1	1	4	2024-10-10 00:00:00	2024-10-10 21:31:41	2024-10-10 21:31:41	\N	DEV NEW Postgres 16 | dba_user dba_user | 5432 | owner | Radit	400
129	10.171.86.72	NBWF UAT	VIDDRLXUMSCDB01	Red Hat  7.9  (RHEL)	(EnterpriseDB Advanced Server 14.13.1)	0	15	8	0	t	1	1	4	2024-10-12 00:00:00	2024-10-12 16:31:46	2025-08-05 13:53:56	\N	SR02701142	400
130	10.171.211.50	DR GP	SIDDCLXPGPMAP01	Red Hat 6.10 (RHEL)	Greenplum Node Master	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
131	10.171.211.51	DR GP	SIDDCLXPGPSAP01	Red Hat 6.10 (RHEL)	Greenplum Node Standby	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
132	10.171.211.123	DR GP	SIDDCLXPGPNAP01	Red Hat 6.10 (RHEL)	Greenplum Node 1	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
133	10.171.211.124	DR GP	SIDDCLXPGPNAP02	Red Hat 6.10 (RHEL)	Greenplum Node 2	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
134	10.171.211.125	DR GP	SIDDCLXPGPNAP03	Red Hat 6.10 (RHEL)	Greenplum Node 3	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
135	10.171.211.126	DR GP	SIDDCLXPGPNAP04	Red Hat 6.10 (RHEL)	Greenplum Node 4	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
136	10.171.211.127	DR GP	SIDDCLXPGPNAP05	Red Hat 6.10 (RHEL)	Greenplum Node 5	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
137	10.171.211.128	DR GP	SIDDCLXPGPNAP06	Red Hat 6.10 (RHEL)	Greenplum Node 6	0	252	8	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2024-02-01 08:00:00	\N	Afdoli Fahmi	400
138	10.170.49.179	DR GP	VIDHOLXDGPMAP02 	Red Hat 8.10 (RHEL)	Postgres 16.0	0	62	24	0	t	1	1	2	2024-02-01 08:00:00	2024-02-01 08:00:00	2025-07-02 14:21:44	\N	Arif Rahman  - Postgres + mis_user padmin password_09 root today123	400
139	10.170.49.180	GP DEV	VIDHOLXDGPNAP03	Red Hat Enterprise Linux 	Greenplum Node 4.3.33	0	62G	24	0	t	1	1	4	2024-10-22 00:00:00	2024-10-22 18:35:26	2024-10-22 20:21:47	\N	VIDHOLXDGPNAP03	400
140	10.170.49.181	GP DEV	VIDHOLXDGPNAP04	Red Hat Enterprise Linux 	Greenplum Node 4.3.33	0	62G	24	0	t	1	1	4	2024-10-22 00:00:00	2024-10-22 20:11:06	2024-10-22 20:22:04	\N	VIDHOLXDGPNAP04	400
141	10.170.49. 	DBA_USER DEV	VID	Red Hat Enterprise Linux 	(EnterpriseDB Advanced Server 14.13.1)	0	62G	24	0	t	1	1	4	2024-10-22 00:00:00	2024-10-22 20:18:04	2024-10-23 07:15:51	\N	10.170.49.180	400
142	10.170.49.168	ON PREM ESUB NEWODS AOB UAT	VIDHOLXUINTDB02	Red Hat  8.1  (RHEL)	PostgreSQL 15.13	0	15	8	0	t	1	1	4	2024-10-23 00:00:00	2024-10-23 10:43:56	2025-08-03 10:13:15	\N	 	400
143	10.171.84.154	ICN DB2 PRD	VIDDCLXPICNDB01	Red Hat (RHEL) 8.10	DB2 v11.5.8.0	0	7.5 GB	2	0	t	1	1	1	2024-11-05 10:00:00	2024-11-05 10:58:11	2024-11-05 10:58:11	\N	Afdoli Fahmi , MIS	400
145	10.170.53.202	TRIAL DB SQL SERVER	TRIAL	WINDOWS 2012 R2	SQL Server 2022	0	16	8	9	t	1	1	5	2024-11-13 00:00:00	2024-11-13 07:52:19	2024-11-13 07:52:27	\N	10.170.53.202\n.\\admintemp\nPassword09	400
148	10.143.27.236	Cloud INTUATDB PRD	IDLIFED4VZP1CVI	Ubuntu 20	SQL Server 2019	0	6	2	0	t	1	10	1	2024-12-17 10:00:00	2024-12-17 16:00:37	2025-02-06 09:45:15	\N	    "private_address": "10.143.27.236",\n    "root_password": "+}CGp[@-"\n}\nuser sqlserver	400
149	10.170.109.42	Server Recording ACRA  PRD	VIDPTWNPACRAP01	Windows Server 2016	SQL Server 2016	0	16	4	0	t	1	1	1	2025-01-14 00:00:00	2025-01-14 09:07:24	2025-01-14 09:07:37	\N	Login : VIDPTWNPACRAP01\\pruadmin\nPassword : P@ssw0rd\nVIDPTWNPACRAP01	400
151	10.171.84.73	VIDDCLXPGA PRD	VIDDCLXPGA	Red Hat Enterprise Linux 	Postgres 14.0	0	8	2	0	t	1	1	2	2025-02-06 00:00:00	2025-02-06 14:44:55	2025-02-06 14:44:55	\N	VIDDCLXPGA	400
152	10.170.53.78	ORACLE PRD	VIDHOWNPINSDB01	WINDOWS 2012 R2	Oracle 11g Windows	0	32	8	0	t	1	1	3	2025-02-21 00:00:00	2025-02-21 15:02:20	2025-02-21 15:02:20	\N	CREATE USER mis_user IDENTIFIED BY Password09;	400
153	10.170.48.190	DCI CFS PRD	VIDHOWPCFSAP1	WINDOWS 2012 R2	Microsoft SQL Server 2012	0	8	4	0	t	1	1	1	2025-02-26 00:00:00	2025-02-26 15:31:15	2025-02-26 15:31:15	\N	Henry Lois Sumendap	400
156	10.171.211.16	DB2 - DEV	PRUIDWFCM02	AIX 2	DB2 AIX	0	8	8	0	t	1	1	2	2025-04-25 00:00:00	2025-04-25 11:18:31	2025-04-25 14:22:08	\N	   test	400
158	10.170.53.132	PROD	vidholxpodsdb02	Red Hat 8.10 (RHEL)	EDB 14.12	0	168	26	0	t	1	1	1	2025-04-30 00:00:00	2025-04-30 14:56:44	2025-05-06 13:29:11	\N	padmin	400
161	10.143.17.22	DEV DBA_USERx	10.143.17.22	CLOUD SQL	Postgres 9.0	0	16	8	0	t	1	1	2	2025-05-21 00:00:00	2025-05-21 14:02:27	2025-05-21 14:02:27	\N	pw: lAb43za16dHCMWbTpOFqV3tNJXi449rL\nu: postgres	400
164	10.170.52.68	SHARE PROD	10.170.52.68	WINDOWS 2016	Postgres 8.3	0	24	8	0	t	1	1	1	2025-05-27 00:00:00	2025-05-27 14:35:12	2025-05-27 14:38:46	\N	IPS_Prundetial	400
165	10.170.52.70	SHARE PROD	10.170.52.70	WINDOWS 2012	Postgres 15.13	0	8	8	0	t	1	1	1	2025-05-27 00:00:00	2025-05-27 14:37:44	2025-05-28 16:48:19	\N	88	400
166	10.143.17.10	REDSOFT	INVESTMEN	CLOUD SQL	Microsoft SQL Server 2019	0	16	8	0	t	1	1	1	2025-06-03 00:00:00	2025-06-03 15:19:47	2025-06-03 15:19:47	\N	IP : 10.143.17.10\nUsername : sqlserver\nPassword : ceJym<Le	400
167	10.170.49.251	NRPD	VIDHOLXUINTDB01	Red Hat 7 (Rhell)	PostgreSQL 14.12	0	15	8	0	t	1	1	2	2025-06-17 00:00:00	2025-06-17 11:37:25	2025-06-17 11:37:25	\N	10.170.49.251	400
168	10.170.49.211	DEV NRPOD	VIDHOWNUSFSAP02	Windows Server 2016	PostgreSQL 16.9	0	16	4	0	t	1	1	1	2025-06-23 00:00:00	2025-06-23 15:39:00	2025-07-03 09:25:06	\N	PostgreSQL 16.9\nPRUASIA\\SQLAGTSVCDEV  \nJ4k@rta21	400
169	10.143.17.96	pruhub3-a2202659	c5fzh0	asia-southeast2	POSTGRES_9_6	0	38	1	0	t	1	1	4	2025-07-02 00:00:00	2025-07-02 13:28:37	2025-07-02 14:38:47	\N	    "default_password": "UQTjnEpIOucHfEKaHHA8fDE2578DiXCu",\n    "default_username": "postgres",	400
170	10.171.84.145	clone 92	VIDDCLXPENTDB01T	Red Hat 8.10 (RHEL)	Postgres 15.0	0	19	4	0	t	1	1	1	2025-07-16 00:00:00	2025-07-16 16:51:47	2025-07-16 16:51:47	\N	padmin/Password09 root/today123	400
171	10.143.34.54	PROD fhsl34 pmnwf-new2-6a194f8d	nbwf	CLOUD	PostgreSQL 9.6.24 	PMN DB	12	24	0	t	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Nanda Widi {"password":"4AOT1weD-2-uEotf","username":"nbwf-svc"} 	400
172	10.143.34.5	PROD pxz32v crm-prod-4d1f4c46	CRM	CLOUD ubuntu linux 20.04 LTS	SQLSERVER 2022 STD	SCRM	32	32	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Salman Farizi user/pas : sqlserver/ua}T&-9[ 	400
173	10.143.27.253	UAT w89lzu jatisdev-c9a15088	jatisSMS (Cloud Instance)	CLOUD (Cloud Instance)	SQLSERVER 2019 ENTERPRISE	jatisSMS (Cloud Instance)	4	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Aji user/pass: sqlserver/Svu72BhZ 	400
174	10.143.34.237	PROD s16gul pruhub3-168cfd2c	pruhub	CLOUD	PostgreSQL 9.6.24	pruhub	4	8	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	 password:"v1CtdwHkyX@7RYi8","username":"dba_user" / default_username":"PostgreSQL " "default_password":"BfvuoYlNmX0XRDY4hPHyCh2bTzE244Do" 	400
175	10.143.17.91	UAT ss5reu pmnwf-new-1b3665f1	pmnwf	CLOUD	PostgreSQL 9.6.24	PMN DB	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Fajar Tri nbwf-svc/Yosm@fY$EcZeF6WE 	400
176	10.143.17.92	UAT lo943j viddrlxddgpap01db-new-d5f22d10	\N	Red Hat Enterprise Linux 	PostgreSQL 16.9 	\N	4	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	viddrlxddgpap01db-new-d5f22d10 "default_password": "15d78c3d849493ee",\n "default_username": "digitalpg",	400
177	10.143.17.17	DEV tylzpr mis-api-bc543eee	mis-api	CLOUD	PostgreSQL 16.8 	mis-api	4	8	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	 PostgreSQL /mKvfzOHMGKiZ6uvH7g5qd8EP3Nyrtwfb 	400
178	10.143.17.16	DEV tylzpr mis-newods-37aa20f8	mis-newods	CLOUD	PostgreSQL 16.8 	mis-newods	4	6	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	 PostgreSQL /9QLP2ubRW6FENboO0H7arWr5vq91GJ1S 	400
179	10.143.34.234	PROD q6ec67 magnumpuredb-08fea2c0	magnumpure	CLOUD	PostgreSQL 15.10 	MagnumPure	16	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Odianto user/pas : PostgreSQL /ikGIgklikmFjNxWf0hVq4oNVZNXlWlVB 	400
180	10.143.17.126	UAT wyaxkx magnumpuredb-f1c22de1	magnumpure	CLOUD	PostgreSQL 15.10 	MagnumPure	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Odianto PostgreSQL /baf78c6b70be36ee  ALTER USER prumagnumpure WITH PASSWORD 'cNA4-K/C2VZ3Wh!!';\n5432	400
181	10.143.34.101	PROD m6amcz pap-f0099a49	PAP	CLOUD	PostgreSQL 14.12 	PAP	4	6	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Marantika user/pas : postgres/xIqL6MHtPJWYA1OjaPaW4n9UM844LYdF	400
182	10.143.34.70 	PROD m6amcz psa-25bc426c	PSA	CLOUD	PostgreSQL 14.12 	PSA	4	6	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Dede P user/pas : PostgreSQL /bFAyEyz383ITMZ8MHImEfAnDzKZSTO74 	400
183	10.143.17.29	UAT wsjs97 edocpg-0db5bf0e	edoc	UBUNTU 10,22 GCP	PostgreSQL 13.21 	edoc (cloud_Instance)	2	5	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Benny Setiawan user/pass: "PostgreSQL "/"o1Gy1WbqQ3DZcTt4hyVGzkCzEHnFEKxb" user/pass:"edocplai"/"U0Y42h8mngzu-D8@"	400
184	10.143.34.199	PROD s3rcg0 apidb-e2626704	apidb	CLOUD	PostgreSQL 13.20 	apidb	8	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Syatria Babullah PostgreSQL /BCddZ3lIoxsgMqEd7Un2gB1JcMT7SFsx 	400
185	10.143.17.197	UAT pdf47h apidb-f000bac2	apidb	CLOUD	PostgreSQL 13.20 	apidb	4	8	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	password":"JqoNbmc/hgQud4wP",\n"username":"dev-svc" postgres/Ku6u6mpGsBplAeyeiiG28P8J3gDUk63o	400
186	10.143.34.226	PROD s3rcg0 oltp-5b56f831	oltp	CLOUD	PostgreSQL 13.13	oltp	8	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Syatria Babullah "oltp-svc"/"KT3meM@r-BdEBF1p" 	400
187	10.143.17.6	PROD pw0vxt smartclaimpg-new-121e1fea	smartclaim	CLOUD	PostgreSQL 12.16	smartclaim	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
189	10.143.17.96	DEV c5fzh0 pruhub3-a2202659	\N	CLOUD	PostgreSQL  9 6	\N	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	 PostgreSQL /UQTjnEpIOucHfEKaHHA8fDE2578DiXCu  dba_user/91s7tmqQzPt$@65-  pruhub_user/j-UESCT26jXXAR-! 	400
190	10.143.34.58	PROD fhsl34 pmnwf-new2-6a194f8d-replica001	PMN DB Replica	CLOUD	PostgreSQL  9 6	PMN DB Replica	12	24	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Fajar Tri  	400
191	10.141.23.11	UAT c5wvjk idlifec5wvjknuf	Renova_Individual	CLOUD	SQLSERVER  2017 STD	Renova (Cloud VM)	8	64	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Kris Ginting user/pass: renovaid/Password12 sa/Password09	400
192	10.143.17.32	DEV lgtk7w pruforce-5c930018	Pruforce Dev	CLOUD	PostgreSQL  16	Pruforce Dev	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
193	10.143.27.7	DEV w89lzu mitracomdev-3dbd2351	Mitracom	CLOUD	SQLSERVER 2019 ENTERPRISE	Mitracom	4	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
194	10.143.34.112	PROD cq4b9l consolidate-db	Consolidate DB	CLOUD	SQLSERVER 2019 ENTERPRISE	Consolidate DB	8	45	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
195	10.143.34.111	PROD cq4b9l internal-db	Internal DB (HR)	CLOUD	SQLSERVER 2019 ENTERPRISE	Internal DB (HR)	4	20	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
196	10.143.34.200	PROD i7e7oy newpruworks	Pruworks	CLOUD	SQLSERVER 2019 ENTERPRISE	Pruworks	8	49	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
197	10.143.17.8	DEV xdh57h radsoftdb	Radsoft dev	CLOUD	SQLSERVER 2019 ENTERPRISE	Radsoft dev	4	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
198	10.143.27.236	UAT h7xg8d pruworks-nprd-1bf475b2	Pruworks UAT	CLOUD	SQLSERVER 2019 ENTERPRISE	Pruworks UAT	4	24	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
199	10.143.27.57	UAT r9vnma crm-nprd-1ccd6221	CRM	CLOUD ubuntu linux 20.04 LTS	SQLSERVER 2022 STD	SCRM	2	9	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Salman Farizi user/pas : sqlserver/vA:sX3d@ 	400
201	10.143.34.206	PROD o35gws smartclaimpg-b9476f39-replica001	smartclaim	CLOUD	PostgreSQL 12.16	smartclaim (replica)	4	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
202	10.143.34.202	PROD o35gws smartclaimpg-b9476f39	smartclaim	CLOUD	PostgreSQL 12.16	smartclaim (master)	4	15	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	"password": "nl!rWHX@vSojmUbn",\n"username": "op-svc"\n\n"password": "rh1mTEj!U23pd6$5",\n  "username": "dba-user"\n\n"password": "rp@o73p6-knfv$lC",\n "username": "release-user"	400
203	10.143.34.42	PROD cmb6ze onepulsepg-60317328	onepulse	CLOUD	PostgreSQL 12.16	One Pulse Platform	2	7	0	t	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Benny Setiawan  	400
204	10.143.17.10	UAT p82cwr radsoftdbuat	Prudential	CLOUD	SQLSERVER 2019 ENTERPRISE	radsoft	4	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Kris Ginting sqlserver/ceJym<Le 	400
205	10.143.27.238	DEV r9vnma crm-reporting-nprd-5ca264f8	CRM Reporting UAT	Ubuntu 20.04	SQL Server 2022 ENTERPRISE	CRM Reporting UAT	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	sqlserver\n\n@78$hZ!L	400
206	10.143.34.109	PROD pxz32v crm-reporting-prod-4b5c8140	CRM Reporting	CLOUD	SQLSERVER 2019 ENTERPRISE	CRM Reporting	8	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
207	10.143.17.69	UAT qdunle psa-a83c68ff	PSA	UBUNTU 10,22 GCP	PostgreSQL 14.12 	PSA	1	3	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Dede P user/pas : PostgreSQL /AmZsWOWWl949v3lAtKMJeT9AVAqlBbHu 	400
208	10.143.34.223	DEV jjnvha edocpg-c18592f8	edoc	CLOUD	PostgreSQL 12.16	edoc (cloud_Instance)	2	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Benny Setiawan user/pass: "PostgreSQL "/"agG0nkLGOCphBdCwsUD5Cd1B8W0TmADT" user/pass: "edocplai"/"IOSBQgiK6hOiEvu-"	400
209	10.143.17.121	UAT eawwbd onepulseplatpg-1a3b455f	\N	CLOUD	PostgreSQL  16	\N	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	 PostgreSQL /b9b4cf99149f76d2 	400
210	10.143.17.88	DEV m9wvmh onepulseplatform-8ec602c4	\N	asia-southeast2	PostgreSQL  12	\N	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	 PostgreSQL /e4f88211cf99b3e7 	400
211	10.143.34.26	PROD babq79 digitalpartner-new-6d79c8d4	Digital Partner	CLOUD	PostgreSQL  12	Digital Partner	4	8	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Herdianto  	400
212	10.143.21.8	UAT gyy08m dbedoc-node-0	edoc	UBUNTU 10,22 GCP	PostgreSQL 12.16	edoc (cloud_VM)	1	1	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Benny Setiawan user/pass: edocplai/edoc2022 	400
213	10.143.36.140	DEV pfpbtb edoc (cloud_VM) edoc PRD	edoc	CLOUD	PostgreSQL 12.16	edoc (cloud_VM)	1	1	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Benny Setiawan user/pass: edocplai/edoc2022 	400
214	10.143.17.202	UAT fynu69 phsdb-f2775ab1	PHS	CLOUD	PostgreSQL  14	PHS	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
215	10.143.34.60	PROD krenc4 dqs-0d921dad	DQS	CLOUD	PostgreSQL  14	DQS	2	6	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	 	400
216	10.143.17.86	DEV yw4ncv dqs-21dddb1e	DQS Dev	CLOUD	PostgreSQL  14	DQS Dev	1	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
217	10.143.34.106	PROD asne4l pruforce-3f630c90	Pruforce	CLOUD	PostgreSQL  16	Pruforce	2	8	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
218	10.141.12.7	PROD DigiService DigiService	DigiService	CLOUD	PostgreSQL 10.6	\N	2	4	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	 PostgreSQL /Password09 	400
219	10.143.17.193	UAT pdf47h misdb-252a6e7d	mis-db uat	CLOUD Red Hat Enterprise Linux 	PostgreSQL  13	mis-db uat	2	6	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  "username":"dev-svc"\n"password":"n@WXnqZHwNZg7/td"\n"username":"dev-user"\n"password":"/vSwLnEYYDul8P!G"\n"password":"nog1-ePSZ/vgrL7-","username":"dev-ro"	400
220	10.143.34.230	PROD s3rcg0 oltp-5b56f831-replica001	OLTP Prod	CLOUD	PostgreSQL  13	OLTP Prod	8	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
221	10.143.34.23	PROD o7pm17 datalake01-8b1c79f9	Datalake	CLOUD	PostgreSQL  13	Datalake	8	32	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
222	10.143.17.95	DEV c5wvjk datalake-new-5d7890fa	Datalake Dev	CLOUD	PostgreSQL  13	Datalake Dev	2	8	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  	400
1	10.170.53.102	AOB DB ESUB PRD	VIDDCLXPAOBDB03	Red Hat  7.9  (RHEL)	EnterpriseDB 9.6.2.7	0	32	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	814 GB	400
2	10.170.53.103	AOB EPOLICY DB (WAB,Fuse)  PRD	VIDDCLXPAOBDB04	Red Hat  7.9  (RHEL)	EnterpriseDB 14.13	0	46	20	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-05-28 15:06:28	\N	200 GB DISK --- NIDLIFEAPPSUP ada versi 14 UP	400
33	10.170.48.215	K2 DB server PRD	VIDHOWNPKTWDB01	Windows Server 2016	SQL Server 2016	0	20	2	8	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2025-02-27 11:53:25	\N	Syofianer Fitra	400
55	10.171.84.43	RESDB DB2 PRD	VIDDCLXPODMDB01	Red Hat  7.9  (RHEL)	DB2 v10.5.0.3	0	31	4	0	t	1	1	1	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-08-01 08:00:00	\N	Afdoli Fahmi , MIS  \n user SPLAIODM pass: Password09 di ip\n10.171.84.43 (BRMS)	400
64	10.170.48.35	DB Server Sentinel  PRD	vidhownpnmsap02	Windows Server 2016	SQL Server 2012	0	16	8	0	t	1	1	5	2024-08-01 08:00:00	2024-08-01 08:00:00	2024-12-02 15:35:36	\N	Ridwan Royani, Manage by Nice Vendor	400
103	10.170.53.114	NPRD	vidhownp2faap01 	Windows Server 2012 R2	PostgreSQL 14.12	0	16	8	0	t	1	1	4	2024-04-01 08:00:00	2024-04-01 08:00:00	2024-09-01 08:00:00	\N	Upgrade Postgres v.8.3 to 14.3	400
116	10.170.49.195	NPRD	vidhowndefmdb01	Windows Server 2016	SQL Server 2016 SP 3	0	16	8	0	t	1	1	5	2024-06-01 08:00:00	2024-06-01 08:00:00	2024-06-01 08:00:00	\N	\N	400
146	10.143.34.85	newpruworks PRD	pruidlife-prod	CLOUD SQL  SVR	PostgreSQL 15.8	0	16	8	0	t	1	1	5	2024-11-19 00:00:00	2024-11-19 13:53:08	2024-11-19 14:30:32	\N	 "default_password": "\\u003cM?WuPtb",\n  "default_username": "pruuser", "root_password": "K2b\\u003ej1ly"	400
150	10.170.49.73	UAT 	VIDDCLXDGAIAPP01	Red Hat Enterprise Linux 	Postgres 14.0	0	16	23	0	t	1	1	4	2025-02-06 00:00:00	2025-02-06 14:38:58	2025-02-06 14:38:58	\N	VIDDCLXDGAIAPP01	400
160	10.143.34.237	pruhub3-168cfd2c	s16gul	CLOUD SQL	PostgreSQL 9	0	16	8	0	t	1	1	1	2025-05-14 00:00:00	2025-05-14 09:13:32	2025-07-21 11:26:51	\N	[{"password":"v1CtdwHkyX@7RYi8","username":"dba_user"},\n{"password":"9TKYrP$8kU15Ny-O","username":"pruhub_user"},\n{"password":"N/TdoFP@ey0nwRWP","username":"service_user"}]	400
188	10.141.19.86	UAT el8fvd PostgreSQL -digiservice (gke)	PostgreSQL 	CLOUD	PostgreSQL 10.6 	\N	1	2	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Fajar Tri PostgreSQL /P@ssw0rd 	400
200	10.143.34.79	PROD syxuqi renovadb2-aaf0f976  (Cloud Instance) Renova_Individual PRD	Renova_Individual	CLOUD	SQLSERVER 2019 STD	Renova (Cloud Instance)	4	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Kris Ginting user/pass: renovadb/5J+a]OlQ user/pass: "sqlserver"/"XpIeX_N&"	400
223	10.141.15.39	PROD wwe3r3 idlifewwe3r3jbi	SUN	CLOUD	SQLSERVER  2016 STD	SUN Payment	8	32	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Salman Farizi sun.dbadmin  Password09	400
224	10.141.15.36	PROD wwe3r3 idlifewwe3r3bcp	TLM	CLOUD	SQLSERVER  2016 STD	TLM Payment	8	32	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Salman Farizi user : SRVPLAIPRTLMSMARTS01 Password : Q42PDxA(	400
225	10.143.34.36	STAGGING j5toic mitracommprd-1a1636b9	smsgw_prod	CLOUD SQL UBUNTU 20	SQLSERVER 2019 STD	mitracom	4	16	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Aji  "default_password":"D<1n=j}K",\n "default_username":"mitracommadm",\n "root" d6fs4NeX" 	400
226	10.141.23.9	DEV c5wvjk win1-c5wvjk-001	ifrs17	CLOUD	SQLSERVER 2019 STD	Ifrs17 (cloud_VM)	10	32	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Agam Adhinegara user/pass: sa/Password09 user/pass : PRUASIA\\407409\tWindows_autentication (superuser)	400
227	10.143.34.120	PROD babq79 pruservices-b6414432	Pruservices	CLOUD	PostgreSQL  16	Pruservices	4	8	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	  username: operation_user_prd | password: p+FNaj+34-49{H1J{>9!\n    "password": "ylsaTGbqz!ZcV8@H",\n    "username": "operation_user_prd"	400
228	10.143.17.59	DEV pdf47h keycloackdb-0ad4bfd6	keycloack	UBUNTU 10,22 GCP	PostgreSQL 13.15	keycloack	4	8	0	f	1	1	1	2025-08-05 00:00:00	2025-08-05 00:00:00	2025-08-05 00:00:00	\N	Syatria Babullah user/pas: "PostgreSQL "/d5iv2cp2t2LmRfIXECtypk1JBh71r7bl	400
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	2014_10_12_000000_create_users_table	1
2	2014_10_12_100000_create_password_reset_tokens_table	1
3	2014_10_12_200000_add_two_factor_columns_to_users_table	1
4	2019_08_19_000000_create_failed_jobs_table	1
5	2019_12_14_000001_create_personal_access_tokens_table	1
6	2020_05_21_100000_create_companies_table	1
7	2020_05_21_200000_create_company_user_table	1
8	2020_05_21_300000_create_company_invitations_table	1
9	2023_02_26_172600_create_schedule_table	1
10	2023_02_26_175242_create_schedule_histories_table	1
11	2023_06_22_145512_create_sessions_table	1
12	2023_06_22_151657_create_permission_tables	1
13	2023_06_22_154509_create_provaiders_table	1
14	2023_06_22_154859_create_hardware_table	1
15	2023_06_22_161713_create_periphels_table	1
16	2023_06_22_163258_create_software_table	1
17	2023_06_25_175501_create_activity_log_table	1
18	2023_06_25_175502_add_event_column_to_activity_log_table	1
19	2023_06_25_175503_add_batch_uuid_column_to_activity_log_table	1
20	2023_06_28_013125_create_notifications_table	1
21	2025_07_11_090559_create_system_metrics_table	2
\.


--
-- Data for Name: model_has_permissions; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.model_has_permissions (permission_id, model_type, model_id) FROM stdin;
\.


--
-- Data for Name: model_has_roles; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.model_has_roles (role_id, model_type, model_id) FROM stdin;
1	App\\Models\\User	1
1	App\\Models\\User	3
2	App\\Models\\User	10
3	App\\Models\\User	3
3	App\\Models\\User	6
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.notifications (id, type, notifiable_type, notifiable_id, data, read_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: periphels; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.periphels (id, make, model, serial, type, company_id, user_id, provaider_id, current, purchased_at, created_at, updated_at, deleted_at) FROM stdin;
1	Arif	Cable	223344	Console	1	6	1	t	2024-10-08 00:00:00	2024-10-08 14:09:27	2024-10-08 14:09:27	\N
2	Free	SQL Conector DB	3344212343	ODBC	1	3	5	t	2024-10-08 00:00:00	2024-10-08 21:17:16	2024-10-08 21:17:16	\N
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.permissions (id, name, guard_name, created_at, updated_at) FROM stdin;
1	view_activity	web	2023-06-25 18:53:30	2023-06-25 18:53:30
2	view_any_activity	web	2023-06-25 18:53:30	2023-06-25 18:53:30
3	create_activity	web	2023-06-25 18:53:30	2023-06-25 18:53:30
4	update_activity	web	2023-06-25 18:53:30	2023-06-25 18:53:30
5	restore_activity	web	2023-06-25 18:53:30	2023-06-25 18:53:30
6	restore_any_activity	web	2023-06-25 18:53:30	2023-06-25 18:53:30
7	replicate_activity	web	2023-06-25 18:53:30	2023-06-25 18:53:30
8	reorder_activity	web	2023-06-25 18:53:30	2023-06-25 18:53:30
9	delete_activity	web	2023-06-25 18:53:30	2023-06-25 18:53:30
10	delete_any_activity	web	2023-06-25 18:53:30	2023-06-25 18:53:30
11	force_delete_activity	web	2023-06-25 18:53:30	2023-06-25 18:53:30
12	force_delete_any_activity	web	2023-06-25 18:53:30	2023-06-25 18:53:30
13	view_company	web	2023-06-25 18:53:30	2023-06-25 18:53:30
14	view_any_company	web	2023-06-25 18:53:30	2023-06-25 18:53:30
15	create_company	web	2023-06-25 18:53:30	2023-06-25 18:53:30
16	update_company	web	2023-06-25 18:53:30	2023-06-25 18:53:30
17	restore_company	web	2023-06-25 18:53:30	2023-06-25 18:53:30
18	restore_any_company	web	2023-06-25 18:53:30	2023-06-25 18:53:30
19	replicate_company	web	2023-06-25 18:53:30	2023-06-25 18:53:30
20	reorder_company	web	2023-06-25 18:53:30	2023-06-25 18:53:30
21	delete_company	web	2023-06-25 18:53:30	2023-06-25 18:53:30
22	delete_any_company	web	2023-06-25 18:53:30	2023-06-25 18:53:30
23	force_delete_company	web	2023-06-25 18:53:30	2023-06-25 18:53:30
24	force_delete_any_company	web	2023-06-25 18:53:30	2023-06-25 18:53:30
25	view_company::invitation	web	2023-06-25 18:53:30	2023-06-25 18:53:30
26	view_any_company::invitation	web	2023-06-25 18:53:30	2023-06-25 18:53:30
27	create_company::invitation	web	2023-06-25 18:53:30	2023-06-25 18:53:30
28	update_company::invitation	web	2023-06-25 18:53:30	2023-06-25 18:53:30
29	restore_company::invitation	web	2023-06-25 18:53:30	2023-06-25 18:53:30
30	restore_any_company::invitation	web	2023-06-25 18:53:30	2023-06-25 18:53:30
31	replicate_company::invitation	web	2023-06-25 18:53:30	2023-06-25 18:53:30
32	reorder_company::invitation	web	2023-06-25 18:53:30	2023-06-25 18:53:30
33	delete_company::invitation	web	2023-06-25 18:53:30	2023-06-25 18:53:30
34	delete_any_company::invitation	web	2023-06-25 18:53:30	2023-06-25 18:53:30
35	force_delete_company::invitation	web	2023-06-25 18:53:30	2023-06-25 18:53:30
36	force_delete_any_company::invitation	web	2023-06-25 18:53:30	2023-06-25 18:53:30
37	view_employeeship	web	2023-06-25 18:53:30	2023-06-25 18:53:30
38	view_any_employeeship	web	2023-06-25 18:53:30	2023-06-25 18:53:30
39	create_employeeship	web	2023-06-25 18:53:30	2023-06-25 18:53:30
40	update_employeeship	web	2023-06-25 18:53:30	2023-06-25 18:53:30
41	restore_employeeship	web	2023-06-25 18:53:30	2023-06-25 18:53:30
42	restore_any_employeeship	web	2023-06-25 18:53:30	2023-06-25 18:53:30
43	replicate_employeeship	web	2023-06-25 18:53:30	2023-06-25 18:53:30
44	reorder_employeeship	web	2023-06-25 18:53:30	2023-06-25 18:53:30
45	delete_employeeship	web	2023-06-25 18:53:30	2023-06-25 18:53:30
46	delete_any_employeeship	web	2023-06-25 18:53:30	2023-06-25 18:53:30
47	force_delete_employeeship	web	2023-06-25 18:53:30	2023-06-25 18:53:30
48	force_delete_any_employeeship	web	2023-06-25 18:53:30	2023-06-25 18:53:30
49	view_hardware	web	2023-06-25 18:53:30	2023-06-25 18:53:30
50	view_any_hardware	web	2023-06-25 18:53:30	2023-06-25 18:53:30
51	create_hardware	web	2023-06-25 18:53:30	2023-06-25 18:53:30
52	update_hardware	web	2023-06-25 18:53:30	2023-06-25 18:53:30
53	restore_hardware	web	2023-06-25 18:53:30	2023-06-25 18:53:30
54	restore_any_hardware	web	2023-06-25 18:53:30	2023-06-25 18:53:30
55	replicate_hardware	web	2023-06-25 18:53:30	2023-06-25 18:53:30
56	reorder_hardware	web	2023-06-25 18:53:30	2023-06-25 18:53:30
57	delete_hardware	web	2023-06-25 18:53:30	2023-06-25 18:53:30
58	delete_any_hardware	web	2023-06-25 18:53:30	2023-06-25 18:53:30
59	force_delete_hardware	web	2023-06-25 18:53:30	2023-06-25 18:53:30
60	force_delete_any_hardware	web	2023-06-25 18:53:30	2023-06-25 18:53:30
61	view_periphel	web	2023-06-25 18:53:30	2023-06-25 18:53:30
62	view_any_periphel	web	2023-06-25 18:53:30	2023-06-25 18:53:30
63	create_periphel	web	2023-06-25 18:53:30	2023-06-25 18:53:30
64	update_periphel	web	2023-06-25 18:53:30	2023-06-25 18:53:30
65	restore_periphel	web	2023-06-25 18:53:30	2023-06-25 18:53:30
66	restore_any_periphel	web	2023-06-25 18:53:30	2023-06-25 18:53:30
67	replicate_periphel	web	2023-06-25 18:53:30	2023-06-25 18:53:30
68	reorder_periphel	web	2023-06-25 18:53:30	2023-06-25 18:53:30
69	delete_periphel	web	2023-06-25 18:53:30	2023-06-25 18:53:30
70	delete_any_periphel	web	2023-06-25 18:53:30	2023-06-25 18:53:30
71	force_delete_periphel	web	2023-06-25 18:53:30	2023-06-25 18:53:30
72	force_delete_any_periphel	web	2023-06-25 18:53:30	2023-06-25 18:53:30
73	view_provaider	web	2023-06-25 18:53:30	2023-06-25 18:53:30
74	view_any_provaider	web	2023-06-25 18:53:30	2023-06-25 18:53:30
75	create_provaider	web	2023-06-25 18:53:30	2023-06-25 18:53:30
76	update_provaider	web	2023-06-25 18:53:30	2023-06-25 18:53:30
77	restore_provaider	web	2023-06-25 18:53:30	2023-06-25 18:53:30
78	restore_any_provaider	web	2023-06-25 18:53:30	2023-06-25 18:53:30
79	replicate_provaider	web	2023-06-25 18:53:30	2023-06-25 18:53:30
80	reorder_provaider	web	2023-06-25 18:53:30	2023-06-25 18:53:30
81	delete_provaider	web	2023-06-25 18:53:30	2023-06-25 18:53:30
82	delete_any_provaider	web	2023-06-25 18:53:30	2023-06-25 18:53:30
83	force_delete_provaider	web	2023-06-25 18:53:30	2023-06-25 18:53:30
84	force_delete_any_provaider	web	2023-06-25 18:53:30	2023-06-25 18:53:30
85	view_role	web	2023-06-25 18:53:30	2023-06-25 18:53:30
86	view_any_role	web	2023-06-25 18:53:30	2023-06-25 18:53:30
87	create_role	web	2023-06-25 18:53:30	2023-06-25 18:53:30
88	update_role	web	2023-06-25 18:53:30	2023-06-25 18:53:30
89	delete_role	web	2023-06-25 18:53:30	2023-06-25 18:53:30
90	delete_any_role	web	2023-06-25 18:53:30	2023-06-25 18:53:30
91	view_software	web	2023-06-25 18:53:30	2023-06-25 18:53:30
92	view_any_software	web	2023-06-25 18:53:30	2023-06-25 18:53:30
93	create_software	web	2023-06-25 18:53:30	2023-06-25 18:53:30
94	update_software	web	2023-06-25 18:53:30	2023-06-25 18:53:30
95	restore_software	web	2023-06-25 18:53:30	2023-06-25 18:53:30
96	restore_any_software	web	2023-06-25 18:53:30	2023-06-25 18:53:30
97	replicate_software	web	2023-06-25 18:53:30	2023-06-25 18:53:30
98	reorder_software	web	2023-06-25 18:53:30	2023-06-25 18:53:30
99	delete_software	web	2023-06-25 18:53:30	2023-06-25 18:53:30
100	delete_any_software	web	2023-06-25 18:53:30	2023-06-25 18:53:30
101	force_delete_software	web	2023-06-25 18:53:30	2023-06-25 18:53:30
102	force_delete_any_software	web	2023-06-25 18:53:30	2023-06-25 18:53:30
103	page_Profile	web	2023-06-25 18:53:30	2023-06-25 18:53:30
104	page_APITokens	web	2023-06-25 18:53:30	2023-06-25 18:53:30
105	page_CompanySettings	web	2023-06-25 18:53:30	2023-06-25 18:53:30
106	page_CreateCompany	web	2023-06-25 18:53:30	2023-06-25 18:53:30
107	widget_EmployeeChart	web	2023-06-25 18:53:30	2023-06-25 18:53:30
108	widget_HardwareChart	web	2023-06-25 18:53:30	2023-06-25 18:53:30
109	widget_SoftwareChart	web	2023-06-25 18:53:30	2023-06-25 18:53:30
110	widget_StatsOverview	web	2023-06-25 18:53:30	2023-06-25 18:53:30
111	widget_PeriphelsChart	web	2023-06-25 18:53:30	2023-06-25 18:53:30
112	view_user	web	2023-06-25 18:53:30	2023-06-25 18:53:30
113	view_any_user	web	2023-06-25 18:53:30	2023-06-25 18:53:30
114	create_user	web	2023-06-25 18:53:30	2023-06-25 18:53:30
115	update_user	web	2023-06-25 18:53:30	2023-06-25 18:53:30
116	restore_user	web	2023-06-25 18:53:30	2023-06-25 18:53:30
117	restore_any_user	web	2023-06-25 18:53:30	2023-06-25 18:53:30
118	replicate_user	web	2023-06-25 18:53:30	2023-06-25 18:53:30
119	reorder_user	web	2023-06-25 18:53:30	2023-06-25 18:53:30
120	delete_user	web	2023-06-25 18:53:30	2023-06-25 18:53:30
121	delete_any_user	web	2023-06-25 18:53:30	2023-06-25 18:53:30
122	force_delete_user	web	2023-06-25 18:53:30	2023-06-25 18:53:30
123	force_delete_any_user	web	2023-06-25 18:53:30	2023-06-25 18:53:30
124	view_any_schedule	web	2023-06-25 18:53:30	2023-06-25 18:53:30
125	view_schedule	web	2023-06-25 18:53:30	2023-06-25 18:53:30
126	delete_schedule	web	2023-06-25 18:53:30	2023-06-25 18:53:30
127	force_delete_schedule	web	2023-06-25 18:53:30	2023-06-25 18:53:30
128	force_delete_any_schedule	web	2023-06-25 18:53:30	2023-06-25 18:53:30
129	restore_schedule	web	2023-06-25 18:53:30	2023-06-25 18:53:30
130	restore_any_schedule	web	2023-06-25 18:53:30	2023-06-25 18:53:30
131	replicate_schedule	web	2023-06-25 18:53:30	2023-06-25 18:53:30
132	reorder_schedule	web	2023-06-25 18:53:30	2023-06-25 18:53:30
133	page_Artisan	web	2023-06-25 18:53:30	2023-06-25 18:53:30
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at) FROM stdin;
1	App\\Models\\User	3	APP_API_TOKEN	d7fdec73a1106209ba0669e1572dd71bd10fa439fc816a4f0fb34fd08abb2cb6	["create","delete","read","update"]	\N	\N	2025-05-05 22:27:38	2025-05-05 22:27:38
\.


--
-- Data for Name: provaiders; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.provaiders (id, company_id, name, created_at, updated_at) FROM stdin;
1	1	HPE	2024-10-05 11:59:24	2024-10-05 11:59:24
2	1	DELL	2024-10-05 11:59:28	2024-10-05 11:59:28
3	1	ORACLE	2024-10-05 11:59:33	2024-10-05 11:59:33
5	1	Microsoft	2024-10-08 21:16:06	2024-10-08 21:16:06
4	1	PostgresSQL	2024-10-08 21:15:57	2024-10-12 12:55:00
6	1	Rhell Enterprise	2024-10-12 12:59:23	2024-10-12 12:59:23
\.


--
-- Data for Name: role_has_permissions; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.role_has_permissions (permission_id, role_id) FROM stdin;
11	1
12	1
13	1
14	1
15	1
16	1
17	1
18	1
19	1
20	1
21	1
22	1
23	1
24	1
25	1
26	1
27	1
28	1
29	1
30	1
31	1
32	1
33	1
34	1
35	1
36	1
37	1
38	1
39	1
40	1
41	1
42	1
43	1
44	1
45	1
46	1
47	1
48	1
49	1
50	1
51	1
52	1
53	1
54	1
55	1
56	1
57	1
58	1
59	1
60	1
61	1
62	1
63	1
64	1
65	1
66	1
67	1
68	1
69	1
70	1
71	1
72	1
73	1
74	1
75	1
76	1
77	1
78	1
79	1
80	1
81	1
82	1
83	1
84	1
85	1
86	1
87	1
88	1
89	1
90	1
91	1
92	1
93	1
94	1
95	1
96	1
97	1
98	1
99	1
100	1
101	1
102	1
103	1
104	1
105	1
106	1
107	1
108	1
109	1
110	1
111	1
112	1
113	1
114	1
115	1
116	1
117	1
118	1
119	1
120	1
121	1
122	1
123	1
124	1
125	1
126	1
127	1
128	1
129	1
130	1
131	1
132	1
133	1
49	2
50	2
51	2
52	2
56	2
92	2
93	2
94	2
98	2
109	2
110	2
49	3
50	3
51	3
52	3
56	3
92	3
93	3
94	3
98	3
108	3
109	3
110	3
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.roles (id, name, guard_name, created_at, updated_at) FROM stdin;
1	super_admin	web	2023-06-25 18:53:30	2023-06-25 18:53:30
2	filament_user	web	2023-06-25 18:53:30	2023-06-25 18:53:30
3	mis_user	web	2023-06-25 18:53:30	2023-06-25 18:53:30
\.


--
-- Data for Name: schedule_histories; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.schedule_histories (id, schedule_id, command, params, output, options, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schedules; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.schedules (id, command, command_custom, params, expression, environments, options, options_with_value, log_filename, even_in_maintenance_mode, without_overlapping, on_one_server, webhook_before, webhook_after, email_output, sendmail_error, log_success, log_error, status, run_in_background, sendmail_success, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
\.


--
-- Data for Name: software; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.software (id, name, type, status, current, licenses, license_period, company_id, provaider_id, purchased_at, expired_at, created_at, updated_at, deleted_at) FROM stdin;
3	Enterprise DB	Console	Active	t	Enterprise	1 year	1	1	2024-10-08 00:00:00	2024-10-08 00:00:00	2024-10-08 21:14:55	2024-10-08 21:15:29	2024-10-08 21:15:29
5	SQL SERVER 2016	Database	Active	t	STD	Lifetime	1	5	2024-01-01 00:00:00	2026-01-01 00:00:00	2024-10-12 12:57:04	2024-10-12 12:57:04	\N
6	Windows Server 2016	Operating System	Active	t	Enterprise	Lifetime	1	5	2024-01-01 00:00:00	2028-01-01 00:00:00	2024-10-12 12:58:55	2024-10-12 12:58:55	\N
7	Red Hat 8 Enterprise (Rhell)	Operating System	Active	t	Enterprise	Lifetime	1	6	2024-01-01 00:00:00	2028-01-01 00:00:00	2024-10-12 13:00:28	2024-10-12 13:00:28	\N
1	Enterprise DB 14	EDB 14.0	Active	t	FREE	1 year	1	4	2024-08-01 00:00:00	2025-08-01 04:00:00	2024-10-05 12:04:09	2024-11-06 05:27:40	\N
4	PostgresSQL	DB	Active	t	Free	1 year	1	4	2024-08-04 00:00:00	2025-08-04 00:00:00	2024-10-08 22:34:44	2024-11-06 05:28:30	\N
2	CSR greenplum for SSL Certificate 	SSL	Active	t	Enterprise	1 year	1	4	2024-10-05 00:00:00	2025-11-05 00:00:00	2024-10-06 23:39:59	2025-01-15 10:58:27	\N
\.


--
-- Data for Name: system_metrics; Type: TABLE DATA; Schema: public; Owner: mis_user
--

COPY public.system_metrics (id, "timestamp", hostname, environment, cpu_usage, memory_usage, disk_usage, network_usage, status, extra1, extra2, file_name, load_status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: test; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.test (id, make, model, serial, os_name, os_version, type, ram, cpu, status, current, company_id, user_id, provaider_id, purchased_at, created_at, updated_at, deleted_at, note) FROM stdin;
4	10.171.140.16	Payment Database	VIDDCLXPNPHDB01-New	LINUX RHELL	EnterpriseDB 9.6.5.10	0	32	4	0	t	1	1	1	2024-02-10 08:00:00	2024-10-10 05:57:00	2024-10-10 05:57:00	\N	688 GB
\N	aa	aa	aa	aa	aa	0	12	12	0	\N	1	3	1	2024-10-08 00:00:00	2024-10-08 20:56:59	2024-10-08 20:56:59	\N	\N
\N	aa	aa	aa	aa	aa	0	12	12	0	\N	1	3	1	2024-10-08 00:00:00	2024-10-08 20:56:59	2024-10-08 20:56:59	\N	\N
\N	aa	aa	aa	aa	aa	0	12	12	0	\N	1	3	1	2024-10-08 00:00:00	2024-10-08 20:56:59	2024-10-08 20:56:59	\N	\N
\N	aa	aa	aa	aa	aa	0	12	12	0	\N	1	3	1	2024-10-08 00:00:00	2024-10-08 20:56:59	2024-10-08 20:56:59	\N	\N
\N	http://10.170.49.136:808/	APPS	VIDDRLXUGBQDB01	Red Hat Enterprise Linux	Postgres 16.0	0	125Gi	32	0	\N	1	3	1	2024-10-08 00:00:00	2024-10-08 21:28:58	2024-10-08 21:28:58	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: dba_user
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, current_company_id, current_connected_account_id, profile_photo_path, created_at, updated_at, two_factor_secret, two_factor_recovery_codes, two_factor_confirmed_at) FROM stdin;
1	Administrator	admin@prudential.co.id	2024-10-05 11:36:22	$2y$10$nvOOlJhaY/HDo6aM9M2ohOAp2E5o6S5DXHyxaUm4G.LfY5LLSbz6C	58AIxX7s2btxYk2OVg0M9HmBngBT16XfFQ54fRZfdu4oSXYeOfZhPd8HX2a0	5	\N	\N	2023-01-02 12:04:04	2024-10-07 15:59:37	\N	\N	\N
5	Haris Rifai	moh.rifai-consultant@prudential.co.id	\N	$2y$10$VUGu2ryUzB0wE2BE3pLdBuGMU.uhemjdJ2.ips39grCjDxEZxpRDu	vcvGBGYahlg7wI7ZlgQnF0VZbYRhUHKo55Gn7lrtKMC7NJBD1yNWslNRuRsZ	1	\N	\N	2024-10-11 09:14:10	2024-10-11 09:19:24	\N	\N	\N
3	Harys 	harys@prudential.co.id	2024-10-05 11:36:22	$2y$10$VUGu2ryUzB0wE2BE3pLdBuGMU.uhemjdJ2.ips39grCjDxEZxpRDu	jlckrh9RcqF9REs3htANvyptUqsUb1detss4uqTJqiMeMJI0WvVXBAPyBb5h	1	\N	profile-photos/pVpVe66ve64fFKJ0idajdDuefBlcFym7qvpp3KAU.png	2024-03-03 07:29:45	2025-07-11 07:03:16	\N	\N	\N
6	Arif Rahman	arif.rahman@prudential.co.id	2024-10-05 11:36:22	$2y$10$4tSuMfhBFOmvB5DaUHE4euw24KmyY0XSY2/gCQOhVhv8QHdeeHmiG	uf8fV2EpEEXwnMmauiR3JS8srTYSm2Phv4M5uIVDZLHfwDdsDSjKzN9eLsvg	1	\N	\N	2024-07-03 05:13:38	2024-10-07 15:57:56	\N	\N	\N
10	Afdoli Fahmi	afdoli.fahmi@prudential.co.id	2024-10-05 11:36:22	$2y$10$VUGu2ryUzB0wE2BE3pLdBuGMU.uhemjdJ2.ips39grCjDxEZxpRDu	4cs3yTX2IxbpvfseS2tZEfFzMLM214E0nmTzKJHrybmxOPVazyFYe3yYEBiS	1	\N	\N	2024-07-27 18:01:01	2024-10-07 15:58:09	\N	\N	\N
\.


--
-- Name: jobid_seq; Type: SEQUENCE SET; Schema: cron; Owner: dba_user
--

SELECT pg_catalog.setval('cron.jobid_seq', 13, true);


--
-- Name: runid_seq; Type: SEQUENCE SET; Schema: cron; Owner: dba_user
--

SELECT pg_catalog.setval('cron.runid_seq', 499, true);


--
-- Name: activity_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dba_user
--

SELECT pg_catalog.setval('public.activity_log_id_seq', 1030, true);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dba_user
--

SELECT pg_catalog.setval('public.companies_id_seq', 5, true);


--
-- Name: company_invitations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dba_user
--

SELECT pg_catalog.setval('public.company_invitations_id_seq', 1, false);


--
-- Name: company_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dba_user
--

SELECT pg_catalog.setval('public.company_user_id_seq', 10, true);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dba_user
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: hardware_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dba_user
--

SELECT pg_catalog.setval('public.hardware_id_seq', 200, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dba_user
--

SELECT pg_catalog.setval('public.migrations_id_seq', 22, true);


--
-- Name: periphels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dba_user
--

SELECT pg_catalog.setval('public.periphels_id_seq', 2, true);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dba_user
--

SELECT pg_catalog.setval('public.permissions_id_seq', 7, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dba_user
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, true);


--
-- Name: provaiders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dba_user
--

SELECT pg_catalog.setval('public.provaiders_id_seq', 6, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dba_user
--

SELECT pg_catalog.setval('public.roles_id_seq', 2, true);


--
-- Name: schedule_histories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dba_user
--

SELECT pg_catalog.setval('public.schedule_histories_id_seq', 1, false);


--
-- Name: schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dba_user
--

SELECT pg_catalog.setval('public.schedules_id_seq', 1, false);


--
-- Name: software_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dba_user
--

SELECT pg_catalog.setval('public.software_id_seq', 7, true);


--
-- Name: system_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mis_user
--

SELECT pg_catalog.setval('public.system_metrics_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dba_user
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: activity_log activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_invitations company_invitations_company_id_email_unique; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.company_invitations
    ADD CONSTRAINT company_invitations_company_id_email_unique UNIQUE (company_id, email);


--
-- Name: company_invitations company_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.company_invitations
    ADD CONSTRAINT company_invitations_pkey PRIMARY KEY (id);


--
-- Name: company_user company_user_company_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.company_user
    ADD CONSTRAINT company_user_company_id_user_id_unique UNIQUE (company_id, user_id);


--
-- Name: company_user company_user_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.company_user
    ADD CONSTRAINT company_user_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: hardware_050425 hardware_copy1_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.hardware_050425
    ADD CONSTRAINT hardware_copy1_pkey PRIMARY KEY (id);


--
-- Name: hardware_140525 hardware_copy1_pkey1; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.hardware_140525
    ADD CONSTRAINT hardware_copy1_pkey1 PRIMARY KEY (id);


--
-- Name: hardware_050825 hardware_copy1_pkey2; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.hardware_050825
    ADD CONSTRAINT hardware_copy1_pkey2 PRIMARY KEY (id);


--
-- Name: hardware hardware_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.hardware
    ADD CONSTRAINT hardware_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: model_has_permissions model_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_pkey PRIMARY KEY (permission_id, model_id, model_type);


--
-- Name: model_has_roles model_has_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_pkey PRIMARY KEY (role_id, model_id, model_type);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: periphels periphels_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.periphels
    ADD CONSTRAINT periphels_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_guard_name_unique UNIQUE (name, guard_name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: provaiders provaiders_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.provaiders
    ADD CONSTRAINT provaiders_pkey PRIMARY KEY (id);


--
-- Name: role_has_permissions role_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_pkey PRIMARY KEY (permission_id, role_id);


--
-- Name: roles roles_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_guard_name_unique UNIQUE (name, guard_name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: schedule_histories schedule_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.schedule_histories
    ADD CONSTRAINT schedule_histories_pkey PRIMARY KEY (id);


--
-- Name: schedules schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: software software_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.software
    ADD CONSTRAINT software_pkey PRIMARY KEY (id);


--
-- Name: system_metrics system_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: mis_user
--

ALTER TABLE ONLY public.system_metrics
    ADD CONSTRAINT system_metrics_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: activity_log_log_name_index; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX activity_log_log_name_index ON public.activity_log USING btree (log_name);


--
-- Name: causer; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX causer ON public.activity_log USING btree (causer_type, causer_id);


--
-- Name: companies_user_id_index; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX companies_user_id_index ON public.companies USING btree (user_id);


--
-- Name: hardware_company_id_index; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX hardware_company_id_index ON public.hardware USING btree (company_id);


--
-- Name: hardware_company_id_index_copy1; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX hardware_company_id_index_copy1 ON public.hardware_050425 USING btree (company_id);


--
-- Name: hardware_company_id_index_copy2; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX hardware_company_id_index_copy2 ON public.hardware_140525 USING btree (company_id);


--
-- Name: hardware_company_id_index_copy3; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX hardware_company_id_index_copy3 ON public.hardware_050825 USING btree (company_id);


--
-- Name: hardware_provaider_id_index; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX hardware_provaider_id_index ON public.hardware USING btree (provaider_id);


--
-- Name: hardware_provaider_id_index_copy1; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX hardware_provaider_id_index_copy1 ON public.hardware_050425 USING btree (provaider_id);


--
-- Name: hardware_provaider_id_index_copy2; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX hardware_provaider_id_index_copy2 ON public.hardware_140525 USING btree (provaider_id);


--
-- Name: hardware_provaider_id_index_copy3; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX hardware_provaider_id_index_copy3 ON public.hardware_050825 USING btree (provaider_id);


--
-- Name: hardware_user_id_index; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX hardware_user_id_index ON public.hardware USING btree (user_id);


--
-- Name: hardware_user_id_index_copy1; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX hardware_user_id_index_copy1 ON public.hardware_050425 USING btree (user_id);


--
-- Name: hardware_user_id_index_copy2; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX hardware_user_id_index_copy2 ON public.hardware_140525 USING btree (user_id);


--
-- Name: hardware_user_id_index_copy3; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX hardware_user_id_index_copy3 ON public.hardware_050825 USING btree (user_id);


--
-- Name: idx_hardware270225_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware270225_btree ON public.hardware270225 USING btree (make);


--
-- Name: idx_hardware270225_company_id_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware270225_company_id_btree ON public.hardware270225 USING btree (company_id);


--
-- Name: idx_hardware270225_cpu_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware270225_cpu_btree ON public.hardware270225 USING btree (cpu);


--
-- Name: idx_hardware270225_current_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware270225_current_btree ON public.hardware270225 USING btree (current);


--
-- Name: idx_hardware270225_deleted_at_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware270225_deleted_at_btree ON public.hardware270225 USING btree (deleted_at);


--
-- Name: idx_hardware270225_model_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware270225_model_btree ON public.hardware270225 USING btree (model);


--
-- Name: idx_hardware270225_note_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware270225_note_btree ON public.hardware270225 USING btree (note);


--
-- Name: idx_hardware270225_os_name_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware270225_os_name_btree ON public.hardware270225 USING btree (os_name);


--
-- Name: idx_hardware270225_os_version_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware270225_os_version_btree ON public.hardware270225 USING btree (os_version);


--
-- Name: idx_hardware270225_provaider_id_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware270225_provaider_id_btree ON public.hardware270225 USING btree (provaider_id);


--
-- Name: idx_hardware270225_purchased_at_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware270225_purchased_at_btree ON public.hardware270225 USING btree (purchased_at);


--
-- Name: idx_hardware270225_ram_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware270225_ram_btree ON public.hardware270225 USING btree (ram);


--
-- Name: idx_hardware270225_serial_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware270225_serial_btree ON public.hardware270225 USING btree (serial);


--
-- Name: idx_hardware270225_status_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware270225_status_btree ON public.hardware270225 USING btree (status);


--
-- Name: idx_hardware270225_type_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware270225_type_btree ON public.hardware270225 USING btree (type);


--
-- Name: idx_hardware270225_user_id_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware270225_user_id_btree ON public.hardware270225 USING btree (user_id);


--
-- Name: idx_hardware_131024_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_131024_btree ON public.hardware_131024 USING btree (make);


--
-- Name: idx_hardware_131024_company_id_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_131024_company_id_btree ON public.hardware_131024 USING btree (company_id);


--
-- Name: idx_hardware_131024_cpu_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_131024_cpu_btree ON public.hardware_131024 USING btree (cpu);


--
-- Name: idx_hardware_131024_current_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_131024_current_btree ON public.hardware_131024 USING btree (current);


--
-- Name: idx_hardware_131024_deleted_at_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_131024_deleted_at_btree ON public.hardware_131024 USING btree (deleted_at);


--
-- Name: idx_hardware_131024_model_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_131024_model_btree ON public.hardware_131024 USING btree (model);


--
-- Name: idx_hardware_131024_note_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_131024_note_btree ON public.hardware_131024 USING btree (note);


--
-- Name: idx_hardware_131024_os_name_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_131024_os_name_btree ON public.hardware_131024 USING btree (os_name);


--
-- Name: idx_hardware_131024_os_version_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_131024_os_version_btree ON public.hardware_131024 USING btree (os_version);


--
-- Name: idx_hardware_131024_provaider_id_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_131024_provaider_id_btree ON public.hardware_131024 USING btree (provaider_id);


--
-- Name: idx_hardware_131024_purchased_at_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_131024_purchased_at_btree ON public.hardware_131024 USING btree (purchased_at);


--
-- Name: idx_hardware_131024_ram_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_131024_ram_btree ON public.hardware_131024 USING btree (ram);


--
-- Name: idx_hardware_131024_serial_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_131024_serial_btree ON public.hardware_131024 USING btree (serial);


--
-- Name: idx_hardware_131024_status_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_131024_status_btree ON public.hardware_131024 USING btree (status);


--
-- Name: idx_hardware_131024_type_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_131024_type_btree ON public.hardware_131024 USING btree (type);


--
-- Name: idx_hardware_131024_user_id_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_131024_user_id_btree ON public.hardware_131024 USING btree (user_id);


--
-- Name: idx_hardware_columns; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_columns ON public.hardware USING btree (current, company_id, user_id, provaider_id, purchased_at, created_at, updated_at, deleted_at, id, status, note, make, model, serial, os_name, os_version, type, ram, cpu);


--
-- Name: idx_hardware_columns_copy1; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_columns_copy1 ON public.hardware_050425 USING btree (current, company_id, user_id, provaider_id, purchased_at, created_at, updated_at, deleted_at, id, status, note, make, model, serial, os_name, os_version, type, ram, cpu);


--
-- Name: idx_hardware_columns_copy2; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_columns_copy2 ON public.hardware_140525 USING btree (current, company_id, user_id, provaider_id, purchased_at, created_at, updated_at, deleted_at, id, status, note, make, model, serial, os_name, os_version, type, ram, cpu);


--
-- Name: idx_hardware_columns_copy3; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_hardware_columns_copy3 ON public.hardware_050825 USING btree (current, company_id, user_id, provaider_id, purchased_at, created_at, updated_at, deleted_at, id, status, note, make, model, serial, os_name, os_version, type, ram, cpu);


--
-- Name: idx_mv_active_hardware_summary_id; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE UNIQUE INDEX idx_mv_active_hardware_summary_id ON public.mv_active_hardware_summary USING btree (id);


--
-- Name: idx_test_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_test_btree ON public.test USING btree (make);


--
-- Name: idx_test_company_id_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_test_company_id_btree ON public.test USING btree (company_id);


--
-- Name: idx_test_cpu_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_test_cpu_btree ON public.test USING btree (cpu);


--
-- Name: idx_test_current_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_test_current_btree ON public.test USING btree (current);


--
-- Name: idx_test_deleted_at_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_test_deleted_at_btree ON public.test USING btree (deleted_at);


--
-- Name: idx_test_model_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_test_model_btree ON public.test USING btree (model);


--
-- Name: idx_test_note_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_test_note_btree ON public.test USING btree (note);


--
-- Name: idx_test_os_name_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_test_os_name_btree ON public.test USING btree (os_name);


--
-- Name: idx_test_os_version_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_test_os_version_btree ON public.test USING btree (os_version);


--
-- Name: idx_test_provaider_id_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_test_provaider_id_btree ON public.test USING btree (provaider_id);


--
-- Name: idx_test_purchased_at_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_test_purchased_at_btree ON public.test USING btree (purchased_at);


--
-- Name: idx_test_ram_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_test_ram_btree ON public.test USING btree (ram);


--
-- Name: idx_test_serial_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_test_serial_btree ON public.test USING btree (serial);


--
-- Name: idx_test_status_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_test_status_btree ON public.test USING btree (status);


--
-- Name: idx_test_type_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_test_type_btree ON public.test USING btree (type);


--
-- Name: idx_test_user_id_btree; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX idx_test_user_id_btree ON public.test USING btree (user_id);


--
-- Name: model_has_permissions_model_id_model_type_index; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX model_has_permissions_model_id_model_type_index ON public.model_has_permissions USING btree (model_id, model_type);


--
-- Name: model_has_roles_model_id_model_type_index; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX model_has_roles_model_id_model_type_index ON public.model_has_roles USING btree (model_id, model_type);


--
-- Name: notifications_notifiable_type_notifiable_id_index; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX notifications_notifiable_type_notifiable_id_index ON public.notifications USING btree (notifiable_type, notifiable_id);


--
-- Name: periphels_company_id_index; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX periphels_company_id_index ON public.periphels USING btree (company_id);


--
-- Name: periphels_provaider_id_index; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX periphels_provaider_id_index ON public.periphels USING btree (provaider_id);


--
-- Name: periphels_user_id_index; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX periphels_user_id_index ON public.periphels USING btree (user_id);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: provaiders_company_id_index; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX provaiders_company_id_index ON public.provaiders USING btree (company_id);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: software_company_id_index; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX software_company_id_index ON public.software USING btree (company_id);


--
-- Name: software_provaider_id_index; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX software_provaider_id_index ON public.software USING btree (provaider_id);


--
-- Name: subject; Type: INDEX; Schema: public; Owner: dba_user
--

CREATE INDEX subject ON public.activity_log USING btree (subject_type, subject_id);


--
-- Name: company_invitations company_invitations_company_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.company_invitations
    ADD CONSTRAINT company_invitations_company_id_foreign FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: hardware hardware_company_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.hardware
    ADD CONSTRAINT hardware_company_id_foreign FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: hardware_050425 hardware_copy1_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.hardware_050425
    ADD CONSTRAINT hardware_copy1_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: hardware_140525 hardware_copy1_company_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.hardware_140525
    ADD CONSTRAINT hardware_copy1_company_id_fkey1 FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: hardware_050825 hardware_copy1_company_id_fkey2; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.hardware_050825
    ADD CONSTRAINT hardware_copy1_company_id_fkey2 FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: hardware_050425 hardware_copy1_provaider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.hardware_050425
    ADD CONSTRAINT hardware_copy1_provaider_id_fkey FOREIGN KEY (provaider_id) REFERENCES public.provaiders(id) ON DELETE CASCADE;


--
-- Name: hardware_140525 hardware_copy1_provaider_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.hardware_140525
    ADD CONSTRAINT hardware_copy1_provaider_id_fkey1 FOREIGN KEY (provaider_id) REFERENCES public.provaiders(id) ON DELETE CASCADE;


--
-- Name: hardware_050825 hardware_copy1_provaider_id_fkey2; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.hardware_050825
    ADD CONSTRAINT hardware_copy1_provaider_id_fkey2 FOREIGN KEY (provaider_id) REFERENCES public.provaiders(id) ON DELETE CASCADE;


--
-- Name: hardware_050425 hardware_copy1_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.hardware_050425
    ADD CONSTRAINT hardware_copy1_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: hardware_140525 hardware_copy1_user_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.hardware_140525
    ADD CONSTRAINT hardware_copy1_user_id_fkey1 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: hardware_050825 hardware_copy1_user_id_fkey2; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.hardware_050825
    ADD CONSTRAINT hardware_copy1_user_id_fkey2 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: hardware hardware_provaider_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.hardware
    ADD CONSTRAINT hardware_provaider_id_foreign FOREIGN KEY (provaider_id) REFERENCES public.provaiders(id) ON DELETE CASCADE;


--
-- Name: hardware hardware_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.hardware
    ADD CONSTRAINT hardware_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: model_has_permissions model_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: model_has_roles model_has_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: periphels periphels_company_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.periphels
    ADD CONSTRAINT periphels_company_id_foreign FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: periphels periphels_provaider_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.periphels
    ADD CONSTRAINT periphels_provaider_id_foreign FOREIGN KEY (provaider_id) REFERENCES public.provaiders(id) ON DELETE CASCADE;


--
-- Name: periphels periphels_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.periphels
    ADD CONSTRAINT periphels_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: provaiders provaiders_company_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.provaiders
    ADD CONSTRAINT provaiders_company_id_foreign FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: role_has_permissions role_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_has_permissions role_has_permissions_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: schedule_histories schedule_histories_schedule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.schedule_histories
    ADD CONSTRAINT schedule_histories_schedule_id_foreign FOREIGN KEY (schedule_id) REFERENCES public.schedules(id);


--
-- Name: software software_company_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.software
    ADD CONSTRAINT software_company_id_foreign FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: software software_provaider_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: dba_user
--

ALTER TABLE ONLY public.software
    ADD CONSTRAINT software_provaider_id_foreign FOREIGN KEY (provaider_id) REFERENCES public.provaiders(id) ON DELETE CASCADE;


--
-- Name: SCHEMA dba; Type: ACL; Schema: -; Owner: dba_user
--

REVOKE ALL ON SCHEMA dba FROM dba_user;
GRANT ALL ON SCHEMA dba TO dba_user WITH GRANT OPTION;
GRANT ALL ON SCHEMA dba TO postgres WITH GRANT OPTION;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO dba_user;


--
-- Name: FUNCTION remote_truncate_and_vacuum(); Type: ACL; Schema: cron; Owner: dba_user
--

GRANT ALL ON FUNCTION cron.remote_truncate_and_vacuum() TO postgres;


--
-- Name: FUNCTION remote_vacuum(); Type: ACL; Schema: cron; Owner: dba_user
--

GRANT ALL ON FUNCTION cron.remote_vacuum() TO postgres;


--
-- Name: mv_active_hardware_summary; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: dba_user
--

REFRESH MATERIALIZED VIEW public.mv_active_hardware_summary;


--
-- Name: mv_activity_log_summary; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: dba_user
--

REFRESH MATERIALIZED VIEW public.mv_activity_log_summary;


--
-- PostgreSQL database dump complete
--

